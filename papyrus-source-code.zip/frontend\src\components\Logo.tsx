import React from 'react';
import { Scroll } from 'lucide-react';

interface LogoProps {
  className?: string;
  iconSize?: number;
  textColor?: string;
  subtextColor?: string;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  iconSize = 24,
  textColor = 'text-[#0F2B59]',
  subtextColor = 'text-amber-600',
}) => {
  return (
    <div className={`flex items-center gap-2.5 font-sans ${className}`}>
      <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-[#0F2B59] to-blue-900 shadow-md shadow-blue-950/20 text-amber-400">
        <Scroll size={iconSize} className="stroke-[2.2]" />
        <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-amber-500 rounded-full border-2 border-white flex items-center justify-center">
          <div className="w-1 h-1 bg-white rounded-full"></div>
        </div>
      </div>
      <div className="flex flex-col">
        <span className={`text-xl font-bold tracking-tight ${textColor} font-serif-papyrus`}>
          PAPYRUS
        </span>
        <span className={`text-[10px] font-semibold tracking-wider uppercase ${subtextColor} -mt-1`}>
          Faith Tech
        </span>
      </div>
    </div>
  );
};
