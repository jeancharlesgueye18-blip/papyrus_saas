import prisma from '../config/prisma.js';

export function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Supprimer les accents
    .replace(/\s+/g, '-') // Remplacer espaces par tirets
    .replace(/[^\w-]+/g, '') // Supprimer caractères non alphanumériques
    .replace(/--+/g, '-') // Remplacer doubles tirets
    .replace(/^-+/, '') // Trim début
    .replace(/-+$/, ''); // Trim fin
}

export async function generateUniqueEventSlug(name: string): Promise<string> {
  const base = slugify(name);
  let slug = base;
  let counter = 1;

  while (await prisma.event.findUnique({ where: { slug } })) {
    slug = `${base}-${counter}`;
    counter++;
  }

  return slug;
}
