import * as XLSX from 'xlsx';
import PDFDocument from 'pdfkit';

export interface ExportParticipantItem {
  'N° Inscription': string;
  'Nom': string;
  'Prénom': string;
  'Téléphone': string;
  'Email': string;
  'Paroisse': string;
  'Diocèse': string;
  'Mouvement / Groupe': string;
  'Ville': string;
  'Statut Cotisation': string;
  'Montant Payé (FCFA)': number;
  'Présence': string;
  'Date Inscription': string;
}

export function formatParticipantsForExport(participants: any[]): ExportParticipantItem[] {
  return participants.map((p) => ({
    'N° Inscription': p.registrationNumber,
    'Nom': p.lastName.toUpperCase(),
    'Prénom': p.firstName,
    'Téléphone': p.phone,
    'Email': p.email || '-',
    'Paroisse': p.parish || '-',
    'Diocèse': p.diocese || '-',
    'Mouvement / Groupe': p.movement || '-',
    'Ville': p.city || '-',
    'Statut Cotisation': p.contributionStatus === 'PAID' ? 'Payé' : p.contributionStatus === 'PARTIAL' ? 'Partiel' : 'Non Payé',
    'Montant Payé (FCFA)': p.amountPaid || 0,
    'Présence': p.isPresent ? 'Présent' : 'Absent',
    'Date Inscription': new Date(p.createdAt).toLocaleDateString('fr-FR'),
  }));
}

export function generateExcelBuffer(data: any[], sheetName = 'Participants'): Buffer {
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
}

export function generateCsvBuffer(data: any[]): Buffer {
  const ws = XLSX.utils.json_to_sheet(data);
  const csv = XLSX.utils.sheet_to_csv(ws);
  return Buffer.from(csv, 'utf-8');
}

export function generatePdfDoc(
  title: string,
  eventInfo: { name: string; date: string; location: string },
  items: ExportParticipantItem[]
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 40, size: 'A4' });
    const buffers: Buffer[] = [];

    doc.on('data', (chunk) => buffers.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(buffers)));
    doc.on('error', (err) => reject(err));

    // En-tête PAPYRUS
    doc
      .fillColor('#0F2B59')
      .fontSize(20)
      .text('PAPYRUS - Gestion d\'Événements', { align: 'center' });
    doc
      .fillColor('#D97706')
      .fontSize(14)
      .text(title, { align: 'center' });

    doc.moveDown(0.5);
    doc
      .fillColor('#334155')
      .fontSize(10)
      .text(`Événement : ${eventInfo.name} | Lieu : ${eventInfo.location} | Date : ${eventInfo.date}`, {
        align: 'center',
      });
    doc.text(`Total participants répertoriés : ${items.length}`, { align: 'center' });

    doc.moveDown(1);
    doc.strokeColor('#CBD5E1').lineWidth(1).moveTo(40, doc.y).lineTo(555, doc.y).stroke();
    doc.moveDown(0.8);

    // Tableau compact
    let y = doc.y;
    doc.fontSize(8).fillColor('#0F2B59');
    doc.text('N° Inscription', 40, y, { width: 80 });
    doc.text('Nom & Prénom', 125, y, { width: 120 });
    doc.text('Téléphone', 250, y, { width: 70 });
    doc.text('Paroisse', 325, y, { width: 85 });
    doc.text('Cotisation', 415, y, { width: 65 });
    doc.text('Présence', 485, y, { width: 60 });

    doc.moveDown(0.5);
    doc.strokeColor('#E2E8F0').lineWidth(0.5).moveTo(40, doc.y).lineTo(555, doc.y).stroke();
    doc.moveDown(0.5);

    items.slice(0, 500).forEach((item) => {
      if (doc.y > 750) {
        doc.addPage();
        y = doc.y;
        doc.fontSize(8).fillColor('#0F2B59');
        doc.text('N° Inscription', 40, y, { width: 80 });
        doc.text('Nom & Prénom', 125, y, { width: 120 });
        doc.text('Téléphone', 250, y, { width: 70 });
        doc.text('Paroisse', 325, y, { width: 85 });
        doc.text('Cotisation', 415, y, { width: 65 });
        doc.text('Présence', 485, y, { width: 60 });
        doc.moveDown(0.5);
        doc.strokeColor('#E2E8F0').lineWidth(0.5).moveTo(40, doc.y).lineTo(555, doc.y).stroke();
        doc.moveDown(0.5);
      }

      y = doc.y;
      doc.fontSize(7.5).fillColor('#1E293B');
      doc.text(item['N° Inscription'], 40, y, { width: 80 });
      doc.text(`${item['Nom']} ${item['Prénom']}`, 125, y, { width: 120 });
      doc.text(item['Téléphone'], 250, y, { width: 70 });
      doc.text(item['Paroisse'] || '-', 325, y, { width: 85 });
      doc.text(item['Statut Cotisation'], 415, y, { width: 65 });
      doc.text(item['Présence'], 485, y, { width: 60 });
      doc.moveDown(0.4);
    });

    doc.end();
  });
}
