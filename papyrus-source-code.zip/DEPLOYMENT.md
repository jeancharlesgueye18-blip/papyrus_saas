# Guide Complet de Déploiement en Production — PAPYRUS SaaS 📜

Ce guide vous détaille les 3 options recommandées pour déployer **PAPYRUS** en production, selon vos préférences d'hébergement.

---

## ⚡ Option 1 : Déploiement Clé en Main sur Render (Recommandé - Simple & Rapide)

Le dépôt contient déjà le fichier `render.yaml` prêt à l'emploi.

1. Créez un compte gratuit sur [Render.com](https://render.com).
2. Cliquez sur **New +** > **Blueprint**.
3. Liez votre dépôt GitHub/GitLab contenant le projet PAPYRUS.
4. Render détectera automatiquement `render.yaml` et créera :
   - Une base de données **PostgreSQL** gérée
   - Le service web Node.js Full-Stack
5. Modifiez le provider dans `prisma/schema.prisma` pour activer PostgreSQL :
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```
6. Cliquez sur **Apply** : votre SaaS est en ligne avec HTTPS automatique !

---

## 🚄 Option 2 : Déploiement sur Railway.app

Le dépôt contient également la configuration `railway.json`.

1. Rendez-vous sur [Railway.app](https://railway.app).
2. Créez un **New Project** > **Deploy from GitHub repo**.
3. Ajoutez un plugin **PostgreSQL** d'un simple clic (`+ New` > `Database` > `Add PostgreSQL`).
4. Dans les paramètres de variables d'environnement (`Variables`), liez la base :
   - `DATABASE_URL` : `${{Postgres.DATABASE_URL}}`
   - `JWT_SECRET` : chaîne aléatoire sécurisée (ex: `papyrus_jwt_secret_2027_production`)
   - `SESSION_SECRET` : chaîne aléatoire sécurisée
   - `NODE_ENV` : `production`
   - `PORT` : `5000`
5. Railway applique le build et démarre le serveur automatiquement.

---

## 🐳 Option 3 : Déploiement Docker / Serveur VPS (OVH, DigitalOcean, Hetzner, AWS)

Idéal pour avoir un contrôle total sur votre infrastructure.

### Prérequis sur votre serveur :
- Docker et Docker Compose installés (`docker -v`, `docker compose version`).

### Étapes :
1. Cloner ou transférer le dossier `papyrus/` sur votre VPS :
   ```bash
   git clone <votre_repo> papyrus
   cd papyrus
   ```

2. Changer le provider dans `prisma/schema.prisma` vers `postgresql` :
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```

3. Lancer l'ensemble de la pile (PostgreSQL + App PAPYRUS) :
   ```bash
   docker compose up -d --build
   ```

4. Vérifier les logs :
   ```bash
   docker compose logs -f app
   ```

5. L'application est disponible immédiatement sur le port `5000` (ou derrière un reverse-proxy Nginx avec Certbot SSL).

---

## 🌐 Configuration Nom de Domaine & Paiements Mobiles (Wave / Orange Money)

- **Nom de domaine** : Faites pointer l'enregistrement DNS `A` (ou CNAME) de votre domaine (ex: `app.papyrus.sn`) vers l'adresse IP de votre serveur ou le domaine fourni par Render/Railway.
- Mettez à jour la variable `APP_URL` avec votre URL réelle :
  ```env
  APP_URL="https://app.papyrus.sn"
  ```
- **Webhooks Paiements** : Vos URLs de redirection et webhooks pour Wave ou Orange Money utiliseront cette même base `https://app.papyrus.sn/api/wallet/...`.

---

## 🔑 Comptes initiaux créés automatiquement (Seed) :
- **Organisateur Démo** : `demo@papyrus.sn` / `Papyrus2027!`
- **Administrateur** : `admin@papyrus.sn` / `Admin2027!`
