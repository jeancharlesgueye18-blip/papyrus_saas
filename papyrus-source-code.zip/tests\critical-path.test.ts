import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { app } from '../backend/src/app.js';
import prisma from '../backend/src/config/prisma.js';

describe('PAPYRUS - Suite de Tests Complète du Parcours Critique', () => {
  let organizerToken = '';
  let organizerUserId = '';
  let organizerWalletId = '';
  let eventId = '';
  let eventSlug = '';
  let participantId = '';
  let participantRegNo = '';
  let participantQrToken = '';

  let otherOrganizerToken = '';

  beforeAll(async () => {
    await prisma.$connect();
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('1. Création de compte organisateur et vérification du portefeuille initial (0 FCFA)', async () => {
    const email = `test.org.${Date.now()}@papyrus.sn`;
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        firstName: 'Jean',
        lastName: 'BAPTISTE',
        email,
        phone: '+221 77 111 22 33',
        password: 'Password123!',
        organizationName: 'Paroisse Test',
        organizationType: 'PAROISSE',
      });

    expect(res.status).toBe(201);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.email).toBe(email);
    expect(res.body.user.wallet.balance).toBe(0);

    organizerToken = res.body.token;
    organizerUserId = res.body.user.id;

    // Récupérer l'ID du portefeuille
    const wallet = await prisma.wallet.findUnique({
      where: { userId: organizerUserId },
    });
    expect(wallet).toBeDefined();
    organizerWalletId = wallet!.id;
  });

  it('2. Recharge du portefeuille : Achat du Pack Paroisse (+10 000 FCFA)', async () => {
    const res = await request(app)
      .post('/api/wallet/purchase')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({
        packId: 'pack-100', // 10 000 FCFA = 100 crédits
        paymentMethod: 'WAVE',
      });

    expect(res.status).toBe(200);
    expect(res.body.wallet.balance).toBe(10000);
    expect(res.body.wallet.availableCredits).toBe(100);
    expect(res.body.transaction.type).toBe('CREDIT_PURCHASE');
    expect(res.body.transaction.amount).toBe(10000);
  });

  it('3. Création d\'événement : JMJ Dakar Test (Cotisation 5 000 FCFA)', async () => {
    const res = await request(app)
      .post('/api/events')
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({
        name: `JMJ Dakar Test ${Date.now()}`,
        type: 'JMJ',
        description: 'Événement de test pour validation automatisée',
        startDate: '2027-04-10T08:00:00Z',
        endDate: '2027-04-12T18:00:00Z',
        location: 'Stade Iba Mar Diop, Dakar',
        parish: 'Cathédrale',
        diocese: 'Archidiocèse de Dakar',
        contributionAmount: 5000,
        contributionType: 'FIXED',
      });

    expect(res.status).toBe(201);
    expect(res.body.event).toBeDefined();
    expect(res.body.event.slug).toBeDefined();
    expect(res.body.event.qrCode).toBeDefined();
    expect(res.body.event.contributionAmount).toBe(5000);

    eventId = res.body.event.id;
    eventSlug = res.body.event.slug;
  });

  it('4. Consultation publique de l\'événement (sans authentification)', async () => {
    const res = await request(app).get(`/api/events/public/slug/${eventSlug}`);
    expect(res.status).toBe(200);
    expect(res.body.event.slug).toBe(eventSlug);
    expect(res.body.event.contributionAmount).toBe(5000);
  });

  it('5. Inscription publique d\'un participant avec prélèvement atomique de 100 FCFA', async () => {
    const res = await request(app)
      .post(`/api/registrations/public/${eventSlug}`)
      .send({
        firstName: 'Pierre',
        lastName: 'FAYE',
        phone: '+221 77 987 65 43',
        email: 'pierre.faye@example.sn',
        gender: 'M',
        parish: 'Saint-Joseph de Médina',
        diocese: 'Archidiocèse de Dakar',
        movement: 'Scouts',
        city: 'Dakar',
      });

    expect(res.status).toBe(201);
    expect(res.body.participant).toBeDefined();
    expect(res.body.participant.registrationNumber).toMatch(/^PAP-\d{4}-\d{6}$/);
    expect(res.body.participant.qrCode).toBeDefined();
    expect(res.body.participant.qrToken).toBeDefined();
    expect(res.body.participant.contributionStatus).toBe('UNPAID');

    participantId = res.body.participant.id;
    participantRegNo = res.body.participant.registrationNumber;
    participantQrToken = res.body.participant.qrToken;

    // VÉRIFICATION VÉRITABLE DANS LA BASE DE DONNÉES :
    // Le solde doit être passé exactement de 10 000 à 9 900 FCFA !
    const updatedWallet = await prisma.wallet.findUnique({
      where: { id: organizerWalletId },
    });
    expect(updatedWallet!.balance).toBe(9900);

    // Une transaction de -100 FCFA doit exister
    const feeTx = await prisma.transaction.findFirst({
      where: {
        userId: organizerUserId,
        type: 'REGISTRATION_FEE',
        amount: -100,
      },
    });
    expect(feeTx).toBeDefined();
  });

  it('6. Enregistrement d\'une cotisation de 5 000 FCFA', async () => {
    const res = await request(app)
      .post(`/api/contributions/events/${eventId}/contributions`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({
        participantId,
        amount: 5000,
        paymentMethod: 'WAVE',
        reference: 'WAVE-REC-TEST-99',
      });

    expect(res.status).toBe(201);
    expect(res.body.contribution.amount).toBe(5000);
    expect(res.body.participant.contributionStatus).toBe('PAID');
    expect(res.body.participant.amountPaid).toBe(5000);
  });

  it('7. Contrôle d\'accès et pointage QR Code (Check-in)', async () => {
    // 7.1 Recherche du billet via QR Token
    const lookupRes = await request(app)
      .get(`/api/checkin/events/${eventId}/lookup?query=${participantQrToken}`)
      .set('Authorization', `Bearer ${organizerToken}`);

    expect(lookupRes.status).toBe(200);
    expect(lookupRes.body.participant.id).toBe(participantId);
    expect(lookupRes.body.participant.isPresent).toBe(false);

    // 7.2 Validation du Check-In
    const checkInRes = await request(app)
      .post(`/api/checkin/events/${eventId}/confirm`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({
        participantId,
        deviceInfo: 'Scanner Test Jest/Vitest',
      });

    expect(checkInRes.status).toBe(200);
    expect(checkInRes.body.participant.isPresent).toBe(true);

    // 7.3 Empêcher le double check-in
    const duplicateRes = await request(app)
      .post(`/api/checkin/events/${eventId}/confirm`)
      .set('Authorization', `Bearer ${organizerToken}`)
      .send({
        participantId,
      });

    expect(duplicateRes.status).toBe(409); // Conflit / déjà pointé
  });

  it('8. Test Critique : Solde insuffisant (100 FCFA -> 1 inscription OK -> 2ème refusée)', async () => {
    // Créer un utilisateur spécifique avec exactement 100 FCFA
    const testUser = await prisma.user.create({
      data: {
        firstName: 'Solde',
        lastName: 'TEST',
        email: `solde.test.${Date.now()}@papyrus.sn`,
        phone: '+221 77 999 88 77',
        password: 'hashed_password',
        role: 'ORGANIZER',
      },
    });

    const testWallet = await prisma.wallet.create({
      data: {
        userId: testUser.id,
        balance: 100, // Exactement le prix d'1 inscription
      },
    });

    const testEvent = await prisma.event.create({
      data: {
        userId: testUser.id,
        name: `Événement Test Solde Limite ${Date.now()}`,
        slug: `test-solde-${Date.now()}`,
        type: 'RETRAITE',
        startDate: new Date('2027-06-01'),
        location: 'Dakar',
        contributionAmount: 0,
      },
    });

    // Inscription 1 : Doit réussir car solde = 100 FCFA
    const res1 = await request(app)
      .post(`/api/registrations/public/${testEvent.slug}`)
      .send({
        firstName: 'Premier',
        lastName: 'PARTICIPANT',
        phone: '+221 77 100 00 01',
      });

    expect(res1.status).toBe(201);

    // Vérifier que le solde est tombé à 0 FCFA
    const walletAfterFirst = await prisma.wallet.findUnique({
      where: { id: testWallet.id },
    });
    expect(walletAfterFirst!.balance).toBe(0);

    // Inscription 2 : Doit impérativement être REFUSÉE (solde = 0 FCFA < 100 FCFA)
    const res2 = await request(app)
      .post(`/api/registrations/public/${testEvent.slug}`)
      .send({
        firstName: 'Deuxieme',
        lastName: 'TENTATIVE',
        phone: '+221 77 100 00 02',
      });

    expect(res2.status).toBe(402);
    expect(res2.body.code).toBe('INSUFFICIENT_WALLET_BALANCE');

    // Le participant 2 ne doit PAS exister en base
    const p2Count = await prisma.participant.count({
      where: { eventId: testEvent.id, firstName: 'Deuxieme' },
    });
    expect(p2Count).toBe(0);

    // Le solde doit rester à 0 FCFA (pas de solde négatif)
    const walletAfterSecond = await prisma.wallet.findUnique({
      where: { id: testWallet.id },
    });
    expect(walletAfterSecond!.balance).toBe(0);
  });

  it('9. Isolation des données : un autre organisateur ne peut pas accéder à cet événement', async () => {
    // Créer un autre organisateur
    const resAuth = await request(app)
      .post('/api/auth/register')
      .send({
        firstName: 'Autre',
        lastName: 'ORGANISATEUR',
        email: `autre.org.${Date.now()}@papyrus.sn`,
        phone: '+221 70 333 44 55',
        password: 'Password123!',
      });

    otherOrganizerToken = resAuth.body.token;

    // Tenter d'accéder aux participants de l'événement du premier organisateur
    const resForbidden = await request(app)
      .get(`/api/participants/events/${eventId}/participants`)
      .set('Authorization', `Bearer ${otherOrganizerToken}`);

    expect(resForbidden.status).toBe(403);
  });

  it('10. Génération des listes dynamiques par catégorie', async () => {
    const res = await request(app)
      .get(`/api/participants/events/${eventId}/categories`)
      .set('Authorization', `Bearer ${organizerToken}`);

    expect(res.status).toBe(200);
    expect(res.body.summary).toBeDefined();
    expect(res.body.lists.cotisants.length).toBeGreaterThanOrEqual(1);
    expect(res.body.lists.presents.length).toBeGreaterThanOrEqual(1);
  });

  it('11. Export des données en Excel (XLSX), CSV et PDF', async () => {
    // Export Excel
    const excelRes = await request(app)
      .get(`/api/exports/events/${eventId}?format=xlsx`)
      .set('Authorization', `Bearer ${organizerToken}`);

    expect(excelRes.status).toBe(200);
    expect(excelRes.headers['content-type']).toContain('spreadsheetml.sheet');

    // Export CSV
    const csvRes = await request(app)
      .get(`/api/exports/events/${eventId}?format=csv`)
      .set('Authorization', `Bearer ${organizerToken}`);

    expect(csvRes.status).toBe(200);
    expect(csvRes.headers['content-type']).toContain('text/csv');

    // Export PDF
    const pdfRes = await request(app)
      .get(`/api/exports/events/${eventId}?format=pdf`)
      .set('Authorization', `Bearer ${organizerToken}`);

    expect(pdfRes.status).toBe(200);
    expect(pdfRes.headers['content-type']).toContain('application/pdf');
  });

  it('12. Portail Administrateur Papyrus (/api/admin)', async () => {
    // Connexion avec l'admin créé dans le seed
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'admin@papyrus.sn',
        password: 'Admin2027!',
      });

    expect(loginRes.status).toBe(200);
    const adminToken = loginRes.body.token;

    const dashRes = await request(app)
      .get('/api/admin/dashboard')
      .set('Authorization', `Bearer ${adminToken}`);

    expect(dashRes.status).toBe(200);
    expect(dashRes.body.metrics.totalUsers).toBeGreaterThan(0);
    expect(dashRes.body.metrics.totalEvents).toBeGreaterThan(0);
    expect(dashRes.body.metrics.papyrusEarnedFees).toBeGreaterThan(0);
  });
});
