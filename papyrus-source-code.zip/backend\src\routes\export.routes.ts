import { Router } from 'express';
import { exportEventData } from '../controllers/export.controller.js';
import { authenticateToken } from '../middleware/auth.js';
import { authorizeEvent } from '../middleware/eventAuth.js';

const router = Router();

router.use(authenticateToken);

router.get('/events/:id', authorizeEvent('MANAGER'), exportEventData);

export default router;
