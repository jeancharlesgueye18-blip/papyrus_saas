import { Request, Response } from 'express';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest } from '../types/index.js';
import { generateUniqueEventSlug } from '../utils/slug.js';
import { generateQrCodeDataUrl } from '../utils/qr.js';

export async function createEvent(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Non authentifié' });
      return;
    }

    const {
      name,
      type,
      description,
      startDate,
      endDate,
      location,
      parish,
      diocese,
      contributionAmount,
      contributionType,
      customFields,
    } = req.body;

    if (!name || !startDate || !location) {
      res.status(400).json({ error: 'Le nom, la date de début et le lieu sont obligatoires' });
      return;
    }

    const slug = await generateUniqueEventSlug(name);
    const appUrl = process.env.APP_URL || 'http://localhost:5000';
    const publicUrl = `${appUrl}/e/${slug}`;

    // Générer le QR Code de l'événement vers la page publique d'inscription
    const qrCode = await generateQrCodeDataUrl(publicUrl);

    const event = await prisma.event.create({
      data: {
        userId: req.user.id,
        name: name.trim(),
        slug,
        type: type || 'AUTRE',
        description: description?.trim(),
        startDate: new Date(startDate),
        endDate: endDate ? new Date(endDate) : null,
        location: location.trim(),
        parish: parish?.trim(),
        diocese: diocese?.trim(),
        contributionAmount: Number(contributionAmount) || 0,
        contributionType: contributionType || 'FIXED',
        qrCode,
        customFields: {
          create: Array.isArray(customFields)
            ? customFields.map((f: any, idx: number) => ({
                label: f.label,
                name: f.name || f.label.toLowerCase().replace(/\s+/g, '_'),
                type: f.type || 'text',
                required: Boolean(f.required),
                options: f.options ? JSON.stringify(f.options) : null,
                order: idx,
              }))
            : [],
        },
      },
      include: {
        customFields: true,
      },
    });

    res.status(201).json({
      message: 'Événement créé avec succès',
      event,
      publicUrl,
    });
  } catch (error) {
    console.error('Erreur createEvent:', error);
    res.status(500).json({ error: 'Erreur lors de la création de l\'événement' });
  }
}

export async function getEvents(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Non authentifié' });
      return;
    }

    // Récupérer les événements dont l'utilisateur est propriétaire ou staff
    const events = await prisma.event.findMany({
      where: {
        OR: [
          { userId: req.user.id },
          { staff: { some: { userId: req.user.id } } },
        ],
      },
      include: {
        _count: {
          select: {
            participants: true,
          },
        },
        participants: {
          select: {
            amountPaid: true,
            isPresent: true,
            contributionStatus: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const enrichedEvents = events.map((event) => {
      const totalParticipants = event._count.participants;
      const totalCollected = event.participants.reduce((sum, p) => sum + p.amountPaid, 0);
      const totalCheckedIn = event.participants.filter((p) => p.isPresent).length;
      const fullyPaidCount = event.participants.filter((p) => p.contributionStatus === 'PAID').length;

      const { participants, ...rest } = event;
      return {
        ...rest,
        stats: {
          totalParticipants,
          totalCollected,
          totalCheckedIn,
          fullyPaidCount,
        },
      };
    });

    res.json({ events: enrichedEvents });
  } catch (error) {
    console.error('Erreur getEvents:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération des événements' });
  }
}

export async function getEventById(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params;

    const event = await prisma.event.findUnique({
      where: { id },
      include: {
        customFields: { orderBy: { order: 'asc' } },
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
            phone: true,
          },
        },
        staff: {
          include: {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
          },
        },
        _count: {
          select: { participants: true },
        },
      },
    });

    if (!event) {
      res.status(404).json({ error: 'Événement non trouvé' });
      return;
    }

    res.json({ event });
  } catch (error) {
    console.error('Erreur getEventById:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération de l\'événement' });
  }
}

/**
 * Endpoint public sans authentification pour la page d'inscription /e/:slug
 */
export async function getEventBySlug(req: Request, res: Response): Promise<void> {
  try {
    const { slug } = req.params;

    const event = await prisma.event.findUnique({
      where: { slug },
      include: {
        customFields: { orderBy: { order: 'asc' } },
        user: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
            phone: true,
            organization: {
              select: {
                name: true,
                type: true,
                diocese: true,
                city: true,
              },
            },
          },
        },
        _count: {
          select: { participants: true },
        },
      },
    });

    if (!event || !event.isActive) {
      res.status(404).json({ error: 'Événement introuvable ou actuellement inactif' });
      return;
    }

    res.json({ event });
  } catch (error) {
    console.error('Erreur getEventBySlug:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération de l\'événement public' });
  }
}

export async function updateEvent(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    const {
      name,
      type,
      description,
      startDate,
      endDate,
      location,
      parish,
      diocese,
      contributionAmount,
      contributionType,
      isActive,
    } = req.body;

    const event = await prisma.event.update({
      where: { id },
      data: {
        name,
        type,
        description,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : null,
        location,
        parish,
        diocese,
        contributionAmount: contributionAmount !== undefined ? Number(contributionAmount) : undefined,
        contributionType,
        isActive: isActive !== undefined ? Boolean(isActive) : undefined,
      },
    });

    res.json({ message: 'Événement mis à jour', event });
  } catch (error) {
    console.error('Erreur updateEvent:', error);
    res.status(500).json({ error: 'Erreur lors de la mise à jour de l\'événement' });
  }
}

export async function deleteEvent(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params;

    await prisma.event.delete({
      where: { id },
    });

    res.json({ message: 'Événement supprimé avec succès' });
  } catch (error) {
    console.error('Erreur deleteEvent:', error);
    res.status(500).json({ error: 'Erreur lors de la suppression de l\'événement' });
  }
}
