import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { EventItem } from '../types/index.js';
import {
  Calendar,
  Users,
  Coins,
  QrCode,
  Share2,
  FileSpreadsheet,
  FileText,
  MapPin,
  Clock,
  ArrowUpRight,
  ListFilter,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
} from 'lucide-react';

export const EventDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [event, setEvent] = useState<EventItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (id) {
      api.getEventById(id)
        .then((data) => setEvent(data.event))
        .catch((err) => console.error(err))
        .finally(() => setLoading(false));
    }
  }, [id]);

  if (loading) {
    return (
      <div className="text-center py-20 text-slate-400 text-sm">
        Chargement de l'événement...
      </div>
    );
  }

  if (!event) {
    return (
      <div className="text-center py-20 text-slate-500">
        Événement introuvable.
      </div>
    );
  }

  const appUrl = window.location.origin;
  const publicUrl = `${appUrl}/e/${event.slug}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(publicUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-8 pb-20 animate-fade-in">
      {/* BANNIÈRE EN-TÊTE ÉVÉNEMENT */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-100 shadow-sm relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-50 text-[#0F2B59]">
                {event.type}
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                  event.isActive
                    ? 'bg-emerald-50 text-emerald-700'
                    : 'bg-slate-100 text-slate-500'
                }`}
              >
                {event.isActive ? 'Inscriptions Ouvertes' : 'Inscriptions Clôturées'}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F2B59]">
              {event.name}
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-xs sm:text-sm text-slate-500">
              <div className="flex items-center gap-1.5">
                <MapPin size={16} className="text-slate-400" />
                <span>{event.location}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock size={16} className="text-slate-400" />
                <span>{new Date(event.startDate).toLocaleDateString('fr-FR')}</span>
              </div>
              {event.parish && (
                <div className="text-slate-600 font-medium">
                  Paroisse : {event.parish}
                </div>
              )}
            </div>
          </div>

          {/* ACTIONS D'ACCÈS PUBLIC ET PARTAGE */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleCopyLink}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-colors"
            >
              {copied ? <Check size={16} className="text-emerald-600" /> : <Copy size={16} />}
              <span>{copied ? 'Lien copié !' : 'Copier le lien public'}</span>
            </button>

            <Link
              to={`/events/${event.id}/share`}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0F2B59] text-xs font-bold transition-all shadow-sm"
            >
              <Share2 size={16} />
              <span>Partager & QR Code</span>
            </Link>

            <a
              href={`/e/${event.slug}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white text-xs font-bold transition-all shadow-sm"
            >
              <span>Page publique</span>
              <ArrowUpRight size={16} className="text-amber-400" />
            </a>
          </div>
        </div>
      </div>

      {/* MODULES DE GESTION PRINCIPAUX (Raccourcis en Cartes) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Participants */}
        <Link
          to={`/events/${event.id}/participants`}
          className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm hover:border-blue-300 hover:shadow-md transition-all group"
        >
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#0F2B59] group-hover:bg-[#0F2B59] group-hover:text-amber-400 flex items-center justify-center mb-4 transition-colors">
            <Users size={22} />
          </div>
          <h3 className="text-base font-bold text-[#0F2B59] mb-1">
            Participants
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Recherche, filtres, tri et modification des inscrits.
          </p>
          <span className="text-xs font-bold text-[#0F2B59] group-hover:text-amber-600 flex items-center gap-1">
            Gérer la liste →
          </span>
        </Link>

        {/* Listes dynamiques */}
        <Link
          to={`/events/${event.id}/categories`}
          className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm hover:border-amber-300 hover:shadow-md transition-all group"
        >
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-700 group-hover:bg-amber-500 group-hover:text-[#0F2B59] flex items-center justify-center mb-4 transition-colors">
            <ListFilter size={22} />
          </div>
          <h3 className="text-base font-bold text-[#0F2B59] mb-1">
            Listes par Catégorie
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Par paroisse, diocèse, mouvement, cotisants et présents.
          </p>
          <span className="text-xs font-bold text-amber-600 flex items-center gap-1">
            Voir les listes →
          </span>
        </Link>

        {/* Cotisations */}
        <Link
          to={`/events/${event.id}/contributions`}
          className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm hover:border-emerald-300 hover:shadow-md transition-all group"
        >
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white flex items-center justify-center mb-4 transition-colors">
            <Coins size={22} />
          </div>
          <h3 className="text-base font-bold text-[#0F2B59] mb-1">
            Cotisations & Caisse
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Enregistrez les paiements Wave, Orange Money et espèces.
          </p>
          <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
            Gérer la caisse →
          </span>
        </Link>

        {/* Scanner Check-In */}
        <Link
          to={`/events/${event.id}/check-in`}
          className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm hover:border-purple-300 hover:shadow-md transition-all group"
        >
          <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-700 group-hover:bg-purple-600 group-hover:text-white flex items-center justify-center mb-4 transition-colors">
            <QrCode size={22} />
          </div>
          <h3 className="text-base font-bold text-[#0F2B59] mb-1">
            Contrôle & Scanner
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Scannez les QR Codes à l'entrée et validez la présence.
          </p>
          <span className="text-xs font-bold text-purple-700 flex items-center gap-1">
            Ouvrir le scanner →
          </span>
        </Link>
      </div>

      {/* EXPORTS DE DONNÉES EN UN CLIC (Section 23) */}
      <div className="p-6 rounded-3xl bg-slate-50 border border-slate-200/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-[#0F2B59] flex items-center gap-2">
              <FileSpreadsheet size={20} className="text-emerald-600" />
              Exports officiels de l'événement
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Téléchargez les listes complètes des participants aux formats standard.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <a
              href={`/api/exports/events/${event.id}?format=xlsx`}
              target="_blank"
              download
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 text-xs font-bold shadow-sm transition-all"
            >
              <FileSpreadsheet size={15} className="text-emerald-600" />
              <span>Excel (.xlsx)</span>
            </a>

            <a
              href={`/api/exports/events/${event.id}?format=csv`}
              target="_blank"
              download
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 text-xs font-bold shadow-sm transition-all"
            >
              <FileText size={15} className="text-blue-600" />
              <span>CSV</span>
            </a>

            <a
              href={`/api/exports/events/${event.id}?format=pdf`}
              target="_blank"
              download
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 text-xs font-bold shadow-sm transition-all"
            >
              <FileText size={15} className="text-rose-600" />
              <span>PDF Officiel</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
