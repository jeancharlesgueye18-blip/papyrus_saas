import { Response } from 'express';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest } from '../types/index.js';

export async function getEventContributions(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params; // eventId

    const event = await prisma.event.findUnique({
      where: { id },
      include: {
        participants: {
          select: {
            id: true,
            registrationNumber: true,
            firstName: true,
            lastName: true,
            phone: true,
            parish: true,
            contributionStatus: true,
            amountPaid: true,
          },
        },
      },
    });

    if (!event) {
      res.status(404).json({ error: 'Événement non trouvé' });
      return;
    }

    const participants = event.participants;
    const totalParticipants = participants.length;
    const feePerPerson = event.contributionAmount;
    const totalExpected = totalParticipants * feePerPerson;
    const totalCollected = participants.reduce((sum, p) => sum + p.amountPaid, 0);
    const totalRemaining = Math.max(0, totalExpected - totalCollected);

    const paidCount = participants.filter((p) => p.contributionStatus === 'PAID').length;
    const partialCount = participants.filter((p) => p.contributionStatus === 'PARTIAL').length;
    const unpaidCount = participants.filter((p) => p.contributionStatus === 'UNPAID').length;

    // Récupérer l'historique détaillé des paiements
    const contributions = await prisma.contribution.findMany({
      where: {
        participant: {
          eventId: id,
        },
      },
      include: {
        participant: {
          select: {
            id: true,
            registrationNumber: true,
            firstName: true,
            lastName: true,
            phone: true,
            parish: true,
          },
        },
      },
      orderBy: { date: 'desc' },
    });

    res.json({
      summary: {
        feePerPerson,
        totalExpected,
        totalCollected,
        totalRemaining,
        paidCount,
        partialCount,
        unpaidCount,
        totalParticipants,
      },
      contributions,
      participants,
    });
  } catch (error) {
    console.error('Erreur getEventContributions:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération des cotisations' });
  }
}

export async function recordContribution(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params; // eventId
    const { participantId, amount, paymentMethod, reference } = req.body;

    const parsedAmount = parseInt(amount, 10);
    if (!participantId || isNaN(parsedAmount) || parsedAmount <= 0) {
      res.status(400).json({ error: 'Participant et montant valide requis' });
      return;
    }

    const event = await prisma.event.findUnique({
      where: { id },
    });

    if (!event) {
      res.status(404).json({ error: 'Événement non trouvé' });
      return;
    }

    const participant = await prisma.participant.findUnique({
      where: { id: participantId },
    });

    if (!participant || participant.eventId !== id) {
      res.status(404).json({ error: 'Participant introuvable pour cet événement' });
      return;
    }

    const staffName = req.user
      ? `${req.user.firstName} ${req.user.lastName}`
      : 'Responsable';

    // Transaction atomique : Créer le paiement et recalculer le statut du participant
    const result = await prisma.$transaction(async (tx) => {
      const contribution = await tx.contribution.create({
        data: {
          participantId,
          amount: parsedAmount,
          paymentMethod: paymentMethod || 'ESPECES',
          reference: reference || `PAY-${Date.now()}`,
          recordedBy: staffName,
        },
      });

      const newTotalPaid = participant.amountPaid + parsedAmount;
      let newStatus: 'PAID' | 'PARTIAL' | 'UNPAID' = 'PARTIAL';

      if (newTotalPaid >= event.contributionAmount) {
        newStatus = 'PAID';
      } else if (newTotalPaid === 0) {
        newStatus = 'UNPAID';
      }

      const updatedParticipant = await tx.participant.update({
        where: { id: participantId },
        data: {
          amountPaid: newTotalPaid,
          contributionStatus: newStatus,
        },
      });

      // Notification
      await tx.notification.create({
        data: {
          userId: event.userId,
          title: `Cotisation reçue : ${parsedAmount.toLocaleString('fr-FR')} FCFA`,
          message: `Reçu pour ${participant.firstName} ${participant.lastName} (${event.name}) via ${paymentMethod || 'Espèces'}.`,
          type: 'PAYMENT',
        },
      });

      return { contribution, updatedParticipant };
    });

    res.status(201).json({
      message: 'Cotisation enregistrée avec succès',
      contribution: result.contribution,
      participant: result.updatedParticipant,
    });
  } catch (error) {
    console.error('Erreur recordContribution:', error);
    res.status(500).json({ error: 'Erreur lors de l\'enregistrement de la cotisation' });
  }
}
