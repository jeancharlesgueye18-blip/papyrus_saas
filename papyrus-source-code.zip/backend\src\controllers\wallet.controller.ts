import { Response } from 'express';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest, CREDIT_PACKS } from '../types/index.js';

export async function getWallet(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Non authentifié' });
      return;
    }

    const wallet = await prisma.wallet.findUnique({
      where: { userId: req.user.id },
    });

    if (!wallet) {
      res.status(404).json({ error: 'Portefeuille introuvable' });
      return;
    }

    const transactions = await prisma.transaction.findMany({
      where: { userId: req.user.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    res.json({
      wallet: {
        id: wallet.id,
        balance: wallet.balance,
        availableCredits: Math.floor(wallet.balance / 100),
        costPerRegistration: 100,
      },
      packs: CREDIT_PACKS,
      transactions,
    });
  } catch (error) {
    console.error('Erreur getWallet:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération du portefeuille' });
  }
}

export async function purchaseCredits(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Non authentifié' });
      return;
    }

    const { packId, paymentMethod = 'SIMULATED', phoneNumber } = req.body;

    const pack = CREDIT_PACKS.find((p) => p.id === packId);
    if (!pack) {
      res.status(400).json({ error: 'Pack de crédits sélectionné non valide' });
      return;
    }

    const reference = `TX-PACK-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

    // Rechargement atomique dans une transaction
    const result = await prisma.$transaction(async (tx) => {
      // 1. Créditer le portefeuille de l'organisateur
      const updatedWallet = await tx.wallet.update({
        where: { userId: req.user!.id },
        data: {
          balance: {
            increment: pack.price,
          },
        },
      });

      // 2. Créer l'enregistrement de transaction
      const transaction = await tx.transaction.create({
        data: {
          userId: req.user!.id,
          amount: pack.price,
          type: 'CREDIT_PURCHASE',
          status: 'COMPLETED',
          reference,
          paymentMethod,
          packName: pack.name,
        },
      });

      // 3. Notification de confirmation
      await tx.notification.create({
        data: {
          userId: req.user!.id,
          title: `Portefeuille rechargé : +${pack.credits} inscriptions`,
          message: `Votre achat de "${pack.name}" (${pack.price.toLocaleString('fr-FR')} FCFA) a été confirmé via ${paymentMethod}.`,
          type: 'SUCCESS',
        },
      });

      return { updatedWallet, transaction };
    });

    res.status(200).json({
      message: 'Recharge effectuée avec succès !',
      wallet: {
        balance: result.updatedWallet.balance,
        availableCredits: Math.floor(result.updatedWallet.balance / 100),
      },
      transaction: result.transaction,
    });
  } catch (error) {
    console.error('Erreur purchaseCredits:', error);
    res.status(500).json({ error: 'Erreur lors du traitement de la recharge' });
  }
}
