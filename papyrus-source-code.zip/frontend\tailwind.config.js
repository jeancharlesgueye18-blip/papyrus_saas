/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        papyrus: {
          blue: {
            DEFAULT: '#0F2B59',
            dark: '#0A1C3A',
            light: '#1E3A8A',
            subtle: '#EEF2F6',
          },
          gold: {
            DEFAULT: '#D97706',
            light: '#F59E0B',
            dark: '#B45309',
            warm: '#FDE68A',
          },
        },
      },
    },
  },
  plugins: [],
};
