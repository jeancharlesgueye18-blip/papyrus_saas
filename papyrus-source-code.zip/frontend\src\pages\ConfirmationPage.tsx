import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import confetti from 'canvas-confetti';
import { api } from '../services/api.js';
import { Participant } from '../types/index.js';
import { Logo } from '../components/Logo.js';
import { Badge } from '../components/Badge.js';
import {
  CheckCircle2,
  Download,
  Printer,
  Share2,
  Calendar,
  MapPin,
  Coins,
  ShieldCheck,
  ArrowLeft,
  Copy,
  Check,
} from 'lucide-react';

export const ConfirmationPage: React.FC = () => {
  const { regNumber } = useParams<{ regNumber: string }>();
  const [participant, setParticipant] = useState<Participant | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const ticketRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (regNumber) {
      api.getPublicTicket(regNumber)
        .then((data) => {
          setParticipant(data.participant);
          // Lancer l'animation confetti
          try {
            confetti({
              particleCount: 80,
              spread: 70,
              origin: { y: 0.6 },
              colors: ['#0F2B59', '#D97706', '#10B981'],
            });
          } catch (e) {}
        })
        .catch((err) => console.error(err))
        .finally(() => setLoading(false));
    }
  }, [regNumber]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    if (!participant || !participant.qrCode) return;
    const a = document.createElement('a');
    a.href = participant.qrCode;
    a.download = `billet-${participant.registrationNumber}.png`;
    a.click();
  };

  const handleShareWhatsApp = () => {
    if (!participant) return;
    const currentUrl = window.location.href;
    const text = encodeURIComponent(
      `Mon inscription à "${participant.event?.name}" est confirmée ! Mon numéro est le ${participant.registrationNumber}.\nBillet : ${currentUrl}`
    );
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center text-slate-500 text-sm">
          Génération de votre billet en cours...
        </div>
      </div>
    );
  }

  if (!participant) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 text-center">
        <h1 className="text-xl font-bold text-slate-800">Billet introuvable</h1>
        <p className="text-xs text-slate-500 mt-1">
          Le numéro d'inscription fourni ne correspond à aucun participant.
        </p>
        <Link to="/" className="mt-4 text-xs font-bold text-[#0F2B59] hover:underline">
          Retour à l'accueil
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col py-8 px-4 selection:bg-amber-100 selection:text-blue-900">
      <div className="max-w-xl mx-auto w-full space-y-6">
        {/* MESSAGE DE SUCCÈS */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md">
            <CheckCircle2 size={36} />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F2B59]">
            Inscription confirmée !
          </h1>
          <p className="text-xs text-slate-600">
            Votre place est réservée. Présentez ce QR Code le jour du rassemblement.
          </p>
        </div>

        {/* BILLET OFFICIEL PAPYRUS (Imprimable) */}
        <div
          ref={ticketRef}
          className="bg-white rounded-3xl overflow-hidden border border-slate-200/80 shadow-2xl shadow-slate-200/60 print:shadow-none print:border-slate-400"
        >
          {/* Haut du billet */}
          <div className="bg-[#0F2B59] text-white p-6 relative overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <Logo textColor="text-white" subtextColor="text-amber-300" />
              <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500 text-[#0F2B59]">
                Billet Officiel
              </span>
            </div>

            <div className="space-y-1">
              <div className="text-xs text-slate-300 uppercase tracking-wider font-semibold">
                {participant.event?.type}
              </div>
              <h2 className="text-xl font-bold text-white">
                {participant.event?.name}
              </h2>
            </div>

            <div className="mt-4 pt-3 border-t border-white/10 flex flex-wrap gap-4 text-xs text-slate-200">
              <div className="flex items-center gap-1.5">
                <Calendar size={14} className="text-amber-400" />
                <span>
                  {participant.event?.startDate
                    ? new Date(participant.event.startDate).toLocaleDateString('fr-FR')
                    : '-'}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin size={14} className="text-amber-400" />
                <span>{participant.event?.location}</span>
              </div>
            </div>
          </div>

          {/* Corps du billet */}
          <div className="p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-100">
              {/* Infos participant */}
              <div className="space-y-3 text-center sm:text-left flex-1">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Participant
                  </span>
                  <div className="text-xl font-extrabold text-[#0F2B59]">
                    {participant.firstName} {participant.lastName.toUpperCase()}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    N° d'Inscription Unique
                  </span>
                  <div className="text-base font-black text-amber-600 font-mono tracking-wider">
                    {participant.registrationNumber}
                  </div>
                </div>

                <div className="flex flex-wrap gap-3 justify-center sm:justify-start text-xs text-slate-600">
                  {participant.parish && <div>Paroisse : <strong>{participant.parish}</strong></div>}
                  {participant.diocese && <div>Diocèse : <strong>{participant.diocese}</strong></div>}
                </div>
              </div>

              {/* QR Code */}
              <div className="flex flex-col items-center shrink-0">
                {participant.qrCode && (
                  <div className="p-2 rounded-2xl bg-slate-50 border border-slate-200 shadow-sm">
                    <img
                      src={participant.qrCode}
                      alt={`QR Code ${participant.registrationNumber}`}
                      className="w-36 h-36 object-contain"
                    />
                  </div>
                )}
                <span className="text-[10px] text-slate-400 mt-1 font-semibold uppercase tracking-wider">
                  Pass d'Accès
                </span>
              </div>
            </div>

            {/* Statut Cotisation */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
              <div>
                <span className="text-slate-500 block">Cotisation Événement</span>
                <span className="font-bold text-slate-900 text-sm">
                  {(participant.event?.contributionAmount || 0).toLocaleString('fr-FR')} FCFA
                </span>
              </div>
              <div className="text-right">
                <span className="text-slate-500 block mb-1">Statut Paiement</span>
                <Badge status={participant.contributionStatus} />
              </div>
            </div>
          </div>
        </div>

        {/* BOUTONS D'ACTION (Section 15 : Télécharger, Partager, Imprimer) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 print:hidden">
          <button
            onClick={handleDownload}
            className="flex items-center justify-center gap-1.5 p-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold shadow-sm transition-colors"
          >
            <Download size={16} className="text-blue-600" />
            <span>Télécharger</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center justify-center gap-1.5 p-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold shadow-sm transition-colors"
          >
            <Printer size={16} className="text-slate-600" />
            <span>Imprimer</span>
          </button>

          <button
            onClick={handleShareWhatsApp}
            className="flex items-center justify-center gap-1.5 p-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm transition-colors"
          >
            <Share2 size={16} />
            <span>WhatsApp</span>
          </button>

          <button
            onClick={handleCopyLink}
            className="flex items-center justify-center gap-1.5 p-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold shadow-sm transition-colors"
          >
            {copied ? <Check size={16} className="text-emerald-600" /> : <Copy size={16} />}
            <span>{copied ? 'Copié !' : 'Copier'}</span>
          </button>
        </div>

        <div className="text-center pt-2 print:hidden">
          <Link
            to={`/e/${participant.event?.slug}`}
            className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-[#0F2B59] font-semibold"
          >
            <ArrowLeft size={14} /> Retour à la page de l'événement
          </Link>
        </div>
      </div>
    </div>
  );
};
