import { Request, Response } from 'express';
import crypto from 'crypto';
import prisma from '../config/prisma.js';
import { generateRegistrationNumber } from '../utils/registrationNumber.js';
import { generateQrCodeDataUrl } from '../utils/qr.js';

export async function registerParticipant(req: Request, res: Response): Promise<void> {
  try {
    const { slug } = req.params;
    const {
      firstName,
      lastName,
      phone,
      email,
      birthDate,
      gender,
      parish,
      diocese,
      movement,
      city,
      emergencyContact,
      emergencyPhone,
      customData,
    } = req.body;

    if (!firstName || !lastName || !phone) {
      res.status(400).json({ error: 'Le prénom, le nom et le téléphone sont obligatoires' });
      return;
    }

    // 1. & 2. Récupérer l'événement et son créateur (organisateur)
    const event = await prisma.event.findUnique({
      where: { slug },
      include: {
        user: {
          include: {
            wallet: true,
          },
        },
      },
    });

    if (!event) {
      res.status(404).json({ error: 'Événement introuvable' });
      return;
    }

    if (!event.isActive) {
      res.status(400).json({ error: 'Les inscriptions pour cet événement sont actuellement clôturées ou suspendues' });
      return;
    }

    const organizerWallet = event.user.wallet;
    if (!organizerWallet) {
      res.status(500).json({ error: 'Portefeuille de l\'organisateur introuvable' });
      return;
    }

    // 3. & 4. Vérifier que le solde >= 100 FCFA
    if (organizerWallet.balance < 100) {
      res.status(402).json({
        error: 'Inscriptions temporairement indisponibles : le portefeuille de l\'organisateur ne dispose pas d\'un solde suffisant pour couvrir les frais de service Papyrus (100 FCFA requis).',
        code: 'INSUFFICIENT_WALLET_BALANCE',
      });
      return;
    }

    // Préparation des métadonnées
    const registrationNumber = await generateRegistrationNumber(event.startDate);
    const qrToken = crypto.randomUUID();

    // Contenu du QR Code : le jeton de validation ou URL de contrôle rapide
    const appUrl = process.env.APP_URL || 'http://localhost:5000';
    const qrPayload = JSON.stringify({
      regNo: registrationNumber,
      token: qrToken,
      eventId: event.id,
    });
    const qrCode = await generateQrCodeDataUrl(qrPayload);

    // OPÉRATION ATOMIQUE DANS UNE TRANSACTION PRISMA
    const result = await prisma.$transaction(async (tx) => {
      // Re-vérifier et verrouiller le portefeuille pour éviter toute race condition
      const currentWallet = await tx.wallet.findUnique({
        where: { id: organizerWallet.id },
      });

      if (!currentWallet || currentWallet.balance < 100) {
        throw new Error('INSUFFICIENT_FUNDS');
      }

      // 8. Déduire 100 FCFA du solde de l'organisateur
      const updatedWallet = await tx.wallet.update({
        where: { id: currentWallet.id },
        data: {
          balance: {
            decrement: 100,
          },
        },
      });

      // 9. Créer la transaction Papyrus (-100 FCFA)
      const transactionRef = `TX-FEE-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
      await tx.transaction.create({
        data: {
          userId: event.userId,
          amount: -100,
          type: 'REGISTRATION_FEE',
          status: 'COMPLETED',
          reference: transactionRef,
          paymentMethod: 'SYSTEM',
        },
      });

      // 5. Créer le participant
      const participant = await tx.participant.create({
        data: {
          eventId: event.id,
          registrationNumber,
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          phone: phone.trim(),
          email: email?.trim() || null,
          birthDate: birthDate ? new Date(birthDate) : null,
          gender: gender || null,
          parish: parish?.trim() || null,
          diocese: diocese?.trim() || null,
          movement: movement?.trim() || null,
          city: city?.trim() || null,
          emergencyContact: emergencyContact?.trim() || null,
          emergencyPhone: emergencyPhone?.trim() || null,
          customData: customData ? JSON.stringify(customData) : null,
          qrCode,
          qrToken,
          contributionStatus: event.contributionAmount === 0 ? 'PAID' : 'UNPAID',
          amountPaid: 0,
          isPresent: false,
        },
      });

      // 10. Notification pour l'organisateur
      await tx.notification.create({
        data: {
          userId: event.userId,
          title: `Nouvelle inscription : ${participant.firstName} ${participant.lastName}`,
          message: `Inscrit(e) pour "${event.name}". N° ${registrationNumber}. Frais de service 100 FCFA déduits.`,
          type: 'REGISTRATION',
        },
      });

      // Alerte solde faible si solde <= 200 FCFA (reste 2 inscriptions ou moins)
      if (updatedWallet.balance <= 200) {
        await tx.notification.create({
          data: {
            userId: event.userId,
            title: 'Alerte Solde Faible !',
            message: `Votre solde Papyrus est de ${updatedWallet.balance} FCFA (${Math.floor(updatedWallet.balance / 100)} inscriptions restantes). Rechargez pour éviter l'interruption des inscriptions.`,
            type: 'WARNING',
          },
        });
      }

      return { participant, updatedWallet };
    });

    res.status(201).json({
      message: 'Inscription confirmée !',
      participant: {
        id: result.participant.id,
        registrationNumber: result.participant.registrationNumber,
        firstName: result.participant.firstName,
        lastName: result.participant.lastName,
        phone: result.participant.phone,
        email: result.participant.email,
        parish: result.participant.parish,
        diocese: result.participant.diocese,
        movement: result.participant.movement,
        contributionStatus: result.participant.contributionStatus,
        amountPaid: result.participant.amountPaid,
        qrCode: result.participant.qrCode,
        qrToken: result.participant.qrToken,
        createdAt: result.participant.createdAt,
      },
      event: {
        id: event.id,
        name: event.name,
        slug: event.slug,
        type: event.type,
        startDate: event.startDate,
        location: event.location,
        contributionAmount: event.contributionAmount,
      },
    });
  } catch (error: any) {
    if (error.message === 'INSUFFICIENT_FUNDS') {
      res.status(402).json({
        error: 'Solde insuffisant dans le portefeuille de l\'organisateur (100 FCFA requis).',
        code: 'INSUFFICIENT_WALLET_BALANCE',
      });
      return;
    }

    console.error('Erreur inscription participant:', error);
    res.status(500).json({ error: 'Erreur lors de l\'enregistrement de l\'inscription' });
  }
}

/**
 * Récupérer le billet public / confirmation par numéro d'inscription ou jeton
 */
export async function getPublicTicket(req: Request, res: Response): Promise<void> {
  try {
    const { regNumber } = req.params;

    const participant = await prisma.participant.findFirst({
      where: {
        OR: [
          { registrationNumber: regNumber },
          { qrToken: regNumber },
          { id: regNumber },
        ],
      },
      include: {
        event: {
          select: {
            id: true,
            name: true,
            slug: true,
            type: true,
            startDate: true,
            location: true,
            parish: true,
            diocese: true,
            contributionAmount: true,
          },
        },
      },
    });

    if (!participant) {
      res.status(404).json({ error: 'Billet introuvable' });
      return;
    }

    res.json({ participant });
  } catch (error) {
    console.error('Erreur getPublicTicket:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération du billet' });
  }
}
