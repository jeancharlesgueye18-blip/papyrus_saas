import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import {
  ShieldCheck,
  Users,
  Calendar,
  CreditCard,
  Ban,
  CheckCircle,
  TrendingUp,
  Coins,
  History,
  Lock,
} from 'lucide-react';

export const AdminPage: React.FC = () => {
  const { user } = useAuth();
  const [data, setData] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'dashboard' | 'users' | 'events' | 'transactions' | 'revenue'>('dashboard');

  useEffect(() => {
    loadAdminData();
  }, [tab]);

  const loadAdminData = async () => {
    setLoading(true);
    try {
      if (tab === 'dashboard' || tab === 'revenue') {
        const res = await api.getAdminDashboard();
        setData(res);
      } else if (tab === 'users') {
        const res = await api.getAdminUsers();
        setUsers(res.users || []);
      } else if (tab === 'events') {
        const res = await api.getAdminEvents();
        setEvents(res.events || []);
      } else if (tab === 'transactions') {
        const res = await api.getAdminTransactions();
        setTransactions(res.transactions || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleSuspend = async (targetUserId: string) => {
    try {
      const res = await api.toggleUserSuspension(targetUserId);
      setUsers((prev) =>
        prev.map((u) => (u.id === targetUserId ? { ...u, isSuspended: res.user.isSuspended } : u))
      );
    } catch (err: any) {
      alert(err.message || 'Impossible de modifier le statut');
    }
  };

  if (user?.role !== 'ADMIN') {
    return (
      <div className="text-center py-24 text-slate-500">
        <Lock size={32} className="mx-auto text-rose-500 mb-3" />
        <h2 className="text-lg font-bold text-slate-800">Accès Refusé</h2>
        <p className="text-xs text-slate-400 mt-1">
          Cette zone est strictement réservée aux administrateurs de la plateforme Papyrus.
        </p>
      </div>
    );
  }

  const metrics = data?.metrics || {};

  return (
    <div className="space-y-6 pb-20 animate-fade-in max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-700">
              <ShieldCheck size={20} />
            </span>
            <h1 className="text-2xl font-extrabold text-[#0F2B59]">
              Administration Globale Papyrus
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Supervision de la plateforme, gestion des comptes et revenus du SaaS.
          </p>
        </div>

        {/* ONGLETS */}
        <div className="flex flex-wrap gap-1 bg-white p-1 rounded-2xl border border-slate-200 text-xs font-bold shadow-sm">
          <button
            onClick={() => setTab('dashboard')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              tab === 'dashboard' ? 'bg-[#0F2B59] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Vue d'ensemble
          </button>
          <button
            onClick={() => setTab('users')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              tab === 'users' ? 'bg-[#0F2B59] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Utilisateurs
          </button>
          <button
            onClick={() => setTab('events')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              tab === 'events' ? 'bg-[#0F2B59] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Événements
          </button>
          <button
            onClick={() => setTab('transactions')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              tab === 'transactions' ? 'bg-[#0F2B59] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Transactions
          </button>
          <button
            onClick={() => setTab('revenue')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              tab === 'revenue' ? 'bg-emerald-700 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Revenus SaaS
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-20 text-slate-400 text-sm">
          Chargement des données administratives...
        </div>
      ) : (
        <>
          {/* VUE D'ENSEMBLE OU REVENUS */}
          {(tab === 'dashboard' || tab === 'revenue') && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-3xl bg-white border border-slate-100 shadow-sm">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Organisateurs
                  </span>
                  <div className="text-2xl font-black text-[#0F2B59]">
                    {metrics.totalUsers || 0}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">Comptes enregistrés</div>
                </div>

                <div className="p-5 rounded-3xl bg-white border border-slate-100 shadow-sm">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Événements Créés
                  </span>
                  <div className="text-2xl font-black text-[#0F2B59]">
                    {metrics.totalEvents || 0}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">Toutes catégories confondues</div>
                </div>

                <div className="p-5 rounded-3xl bg-white border border-slate-100 shadow-sm">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Participants Inscrits
                  </span>
                  <div className="text-2xl font-black text-[#0F2B59]">
                    {metrics.totalParticipants || 0}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">Volume de pèlerins & fidèles</div>
                </div>

                <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-800 text-white shadow-md">
                  <span className="text-[10px] font-bold text-emerald-200 uppercase tracking-wider block mb-1">
                    Chiffre d'Affaires Papyrus
                  </span>
                  <div className="text-2xl font-black font-serif-papyrus text-amber-300">
                    {(metrics.papyrusEarnedFees || 0).toLocaleString('fr-FR')} <span className="text-xs font-sans text-slate-100">FCFA</span>
                  </div>
                  <div className="text-[11px] text-emerald-100 mt-1">
                    {metrics.totalParticipants} × 100 FCFA prélevés
                  </div>
                </div>
              </div>

              {/* RAPPEL SUR LES REVENUS ET PACKS VENDUS */}
              <div className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm">
                <h3 className="text-sm font-bold text-[#0F2B59] uppercase tracking-wider mb-4">
                  Bilan Financier Papyrus
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div className="p-4 rounded-2xl bg-slate-50">
                    <span className="text-slate-400 block mb-1">Ventes de Packs (Recharges)</span>
                    <span className="text-lg font-bold text-slate-900 font-serif-papyrus">
                      {(metrics.totalRechargeSales || 0).toLocaleString('fr-FR')} FCFA
                    </span>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50">
                    <span className="text-slate-400 block mb-1">Soldes en Circulation</span>
                    <span className="text-lg font-bold text-slate-900 font-serif-papyrus">
                      {(metrics.totalWalletBalance || 0).toLocaleString('fr-FR')} FCFA
                    </span>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50">
                    <span className="text-slate-400 block mb-1">Crédits d'Inscriptions Restants</span>
                    <span className="text-lg font-bold text-amber-600">
                      {metrics.totalCreditsInCirculation || 0} inscriptions
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ONGLET UTILISATEURS */}
          {tab === 'users' && (
            <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 font-bold text-xs text-[#0F2B59] uppercase tracking-wider">
                Utilisateurs de la plateforme ({users.length})
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase">
                    <tr>
                      <th className="py-3 px-4">Utilisateur</th>
                      <th className="py-3 px-4">Contact</th>
                      <th className="py-3 px-4">Organisation</th>
                      <th className="py-3 px-4">Solde Papyrus</th>
                      <th className="py-3 px-4">Statut</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50/70">
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900">{u.firstName} {u.lastName}</div>
                          <div className="text-[10px] text-slate-400">{u.role}</div>
                        </td>
                        <td className="py-3.5 px-4 text-slate-600">
                          <div>{u.email}</div>
                          <div className="text-[10px] text-slate-400">{u.phone}</div>
                        </td>
                        <td className="py-3.5 px-4 text-slate-600">
                          {u.organization?.name || '-'}
                        </td>
                        <td className="py-3.5 px-4 font-bold text-slate-800">
                          {(u.wallet?.balance || 0).toLocaleString('fr-FR')} FCFA
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              u.isSuspended
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-emerald-50 text-emerald-700'
                            }`}
                          >
                            {u.isSuspended ? 'Suspendu' : 'Actif'}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          {u.role !== 'ADMIN' && (
                            <button
                              onClick={() => handleToggleSuspend(u.id)}
                              className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors ${
                                u.isSuspended
                                  ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                  : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                              }`}
                            >
                              {u.isSuspended ? 'Réactiver' : 'Suspendre'}
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ONGLET ÉVÉNEMENTS */}
          {tab === 'events' && (
            <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 font-bold text-xs text-[#0F2B59] uppercase tracking-wider">
                Événements ({events.length})
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase">
                    <tr>
                      <th className="py-3 px-4">Événement</th>
                      <th className="py-3 px-4">Organisateur</th>
                      <th className="py-3 px-4">Inscrits</th>
                      <th className="py-3 px-4">Cotisation</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Statut</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {events.map((evt) => (
                      <tr key={evt.id} className="hover:bg-slate-50/70">
                        <td className="py-3.5 px-4 font-bold text-slate-900">
                          {evt.name}
                        </td>
                        <td className="py-3.5 px-4 text-slate-600">
                          {evt.user?.firstName} {evt.user?.lastName} ({evt.user?.email})
                        </td>
                        <td className="py-3.5 px-4 font-bold text-slate-800">
                          {evt._count?.participants || 0}
                        </td>
                        <td className="py-3.5 px-4 font-bold text-emerald-700">
                          {evt.contributionAmount.toLocaleString('fr-FR')} FCFA
                        </td>
                        <td className="py-3.5 px-4 text-slate-500">
                          {new Date(evt.startDate).toLocaleDateString('fr-FR')}
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              evt.isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                            }`}
                          >
                            {evt.isActive ? 'Actif' : 'Inactif'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ONGLET TRANSACTIONS */}
          {tab === 'transactions' && (
            <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 font-bold text-xs text-[#0F2B59] uppercase tracking-wider">
                Transactions globales ({transactions.length})
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase">
                    <tr>
                      <th className="py-3 px-4">Référence</th>
                      <th className="py-3 px-4">Utilisateur</th>
                      <th className="py-3 px-4">Type</th>
                      <th className="py-3 px-4">Montant</th>
                      <th className="py-3 px-4">Méthode</th>
                      <th className="py-3 px-4 text-right">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {transactions.map((t) => (
                      <tr key={t.id} className="hover:bg-slate-50/70">
                        <td className="py-3.5 px-4 font-mono text-[11px] text-slate-600">
                          {t.reference}
                        </td>
                        <td className="py-3.5 px-4 text-slate-800 font-medium">
                          {t.user?.firstName} {t.user?.lastName}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-slate-100 text-slate-700">
                            {t.type}
                          </span>
                        </td>
                        <td
                          className={`py-3.5 px-4 font-bold text-sm ${
                            t.amount > 0 ? 'text-emerald-700' : 'text-slate-800'
                          }`}
                        >
                          {t.amount > 0 ? `+${t.amount}` : t.amount} FCFA
                        </td>
                        <td className="py-3.5 px-4 text-slate-500">
                          {t.paymentMethod || 'SYSTEM'}
                        </td>
                        <td className="py-3.5 px-4 text-right text-slate-400">
                          {new Date(t.createdAt).toLocaleString('fr-FR')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
