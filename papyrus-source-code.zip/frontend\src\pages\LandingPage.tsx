import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Sparkles,
  CheckCircle2,
  Share2,
  Users2,
  QrCode,
  ShieldCheck,
  FileSpreadsheet,
  ArrowRight,
  Compass,
  HeartHandshake,
  Church,
  ScrollText,
  BadgeCheck,
  Calculator,
} from 'lucide-react';
import { Logo } from '../components/Logo.js';

export const LandingPage: React.FC = () => {
  const [calcCount, setCalcCount] = useState<number>(350);

  const targetCards = [
    { name: 'JMJ', desc: 'Rassemblements diocésains & nationaux des jeunes', icon: Users2 },
    { name: 'Pèlerinages', desc: 'Popenguine, sanctuaires et grands pèlerinages de foi', icon: Compass },
    { name: 'Marches', desc: 'Marches de Carême, processions et pèlerinages pédestres', icon: ScrollText },
    { name: 'Retraites', desc: 'Sessions spirituelles, récollections paroissiales', icon: Church },
    { name: 'Paroisses', desc: 'Activités et kermesses paroissiales, catéchèses', icon: Church },
    { name: 'Diocèses', desc: 'Événements épiscopaux et coordinations régionales', icon: ShieldCheck },
    { name: 'Mouvements', desc: 'Scouts, Guides, JEC, Renouveau, Légion de Marie', icon: HeartHandshake },
    { name: 'Chorales', desc: 'Concerts de louange, festivals de chant choral', icon: Sparkles },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-amber-100 selection:text-blue-900">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-white via-slate-50 to-blue-50/40 pt-12 pb-20 border-b border-slate-100">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f2b590a_1px,transparent_1px),linear-gradient(to_bottom,#0f2b590a_1px,transparent_1px)] bg-[size:3rem_3rem]"></div>
        
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-50 border border-amber-200/80 text-amber-800 text-xs font-semibold uppercase tracking-wider mb-8 shadow-sm animate-fade-in">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
            Le SaaS simple pour gérer vos événements chrétiens
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold text-[#0F2B59] tracking-tight leading-[1.15] mb-6">
            Organisez vos événements chrétiens{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-600">
              simplement.
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto font-normal leading-relaxed mb-10">
            Centralisez les inscriptions, cotisations et participants de vos événements
            en quelques clics. Fini les listes papier et les pertes d'argent.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/register"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl bg-[#0F2B59] hover:bg-blue-900 text-white font-bold text-base shadow-xl shadow-blue-950/20 hover:scale-[1.02] transition-all"
            >
              <span>Créer mon événement</span>
              <ArrowRight size={18} className="text-amber-400" />
            </Link>
            <Link
              to="/login"
              className="w-full sm:w-auto inline-flex items-center justify-center px-7 py-3.5 rounded-2xl bg-white hover:bg-slate-50 text-[#0F2B59] font-bold text-base border border-slate-200 shadow-sm transition-all"
            >
              Se connecter
            </Link>
          </div>

          {/* Slogan Badge */}
          <div className="mt-12 flex items-center justify-center gap-6 text-xs text-slate-500 font-medium">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={16} className="text-emerald-500" /> Organisez
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={16} className="text-emerald-500" /> Cotisez
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={16} className="text-emerald-500" /> Rassemblez
            </span>
          </div>
        </div>
      </section>

      {/* SECTION : COMMENT ÇA MARCHE ? */}
      <section className="py-20 bg-white border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs font-bold text-amber-600 uppercase tracking-widest mb-2">
              Prise en main en 3 minutes
            </h2>
            <h3 className="text-3xl font-extrabold text-[#0F2B59]">
              Comment ça marche ?
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:border-amber-200 hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-2xl bg-[#0F2B59] text-amber-400 font-bold flex items-center justify-center text-xl mb-6 shadow-md shadow-blue-950/20 group-hover:scale-110 transition-transform">
                1
              </div>
              <h4 className="text-xl font-bold text-[#0F2B59] mb-3">
                Créez votre événement
              </h4>
              <p className="text-slate-600 text-sm leading-relaxed">
                Renseignez le nom, le lieu, la date et le montant de la cotisation demandée aux pèlerins ou participants.
              </p>
            </div>

            <div className="relative p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:border-amber-200 hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white font-bold flex items-center justify-center text-xl mb-6 shadow-md shadow-amber-500/20 group-hover:scale-110 transition-transform">
                2
              </div>
              <h4 className="text-xl font-bold text-[#0F2B59] mb-3">
                Partagez votre lien
              </h4>
              <p className="text-slate-600 text-sm leading-relaxed">
                Votre lien public et votre QR Code sont créés instantanément. Diffusez-les sur WhatsApp, Facebook ou à la paroisse.
              </p>
            </div>

            <div className="relative p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:border-amber-200 hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white font-bold flex items-center justify-center text-xl mb-6 shadow-md shadow-emerald-600/20 group-hover:scale-110 transition-transform">
                3
              </div>
              <h4 className="text-xl font-bold text-[#0F2B59] mb-3">
                Gérez vos participants
              </h4>
              <p className="text-slate-600 text-sm leading-relaxed">
                Suivez les cotisations (Wave, Orange Money, Espèces), scannez les billets à l'entrée et exportez en Excel en un clic.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION : CONÇU POUR LES COMMUNAUTÉS CHRÉTIENNES */}
      <section className="py-20 bg-slate-50 border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs font-bold text-amber-600 uppercase tracking-widest mb-2">
              Adapté à vos réalités de terrain
            </h2>
            <h3 className="text-3xl font-extrabold text-[#0F2B59]">
              Conçu pour les communautés chrétiennes
            </h3>
            <p className="text-slate-600 text-sm mt-3">
              Que vous organisiez un pèlerinage de 10 000 personnes ou une retraite de chorale de 30 membres, Papyrus s'adapte à votre échelle.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {targetCards.map((card) => {
              const Icon = card.icon;
              return (
                <div
                  key={card.name}
                  className="p-5 sm:p-6 rounded-2xl bg-white border border-slate-200/80 hover:border-amber-400 hover:shadow-lg transition-all group"
                >
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0F2B59] group-hover:bg-[#0F2B59] group-hover:text-amber-400 flex items-center justify-center mb-4 transition-colors">
                    <Icon size={20} />
                  </div>
                  <h4 className="text-base font-bold text-[#0F2B59] mb-1">
                    {card.name}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {card.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* SECTION : MODÈLE ÉCONOMIQUE TRANSPARENT (100 FCFA PAR INSCRIPTION) */}
      <section className="py-20 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="rounded-3xl bg-gradient-to-br from-[#0F2B59] via-blue-900 to-[#0A1C3A] text-white p-8 sm:p-14 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

            <div className="relative max-w-2xl mb-10">
              <span className="inline-block px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-xs font-bold uppercase tracking-wider mb-4">
                Tarification Simple & Sans Surprise
              </span>
              <h3 className="text-3xl sm:text-4xl font-extrabold text-white mb-4">
                Seulement 100 FCFA par inscription
              </h3>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                Aucun abonnement mensuel contraignant. Vous ne payez que les frais de service Papyrus lorsque des participants s'inscrivent.
                Les frais Papyrus (100 FCFA) sont <strong className="text-amber-300">totalement indépendants</strong> de la cotisation que vous fixez pour votre événement.
              </p>
            </div>

            {/* Simulateur interactif */}
            <div className="p-6 rounded-2xl bg-white/10 backdrop-blur border border-white/10 mb-8">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
                <div className="flex items-center gap-2 text-amber-400 text-sm font-bold">
                  <Calculator size={18} />
                  <span>Simulateur de coût de service :</span>
                </div>
                <div className="text-2xl font-black text-amber-400 font-serif-papyrus">
                  {(calcCount * 100).toLocaleString('fr-FR')} FCFA
                </div>
              </div>

              <input
                type="range"
                min="50"
                max="2000"
                step="50"
                value={calcCount}
                onChange={(e) => setCalcCount(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer h-2 bg-blue-950/60 rounded-lg"
              />

              <div className="flex justify-between text-xs text-slate-300 mt-2">
                <span>50 participants (5 000 FCFA)</span>
                <span className="font-bold text-white">{calcCount} participants</span>
                <span>2 000 participants (200 000 FCFA)</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <div className="text-amber-400 font-bold text-lg font-serif-papyrus">100 Inscriptions</div>
                <div className="text-white text-xl font-extrabold">10 000 FCFA</div>
                <div className="text-xs text-slate-300 mt-1">Pack Paroisse</div>
              </div>
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <div className="text-amber-400 font-bold text-lg font-serif-papyrus">500 Inscriptions</div>
                <div className="text-white text-xl font-extrabold">50 000 FCFA</div>
                <div className="text-xs text-slate-300 mt-1">Pack Diocèse</div>
              </div>
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <div className="text-amber-400 font-bold text-lg font-serif-papyrus">1 000 Inscriptions</div>
                <div className="text-white text-xl font-extrabold">100 000 FCFA</div>
                <div className="text-xs text-slate-300 mt-1">Pack Grand Rassemblement</div>
              </div>
            </div>

            <div className="mt-8 text-center">
              <Link
                to="/register"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0F2B59] font-bold text-sm shadow-xl transition-all hover:scale-105"
              >
                <span>Commencer maintenant</span>
                <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="mt-auto py-10 bg-slate-900 text-slate-400 border-t border-slate-800 text-xs">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <Logo textColor="text-white" />
          <div className="text-center sm:text-right">
            <p className="text-slate-300 font-medium">
              PAPYRUS — "Organisez. Cotisez. Rassemblez."
            </p>
            <p className="text-slate-500 mt-1">
              Plateforme SaaS dédiée aux paroisses, diocèses et communautés chrétiennes.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};
