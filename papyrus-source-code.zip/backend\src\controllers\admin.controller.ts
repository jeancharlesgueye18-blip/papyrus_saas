import { Response } from 'express';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest } from '../types/index.js';

export async function getAdminDashboard(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const [
      totalUsers,
      totalEvents,
      totalParticipants,
      totalTransactions,
      wallets,
      recentUsers,
      recentTransactions,
      feeTransactions,
      purchaseTransactions,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.event.count(),
      prisma.participant.count(),
      prisma.transaction.count(),
      prisma.wallet.findMany({ select: { balance: true } }),
      prisma.user.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: {
          wallet: true,
          _count: { select: { events: true } },
        },
      }),
      prisma.transaction.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: {
          user: {
            select: { firstName: true, lastName: true, email: true },
          },
        },
      }),
      prisma.transaction.aggregate({
        where: { type: 'REGISTRATION_FEE' },
        _sum: { amount: true },
        _count: true,
      }),
      prisma.transaction.aggregate({
        where: { type: 'CREDIT_PURCHASE' },
        _sum: { amount: true },
        _count: true,
      }),
    ]);

    const totalWalletBalance = wallets.reduce((sum, w) => sum + w.balance, 0);
    const totalCreditsInCirculation = Math.floor(totalWalletBalance / 100);

    // Frais Papyrus collectés : 100 FCFA par participant inscrit
    const papyrusEarnedFees = Math.abs(feeTransactions._sum.amount || 0);
    const totalRechargeSales = purchaseTransactions._sum.amount || 0;

    res.json({
      metrics: {
        totalUsers,
        totalEvents,
        totalParticipants,
        totalTransactions,
        totalWalletBalance,
        totalCreditsInCirculation,
        papyrusEarnedFees,
        totalRechargeSales,
      },
      recentUsers,
      recentTransactions,
    });
  } catch (error) {
    console.error('Erreur getAdminDashboard:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération des statistiques administratives' });
  }
}

export async function getAdminUsers(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const users = await prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        wallet: true,
        organization: true,
        _count: {
          select: {
            events: true,
            transactions: true,
          },
        },
      },
    });

    res.json({ users });
  } catch (error) {
    console.error('Erreur getAdminUsers:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération des utilisateurs' });
  }
}

export async function toggleUserSuspension(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { userId } = req.params;

    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      res.status(404).json({ error: 'Utilisateur introuvable' });
      return;
    }

    if (user.role === 'ADMIN') {
      res.status(400).json({ error: 'Impossible de suspendre un compte administrateur' });
      return;
    }

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: {
        isSuspended: !user.isSuspended,
      },
    });

    res.json({
      message: `Compte ${updatedUser.isSuspended ? 'suspendu' : 'réactivé'} avec succès`,
      user: updatedUser,
    });
  } catch (error) {
    console.error('Erreur toggleUserSuspension:', error);
    res.status(500).json({ error: 'Erreur lors de la mise à jour de la suspension' });
  }
}

export async function getAdminEvents(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const events = await prisma.event.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        user: {
          select: { firstName: true, lastName: true, email: true },
        },
        _count: {
          select: { participants: true },
        },
      },
    });

    res.json({ events });
  } catch (error) {
    console.error('Erreur getAdminEvents:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération des événements' });
  }
}

export async function getAdminTransactions(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const transactions = await prisma.transaction.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        user: {
          select: { firstName: true, lastName: true, email: true },
        },
      },
    });

    res.json({ transactions });
  } catch (error) {
    console.error('Erreur getAdminTransactions:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération des transactions' });
  }
}
