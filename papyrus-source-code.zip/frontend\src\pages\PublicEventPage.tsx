import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../services/api.js';
import { EventItem } from '../types/index.js';
import { Logo } from '../components/Logo.js';
import {
  Calendar,
  MapPin,
  Coins,
  Church,
  User,
  Phone,
  Mail,
  HeartHandshake,
  ShieldAlert,
  ArrowRight,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

export const PublicEventPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const [event, setEvent] = useState<EventItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    birthDate: '',
    gender: 'M',
    parish: '',
    diocese: '',
    movement: '',
    city: 'Dakar',
    emergencyContact: '',
    emergencyPhone: '',
  });

  useEffect(() => {
    if (slug) {
      api.getEventBySlug(slug)
        .then((data) => setEvent(data.event))
        .catch((err) => setError(err.message || 'Événement introuvable'))
        .finally(() => setLoading(false));
    }
  }, [slug]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!slug) return;
    setError(null);
    setSubmitting(true);

    try {
      const res = await api.registerParticipant(slug, formData);
      navigate(`/confirmation/${res.participant.registrationNumber}`);
    } catch (err: any) {
      if (err.code === 'INSUFFICIENT_WALLET_BALANCE' || err.status === 402) {
        setError(
          'Les inscriptions pour cet événement sont temporairement suspendues par l\'organisation. Veuillez réessayer ultérieurement.'
        );
      } else {
        setError(err.message || 'Une erreur est survenue lors de l\'enregistrement de votre inscription.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center text-slate-500 text-sm">
          Chargement de l'événement en cours...
        </div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 text-center">
        <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mb-4">
          <ShieldAlert size={28} />
        </div>
        <h1 className="text-xl font-bold text-slate-800">Événement introuvable</h1>
        <p className="text-xs text-slate-500 mt-1 max-w-sm">
          Cet événement n'existe pas ou a été désactivé par les organisateurs.
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* HEADER PUBLIC DE LA PAGE */}
      <header className="bg-white border-b border-slate-100 py-3 px-4 shadow-sm">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Logo iconSize={20} />
          <span className="text-xs font-semibold text-slate-500">
            Inscription en ligne sécurisée
          </span>
        </div>
      </header>

      <main className="max-w-4xl mx-auto w-full px-4 py-8 space-y-6 flex-1">
        {/* BANNIÈRE DE L'ÉVÉNEMENT */}
        <div className="bg-gradient-to-br from-[#0F2B59] to-blue-950 text-white rounded-3xl p-6 sm:p-10 shadow-xl shadow-blue-950/20 relative overflow-hidden">
          <div className="relative z-10 space-y-4">
            <span className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-400 text-[#0F2B59]">
              {event.type}
            </span>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
              {event.name}
            </h1>
            {event.description && (
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed max-w-2xl">
                {event.description}
              </p>
            )}

            <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 border-t border-white/10 text-xs text-slate-200">
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-amber-400 shrink-0" />
                <span>{event.location}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar size={16} className="text-amber-400 shrink-0" />
                <span>{new Date(event.startDate).toLocaleDateString('fr-FR')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Coins size={16} className="text-amber-400 shrink-0" />
                <span className="font-bold text-amber-300">
                  Cotisation : {event.contributionAmount.toLocaleString('fr-FR')} FCFA
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* FORMULAIRE D'INSCRIPTION */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-100 shadow-xl shadow-slate-200/50">
          <div className="mb-8">
            <h2 className="text-xl font-bold text-[#0F2B59]">
              Formulaire d'Inscription du Participant
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Remplissez les informations ci-dessous pour recevoir votre billet électronique officiel muni de son QR Code.
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-3">
              <AlertCircle size={20} className="shrink-0 text-rose-500" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* 1. ÉTAT CIVIL */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                1. Informations Personnelles
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Prénom *
                  </label>
                  <input
                    type="text"
                    required
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    placeholder="Jean-Baptiste"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Nom *
                  </label>
                  <input
                    type="text"
                    required
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    placeholder="SARR"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Téléphone (WhatsApp) *
                  </label>
                  <input
                    type="tel"
                    required
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+221 77 000 00 00"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="jean.sarr@gmail.com"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Sexe
                  </label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  >
                    <option value="M">Masculin (M)</option>
                    <option value="F">Féminin (F)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* 2. COMMUNAUTÉ CHRÉTIENNE */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                2. Communauté & Origine
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Paroisse
                  </label>
                  <input
                    type="text"
                    name="parish"
                    value={formData.parish}
                    onChange={handleChange}
                    placeholder="Ex : Paroisse Saint-Joseph"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Diocèse
                  </label>
                  <input
                    type="text"
                    name="diocese"
                    value={formData.diocese}
                    onChange={handleChange}
                    placeholder="Ex : Archidiocèse de Dakar"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Groupe / Mouvement
                  </label>
                  <input
                    type="text"
                    name="movement"
                    value={formData.movement}
                    onChange={handleChange}
                    placeholder="Ex : Scouts, Chorale..."
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  />
                </div>
              </div>
            </div>

            {/* 3. CONTACT D'URGENCE */}
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                3. Sécurité & Contact d'Urgence
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Nom du contact d'urgence
                  </label>
                  <input
                    type="text"
                    name="emergencyContact"
                    value={formData.emergencyContact}
                    onChange={handleChange}
                    placeholder="Ex : Parent ou Responsable"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Téléphone d'urgence
                  </label>
                  <input
                    type="tel"
                    name="emergencyPhone"
                    value={formData.emergencyPhone}
                    onChange={handleChange}
                    placeholder="+221 77 000 00 00"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                  />
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100">
              <button
                type="submit"
                disabled={submitting}
                className="w-full flex items-center justify-center gap-2 py-4 px-6 rounded-2xl bg-[#0F2B59] hover:bg-blue-900 text-white font-bold text-base shadow-xl shadow-blue-950/20 transition-all hover:scale-[1.01] disabled:opacity-50"
              >
                <span>{submitting ? 'Validation de votre inscription...' : 'S\'inscrire maintenant'}</span>
                <ArrowRight size={18} className="text-amber-400" />
              </button>
              <p className="text-center text-[11px] text-slate-400 mt-3">
                Un billet officiel avec numéro PAP et QR Code vous sera immédiatement délivré.
              </p>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
};
