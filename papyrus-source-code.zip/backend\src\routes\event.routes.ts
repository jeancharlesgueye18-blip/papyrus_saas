import { Router } from 'express';
import {
  createEvent,
  getEvents,
  getEventById,
  getEventBySlug,
  updateEvent,
  deleteEvent,
} from '../controllers/event.controller.js';
import { authenticateToken } from '../middleware/auth.js';
import { authorizeEvent } from '../middleware/eventAuth.js';

const router = Router();

// Routes publiques
router.get('/public/slug/:slug', getEventBySlug);

// Routes privées protégées
router.use(authenticateToken);

router.post('/', createEvent);
router.get('/', getEvents);
router.get('/:id', authorizeEvent('CHECKER'), getEventById);
router.put('/:id', authorizeEvent('MANAGER'), updateEvent);
router.delete('/:id', authorizeEvent('OWNER'), deleteEvent);

export default router;
