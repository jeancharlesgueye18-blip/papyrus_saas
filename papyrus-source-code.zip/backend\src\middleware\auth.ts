import { Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest, AuthUser } from '../types/index.js';

const JWT_SECRET = process.env.JWT_SECRET || 'papyrus_secret_key_default';

export async function authenticateToken(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    res.status(401).json({ error: 'Accès non autorisé : jeton d\'authentification manquant' });
    return;
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string };

    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        isSuspended: true,
      },
    });

    if (!user) {
      res.status(401).json({ error: 'Utilisateur introuvable' });
      return;
    }

    if (user.isSuspended) {
      res.status(403).json({ error: 'Ce compte a été suspendu par l\'administrateur' });
      return;
    }

    req.user = user as AuthUser;
    next();
  } catch (error) {
    res.status(403).json({ error: 'Jeton invalide ou expiré' });
    return;
  }
}

export function requireAdmin(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): void {
  if (!req.user || req.user.role !== 'ADMIN') {
    res.status(403).json({ error: 'Accès réservé aux administrateurs de Papyrus' });
    return;
  }
  next();
}
