import express, { Express, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

import authRoutes from './routes/auth.routes.js';
import eventRoutes from './routes/event.routes.js';
import registrationRoutes from './routes/registration.routes.js';
import participantRoutes from './routes/participant.routes.js';
import contributionRoutes from './routes/contribution.routes.js';
import walletRoutes from './routes/wallet.routes.js';
import checkinRoutes from './routes/checkin.routes.js';
import exportRoutes from './routes/export.routes.js';
import adminRoutes from './routes/admin.routes.js';
import notificationRoutes from './routes/notification.routes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app: Express = express();

// Middlewares fondamentaux
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health Check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'OK',
    service: 'PAPYRUS API',
    timestamp: new Date().toISOString(),
    slogan: 'Organisez. Cotisez. Rassemblez.',
  });
});

// Enregistrement des routes API REST
app.use('/api/auth', authRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/registrations', registrationRoutes);
app.use('/api/participants', participantRoutes);
app.use('/api/contributions', contributionRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/checkin', checkinRoutes);
app.use('/api/exports', exportRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/notifications', notificationRoutes);

// Servir les fichiers statiques du frontend compilé en production
let frontendDist = path.resolve(__dirname, '../../../frontend/dist');
if (!fs.existsSync(frontendDist)) {
  frontendDist = path.resolve(__dirname, '../../frontend/dist');
}
app.use(express.static(frontendDist));

// Fallback SPA pour toute route non-API
app.get('*', (req: Request, res: Response, next: NextFunction) => {
  if (req.path.startsWith('/api')) {
    return next();
  }
  const indexPath = path.join(frontendDist, 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      // Si le frontend n'est pas encore buildé, renvoyer message JSON
      res.status(200).json({
        message: 'API PAPYRUS en ligne. Le frontend Vite est accessible séparément en développement.',
      });
    }
  });
});

// Middleware global de gestion d'erreur
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  console.error('Erreur API non gérée:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Une erreur interne est survenue sur le serveur Papyrus.',
  });
});

export default app;
