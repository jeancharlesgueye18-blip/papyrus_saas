import { Router } from 'express';
import { getWallet, purchaseCredits } from '../controllers/wallet.controller.js';
import { authenticateToken } from '../middleware/auth.js';

const router = Router();

router.use(authenticateToken);

router.get('/', getWallet);
router.post('/purchase', purchaseCredits);

export default router;
