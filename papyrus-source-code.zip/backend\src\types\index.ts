import { Request } from 'express';

export type UserRole = 'ADMIN' | 'ORGANIZER';
export type StaffRole = 'OWNER' | 'MANAGER' | 'CHECKER';
export type EventType =
  | 'JMJ'
  | 'PELERINAGE'
  | 'MARCHE'
  | 'RETRAITE'
  | 'RASSEMBLEMENT'
  | 'CONFERENCE'
  | 'FORMATION'
  | 'CHORALE'
  | 'AUTRE';

export type ContributionStatus = 'PAID' | 'PARTIAL' | 'UNPAID';
export type PaymentMethod =
  | 'ESPECES'
  | 'WAVE'
  | 'ORANGE_MONEY'
  | 'FREE_MONEY'
  | 'VIREMENT'
  | 'AUTRE'
  | 'SIMULATED'
  | 'SYSTEM';

export type TransactionType = 'CREDIT_PURCHASE' | 'REGISTRATION_FEE' | 'REFUND';

export interface AuthUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  isSuspended: boolean;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

export interface CreditPack {
  id: string;
  name: string;
  price: number; // en FCFA
  credits: number; // nombre d'inscriptions (price / 100)
  popular?: boolean;
}

export const CREDIT_PACKS: CreditPack[] = [
  { id: 'pack-50', name: 'Pack Découverte', price: 5000, credits: 50 },
  { id: 'pack-100', name: 'Pack Paroisse', price: 10000, credits: 100, popular: true },
  { id: 'pack-250', name: 'Pack Mouvement', price: 25000, credits: 250 },
  { id: 'pack-500', name: 'Pack Diocèse', price: 50000, credits: 500 },
  { id: 'pack-1000', name: 'Pack Grand Rassemblement', price: 100000, credits: 1000 },
];
