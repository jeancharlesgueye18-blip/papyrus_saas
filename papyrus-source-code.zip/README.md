# 📜 PAPYRUS

> **"Organisez. Cotisez. Rassemblez."**  
> *Le SaaS simple pour gérer vos événements chrétiens.*

PAPYRUS est une plateforme SaaS Full-Stack tout-en-un conçue pour les paroisses, diocèses, mouvements chrétiens, chorales et organisateurs de pèlerinages, JMJ et retraites. Elle centralise les inscriptions en ligne, la collecte et le suivi des cotisations, la génération automatique de billets munis de QR Codes uniques, le pointage à l'entrée et l'exportation des listes.

---

## 💡 Modèle Économique

- **100 FCFA par inscription** prélevés automatiquement et de manière atomique sur le portefeuille Papyrus de l'organisateur.
- Les frais Papyrus sont **totalement indépendants** de la cotisation demandée aux participants pour l'événement.
- **Packs de rechargement disponibles :**
  - **Pack Découverte** : 5 000 FCFA (50 inscriptions)
  - **Pack Paroisse** : 10 000 FCFA (100 inscriptions)
  - **Pack Mouvement** : 25 000 FCFA (250 inscriptions)
  - **Pack Diocèse** : 50 000 FCFA (500 inscriptions)
  - **Pack Grand Rassemblement** : 100 000 FCFA (1 000 inscriptions)
- **Règle stricte d'intégrité financière :** Si le solde du portefeuille est inférieur à 100 FCFA, l'inscription est refusée (`402 Payment Required`).

---

## 🏗️ Architecture Technique

```
/papyrus
├── /backend            # API REST Node.js + Express + TypeScript
│   └── /src
│       ├── /config     # Connexion Prisma Client singleton
│       ├── /controllers# Logique métier & transactions atomiques
│       ├── /middleware # Authentification JWT, RBAC & isolation des données
│       ├── /routes     # Définition des endpoints API REST
│       ├── /services   # Services métier
│       ├── /types      # Interfaces TypeScript
│       └── /utils      # Générateurs QR Code, N° PAP, Slugs, Exports XLSX/PDF/CSV
├── /frontend           # SPA React 18 + TypeScript + Vite + Tailwind CSS
│   └── /src
│       ├── /components # Navbar, Sidebar, Badges, Modals, Logo
│       ├── /context    # AuthContext & état du portefeuille
│       ├── /pages      # Landing, Dashboard, Événements, Inscription, Caisse, Scanner, Admin
│       ├── /services   # Client HTTP API
│       └── /types      # Interfaces partagées
├── /prisma             # Schéma Prisma, migrations et script de seed
├── /tests              # Tests d'intégration automatisés (Vitest + Supertest)
├── .env.example        # Modèle des variables d'environnement
├── package.json        # Dépendances et scripts monorepo
└── README.md           # Documentation officielle
```

### Stack Technique :
- **Frontend** : React 18, TypeScript, Tailwind CSS, Lucide Icons, Vite, Canvas Confetti
- **Backend** : Node.js (ESM), Express, TypeScript, JWT, BcryptJS, QRCode, XLSX, PDFKit
- **Base de données & ORM** : Prisma ORM (SQLite en local pour zéro friction, PostgreSQL prêt pour la production)
- **Tests** : Vitest, Supertest

---

## 🚀 Démarrage Rapide

### 1. Prérequis
- Node.js version 18+ ou 20+ ou 22+ LTS
- npm ou pnpm

### 2. Cloner et installer les dépendances
```bash
# Cloner le dépôt
cd papyrus

# Installer les dépendances du backend & des outils
npm install

# Installer les dépendances du frontend
cd frontend
npm install
cd ..
```

### 3. Configuration des variables d'environnement
Copiez `.env.example` en `.env` :
```bash
cp .env.example .env
```
Contenu par défaut dans `.env` :
```env
DATABASE_URL="file:./dev.db"
JWT_SECRET="papyrus_jwt_super_secret_key_faith_tech_2027_secure_token"
SESSION_SECRET="papyrus_session_super_secret_sign_key_987654321"
PORT=5000
APP_URL="http://localhost:5000"
FRONTEND_URL="http://localhost:5173"
NODE_ENV="development"
```

### 4. Base de données & Amorçage (Seed)
Initialisez la base de données et peuplez les données de démonstration :
```bash
# Générer le client Prisma et synchroniser les tables
npm run prisma:generate
npm run prisma:migrate

# Exécuter le seed de démonstration
npm run seed
```

#### Identifiants préconfigurés pour tester l'application :
| Rôle | Email | Mot de passe | Description |
| :--- | :--- | :--- | :--- |
| **Organisateur Démo** | `demo@papyrus.sn` | `Papyrus2027!` | Abbé Paul Ndiaye (Solde : 47 600 FCFA, 3 événements, 24 participants) |
| **Administrateur** | `admin@papyrus.sn` | `Admin2027!` | Supervision globale, modération, audit des revenus et transactions |

### 5. Lancement de l'application
Vous pouvez lancer le backend et le frontend :

```bash
# Option A : Mode développement complet
npm run dev:backend       # Lance l'API sur http://localhost:5000
npm run dev:frontend      # Dans un autre terminal : Lance Vite sur http://localhost:5173

# Option B : Mode production unifié
npm run build             # Compile le frontend et le backend
npm start                 # Lance l'application complète sur http://localhost:5000
```

---

## 🧪 Exécution des Tests Automatisés

Une suite complète de 12 tests d'intégration valide les fonctionnalités critiques :
```bash
npm test
```

### Scénarios testés :
1. Création de compte organisateur et vérification du portefeuille initial (0 FCFA).
2. Recharge de portefeuille (+10 000 FCFA avec le Pack Paroisse).
3. Création d'événement (JMJ Dakar Test, cotisation 5 000 FCFA).
4. Consultation publique de l'événement sans authentification (`/api/events/public/slug/:slug`).
5. **Inscription publique d'un participant avec prélèvement atomique de 100 FCFA** et vérification de la transaction.
6. Enregistrement d'une cotisation financière de 5 000 FCFA (Wave / Orange Money).
7. Contrôle d'accès et scan QR Code (Check-in & blocage des doubles scans).
8. **Test Critique de solde insuffisant** : Portefeuille à 100 FCFA -> Inscription 1 acceptée -> Solde passe à 0 FCFA -> Inscription 2 strictement refusée (`402 Payment Required`).
9. **Isolation des données** : Un organisateur A ne peut jamais accéder aux participants d'un organisateur B (`403 Forbidden`).
10. Génération dynamique des listes catégorisées (par paroisse, diocèse, cotisants, présents).
11. Exportations des données en Excel (.xlsx), CSV et PDF officiel.
12. Dashboard de supervision Super-Administrateur (`/api/admin`).

---

## 🐘 Déploiement en Production avec PostgreSQL

Pour déployer PAPYRUS sur un serveur de production (Render, Railway, Supabase, Neon, AWS) avec PostgreSQL :

1. Modifiez le provider dans `prisma/schema.prisma` :
```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

2. Configurez votre variable `DATABASE_URL` dans les paramètres d'environnement de production :
```env
DATABASE_URL="postgresql://user:password@host:5432/papyrus_db?schema=public"
```

3. Exécutez les migrations :
```bash
npx prisma migrate deploy
npm run seed
```

---

## 🔒 Sécurité & Bonnes Pratiques
- **Isolation stricte** : Contrôle systématique du propriétaire et des rôles d'équipe (`OWNER`, `MANAGER`, `CHECKER`).
- **Transactions atomiques PostgreSQL / Prisma** : Prévention garantie contre les anomalies de prélèvement.
- **Hachage des mots de passe** : Bcrypt avec salt de facteur 10.
- **Protection des billets** : Jeton cryptographique UUID unique encodé dans le QR Code pour empêcher toute contrefaçon de billet.

---

## 📄 Licence
Propriété de la plateforme PAPYRUS. Tous droits réservés.
