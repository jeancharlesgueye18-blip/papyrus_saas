import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { EventItem } from '../types/index.js';
import {
  Calendar,
  PlusCircle,
  Search,
  QrCode,
  Share2,
  ArrowUpRight,
  MapPin,
  Clock,
  Filter,
} from 'lucide-react';

export const EventsListPage: React.FC = () => {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('ALL');

  useEffect(() => {
    api.getEvents()
      .then((data) => setEvents(data.events || []))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  const filteredEvents = events.filter((e) => {
    const matchSearch =
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.location.toLowerCase().includes(search.toLowerCase());
    const matchType = filterType === 'ALL' || e.type === filterType;
    return matchSearch && matchType;
  });

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F2B59]">
            Événements
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Gérez tous vos rassemblements chrétiens, pèlerinages et activités.
          </p>
        </div>

        <Link
          to="/events/new"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white font-bold text-xs sm:text-sm shadow-md transition-all hover:scale-[1.02]"
        >
          <PlusCircle size={18} className="text-amber-400" />
          <span>Créer un événement</span>
        </Link>
      </div>

      {/* RECHERCHE ET FILTRES */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={18} className="absolute inset-y-0 left-3.5 my-auto text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher par nom, lieu..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-white"
          />
        </div>

        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="px-4 py-2.5 rounded-xl border border-slate-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
        >
          <option value="ALL">Tous les types</option>
          <option value="JMJ">JMJ</option>
          <option value="PELERINAGE">Pèlerinage</option>
          <option value="MARCHE">Marche</option>
          <option value="RETRAITE">Retraite</option>
          <option value="CHORALE">Chorale</option>
          <option value="AUTRE">Autre</option>
        </select>
      </div>

      {/* LISTE DES CARTES */}
      {loading ? (
        <div className="text-center py-16 text-slate-400 text-sm">
          Chargement de vos événements...
        </div>
      ) : filteredEvents.length === 0 ? (
        <div className="text-center py-16 px-4 bg-white rounded-3xl border border-dashed border-slate-200">
          <Calendar size={32} className="mx-auto text-slate-300 mb-3" />
          <h3 className="text-sm font-bold text-slate-800">Aucun événement trouvé</h3>
          <p className="text-xs text-slate-400 mt-1">
            Modifiez vos filtres ou créez votre premier événement.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredEvents.map((evt) => (
            <div
              key={evt.id}
              className="bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-[#0F2B59]">
                    {evt.type}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      evt.isActive
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {evt.isActive ? 'Actif' : 'Clôturé'}
                  </span>
                </div>

                <h3 className="text-base font-bold text-[#0F2B59] line-clamp-1">
                  {evt.name}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-2">
                  <MapPin size={14} className="text-slate-400 shrink-0" />
                  <span className="truncate">{evt.location}</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                  <Clock size={14} className="text-slate-400 shrink-0" />
                  <span>{new Date(evt.startDate).toLocaleDateString('fr-FR')}</span>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-50 grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px] font-semibold uppercase">
                      Inscrits
                    </span>
                    <span className="font-bold text-slate-800 text-sm">
                      {evt.stats?.totalParticipants || 0}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] font-semibold uppercase">
                      Cotisation
                    </span>
                    <span className="font-bold text-emerald-700 text-sm">
                      {evt.contributionAmount.toLocaleString('fr-FR')} F
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                <Link
                  to={`/events/${evt.id}`}
                  className="flex-1 text-center py-2 px-3 rounded-xl bg-slate-100 hover:bg-[#0F2B59] hover:text-white text-[#0F2B59] font-bold text-xs transition-colors"
                >
                  Tableau de bord
                </Link>

                <Link
                  to={`/events/${evt.id}/check-in`}
                  className="p-2 rounded-xl bg-amber-50 text-amber-700 hover:bg-amber-100 transition-colors"
                  title="Scanner"
                >
                  <QrCode size={18} />
                </Link>

                <Link
                  to={`/events/${evt.id}/share`}
                  className="p-2 rounded-xl bg-blue-50 text-[#0F2B59] hover:bg-blue-100 transition-colors"
                  title="Partager"
                >
                  <Share2 size={18} />
                </Link>

                <Link
                  to={`/e/${evt.slug}`}
                  target="_blank"
                  className="p-2 rounded-xl bg-slate-50 text-slate-600 hover:text-slate-900 transition-colors"
                  title="Lien public"
                >
                  <ArrowUpRight size={18} />
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
