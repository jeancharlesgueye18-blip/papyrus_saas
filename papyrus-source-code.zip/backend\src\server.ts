import dotenv from 'dotenv';
dotenv.config();

import { app } from './app.js';
import prisma from './config/prisma.js';

const PORT = process.env.PORT || 5000;

async function startServer() {
  try {
    // Vérifier la connexion base de données
    await prisma.$connect();
    console.log('✅ Base de données connectée avec succès.');

    app.listen(PORT, () => {
      console.log(`
============================================================
🕊️  PAPYRUS - Serveur SaaS Démarré
============================================================
  Portail API  : http://localhost:${PORT}/api/health
  URL Globale  : http://localhost:${PORT}
  Slogan       : "Organisez. Cotisez. Rassemblez."
============================================================
      `);
    });
  } catch (error) {
    console.error('❌ Impossible de démarrer le serveur Papyrus:', error);
    process.exit(1);
  }
}

startServer();
