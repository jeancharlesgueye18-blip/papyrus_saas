import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Calendar,
  Users,
  Coins,
  QrCode,
  Wallet,
  ShieldCheck,
  PlusCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';

export const Sidebar: React.FC = () => {
  const { user } = useAuth();

  const navItems = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/events', label: 'Événements', icon: Calendar },
    { to: '/billing', label: 'Crédits', icon: Wallet },
  ];

  if (user?.role === 'ADMIN') {
    navItems.push({ to: '/admin', label: 'Admin', icon: ShieldCheck });
  }

  return (
    <>
      {/* DESKTOP SIDEBAR */}
      <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-slate-100 min-h-[calc(100vh-4rem)] p-4 shrink-0">
        <div className="space-y-1 mb-6">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-50 to-amber-50/50 text-[#0F2B59] font-bold border-l-4 border-amber-500 shadow-sm'
                      : 'text-slate-600 hover:text-[#0F2B59] hover:bg-slate-50'
                  }`
                }
              >
                <Icon size={18} className="shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </div>

        {/* Encadré Portefeuille rapide */}
        <div className="mt-auto p-4 rounded-2xl bg-gradient-to-br from-[#0F2B59] to-blue-950 text-white shadow-lg shadow-blue-950/20">
          <div className="flex items-center justify-between text-xs text-amber-400 font-semibold mb-1">
            <span className="uppercase tracking-wider">Solde Papyrus</span>
            <span className="text-[10px] bg-amber-400/20 px-1.5 py-0.5 rounded text-amber-300">
              100 F / insc.
            </span>
          </div>
          <div className="text-xl font-bold font-serif-papyrus text-white">
            {(user?.wallet?.balance || 0).toLocaleString('fr-FR')} FCFA
          </div>
          <div className="text-xs text-slate-300 mt-1 flex items-center justify-between">
            <span>Inscriptions :</span>
            <span className="font-bold text-amber-300">
              {Math.floor((user?.wallet?.balance || 0) / 100)} disponibles
            </span>
          </div>
          <NavLink
            to="/billing"
            className="mt-3 block w-full text-center py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0F2B59] text-xs font-bold transition-all shadow-sm"
          >
            Recharger mes crédits
          </NavLink>
        </div>
      </aside>

      {/* MOBILE BOTTOM NAVIGATION (Section 32 Mobile First) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur border-t border-slate-200 py-2 px-4 shadow-lg flex items-center justify-around">
        <NavLink
          to="/dashboard"
          className={({ isActive }) =>
            `flex flex-col items-center gap-1 text-[10px] font-semibold transition-colors ${
              isActive ? 'text-[#0F2B59]' : 'text-slate-500'
            }`
          }
        >
          <LayoutDashboard size={20} />
          <span>Dashboard</span>
        </NavLink>

        <NavLink
          to="/events"
          className={({ isActive }) =>
            `flex flex-col items-center gap-1 text-[10px] font-semibold transition-colors ${
              isActive ? 'text-[#0F2B59]' : 'text-slate-500'
            }`
          }
        >
          <Calendar size={20} />
          <span>Événements</span>
        </NavLink>

        <NavLink
          to="/events/new"
          className="flex flex-col items-center -mt-5"
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#0F2B59] to-blue-800 text-amber-400 flex items-center justify-center shadow-lg border-2 border-white">
            <PlusCircle size={24} />
          </div>
          <span className="text-[10px] font-bold text-[#0F2B59] mt-0.5">Créer</span>
        </NavLink>

        <NavLink
          to="/billing"
          className={({ isActive }) =>
            `flex flex-col items-center gap-1 text-[10px] font-semibold transition-colors ${
              isActive ? 'text-[#0F2B59]' : 'text-slate-500'
            }`
          }
        >
          <Wallet size={20} />
          <span>Crédits</span>
        </NavLink>

        {user?.role === 'ADMIN' && (
          <NavLink
            to="/admin"
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 text-[10px] font-semibold transition-colors ${
                isActive ? 'text-[#0F2B59]' : 'text-slate-500'
              }`
            }
          >
            <ShieldCheck size={20} />
            <span>Admin</span>
          </NavLink>
        )}
      </nav>
    </>
  );
};
