import { Response } from 'express';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest } from '../types/index.js';
import {
  formatParticipantsForExport,
  generateExcelBuffer,
  generateCsvBuffer,
  generatePdfDoc,
} from '../utils/export.js';

export async function exportEventData(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params; // eventId
    const { format = 'xlsx', type = 'general', parish, diocese } = req.query;

    const event = await prisma.event.findUnique({
      where: { id },
    });

    if (!event) {
      res.status(404).json({ error: 'Événement non trouvé' });
      return;
    }

    const where: any = { eventId: id };

    let sheetTitle = 'Liste Générale';
    if (type === 'parish') {
      if (parish) where.parish = parish as string;
      sheetTitle = parish ? `Paroisse - ${parish}` : 'Par Paroisses';
    } else if (type === 'diocese') {
      if (diocese) where.diocese = diocese as string;
      sheetTitle = diocese ? `Diocèse - ${diocese}` : 'Par Diocèses';
    } else if (type === 'contributions') {
      where.contributionStatus = 'PAID';
      sheetTitle = 'Liste des Cotisants';
    } else if (type === 'unpaid') {
      where.contributionStatus = { in: ['UNPAID', 'PARTIAL'] };
      sheetTitle = 'Liste des Non-Cotisants';
    } else if (type === 'presence') {
      where.isPresent = true;
      sheetTitle = 'Liste des Présents';
    } else if (type === 'absent') {
      where.isPresent = false;
      sheetTitle = 'Liste des Absents';
    }

    const participants = await prisma.participant.findMany({
      where,
      orderBy: [{ lastName: 'asc' }, { firstName: 'asc' }],
    });

    const formattedData = formatParticipantsForExport(participants);
    const dateStr = new Date().toISOString().split('T')[0];
    const safeSlug = event.slug;

    if (format === 'csv') {
      const buffer = generateCsvBuffer(formattedData);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="papyrus-${safeSlug}-${type}-${dateStr}.csv"`
      );
      res.send(buffer);
      return;
    }

    if (format === 'pdf') {
      const eventInfo = {
        name: event.name,
        date: new Date(event.startDate).toLocaleDateString('fr-FR'),
        location: event.location,
      };
      const buffer = await generatePdfDoc(sheetTitle, eventInfo, formattedData);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="papyrus-${safeSlug}-${type}-${dateStr}.pdf"`
      );
      res.send(buffer);
      return;
    }

    // Par défaut : Excel XLSX
    const buffer = generateExcelBuffer(formattedData, sheetTitle);
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="papyrus-${safeSlug}-${type}-${dateStr}.xlsx"`
    );
    res.send(buffer);
  } catch (error) {
    console.error('Erreur exportEventData:', error);
    res.status(500).json({ error: 'Erreur lors de l\'exportation des données' });
  }
}
