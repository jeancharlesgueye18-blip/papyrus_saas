import { Response } from 'express';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest } from '../types/index.js';

export async function getParticipants(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params; // eventId
    const {
      search,
      parish,
      diocese,
      movement,
      contributionStatus,
      isPresent,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      page = '1',
      limit = '50',
    } = req.query;

    const pageNum = Math.max(1, parseInt(page as string, 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(limit as string, 10) || 50));
    const skip = (pageNum - 1) * limitNum;

    // Construction du filtre Prisma
    const where: any = { eventId: id };

    if (search) {
      const q = (search as string).trim();
      where.OR = [
        { firstName: { contains: q } },
        { lastName: { contains: q } },
        { phone: { contains: q } },
        { registrationNumber: { contains: q } },
        { email: { contains: q } },
      ];
    }

    if (parish) where.parish = parish as string;
    if (diocese) where.diocese = diocese as string;
    if (movement) where.movement = movement as string;
    if (contributionStatus) where.contributionStatus = contributionStatus as string;
    if (isPresent !== undefined) where.isPresent = isPresent === 'true';

    const [participants, totalCount] = await Promise.all([
      prisma.participant.findMany({
        where,
        skip,
        take: limitNum,
        orderBy: {
          [sortBy as string]: sortOrder === 'asc' ? 'asc' : 'desc',
        },
        include: {
          contributions: {
            orderBy: { createdAt: 'desc' },
          },
        },
      }),
      prisma.participant.count({ where }),
    ]);

    res.json({
      participants,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalCount,
        totalPages: Math.ceil(totalCount / limitNum),
      },
    });
  } catch (error) {
    console.error('Erreur getParticipants:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération des participants' });
  }
}

export async function getParticipantById(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { participantId } = req.params;

    const participant = await prisma.participant.findUnique({
      where: { id: participantId },
      include: {
        event: true,
        contributions: { orderBy: { createdAt: 'desc' } },
        checkIns: { orderBy: { checkedInAt: 'desc' } },
      },
    });

    if (!participant) {
      res.status(404).json({ error: 'Participant introuvable' });
      return;
    }

    res.json({ participant });
  } catch (error) {
    console.error('Erreur getParticipantById:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération du participant' });
  }
}

export async function updateParticipant(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { participantId } = req.params;
    const {
      firstName,
      lastName,
      phone,
      email,
      birthDate,
      gender,
      parish,
      diocese,
      movement,
      city,
      emergencyContact,
      emergencyPhone,
    } = req.body;

    const participant = await prisma.participant.update({
      where: { id: participantId },
      data: {
        firstName,
        lastName,
        phone,
        email,
        birthDate: birthDate ? new Date(birthDate) : undefined,
        gender,
        parish,
        diocese,
        movement,
        city,
        emergencyContact,
        emergencyPhone,
      },
    });

    res.json({ message: 'Participant mis à jour', participant });
  } catch (error) {
    console.error('Erreur updateParticipant:', error);
    res.status(500).json({ error: 'Erreur lors de la modification du participant' });
  }
}

export async function deleteParticipant(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { participantId } = req.params;

    await prisma.participant.delete({
      where: { id: participantId },
    });

    res.json({ message: 'Participant supprimé avec succès' });
  } catch (error) {
    console.error('Erreur deleteParticipant:', error);
    res.status(500).json({ error: 'Erreur lors de la suppression du participant' });
  }
}

/**
 * Listes automatiques générées dynamiquement (Section 17)
 */
export async function getCategoryLists(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params; // eventId

    const allParticipants = await prisma.participant.findMany({
      where: { eventId: id },
      orderBy: { lastName: 'asc' },
    });

    // 1. Groupements par paroisse
    const byParish: Record<string, typeof allParticipants> = {};
    // 2. Groupements par diocèse
    const byDiocese: Record<string, typeof allParticipants> = {};
    // 3. Groupements par groupe / mouvement
    const byMovement: Record<string, typeof allParticipants> = {};

    const cotisants: typeof allParticipants = [];
    const nonCotisants: typeof allParticipants = [];
    const presents: typeof allParticipants = [];
    const absents: typeof allParticipants = [];

    allParticipants.forEach((p) => {
      // Paroisse
      const parishKey = p.parish || 'Non spécifiée';
      if (!byParish[parishKey]) byParish[parishKey] = [];
      byParish[parishKey].push(p);

      // Diocèse
      const dioceseKey = p.diocese || 'Non spécifié';
      if (!byDiocese[dioceseKey]) byDiocese[dioceseKey] = [];
      byDiocese[dioceseKey].push(p);

      // Mouvement / Groupe
      const movementKey = p.movement || 'Général / Aucun';
      if (!byMovement[movementKey]) byMovement[movementKey] = [];
      byMovement[movementKey].push(p);

      // Statut Cotisation
      if (p.contributionStatus === 'PAID') {
        cotisants.push(p);
      } else {
        nonCotisants.push(p);
      }

      // Statut Présence
      if (p.isPresent) {
        presents.push(p);
      } else {
        absents.push(p);
      }
    });

    res.json({
      summary: {
        total: allParticipants.length,
        cotisantsCount: cotisants.length,
        nonCotisantsCount: nonCotisants.length,
        presentsCount: presents.length,
        absentsCount: absents.length,
        parishesCount: Object.keys(byParish).length,
        diocesesCount: Object.keys(byDiocese).length,
        movementsCount: Object.keys(byMovement).length,
      },
      lists: {
        byParish,
        byDiocese,
        byMovement,
        cotisants,
        nonCotisants,
        presents,
        absents,
      },
    });
  } catch (error) {
    console.error('Erreur getCategoryLists:', error);
    res.status(500).json({ error: 'Erreur lors de la génération des listes dynamiques' });
  }
}
