import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import QRCode from 'qrcode';

const prisma = new PrismaClient();

async function generateQr(payload: string): Promise<string> {
  return QRCode.toDataURL(payload, {
    margin: 2,
    width: 250,
    color: { dark: '#0F2B59', light: '#FFFFFF' },
  });
}

async function main() {
  console.log('🌱 Amorçage des données Papyrus...');

  // Nettoyage préalable si nécessaire
  await prisma.notification.deleteMany();
  await prisma.checkIn.deleteMany();
  await prisma.contribution.deleteMany();
  await prisma.participant.deleteMany();
  await prisma.eventField.deleteMany();
  await prisma.eventStaff.deleteMany();
  await prisma.transaction.deleteMany();
  await prisma.wallet.deleteMany();
  await prisma.event.deleteMany();
  await prisma.user.deleteMany();
  await prisma.organization.deleteMany();

  const salt = await bcrypt.genSalt(10);
  const demoPassword = await bcrypt.hash('Papyrus2027!', salt);
  const adminPassword = await bcrypt.hash('Admin2027!', salt);

  // 1. Création d'organisations
  const orgDakar = await prisma.organization.create({
    data: {
      name: 'Archidiocèse de Dakar',
      type: 'DIOCESE',
      diocese: 'Archidiocèse de Dakar',
      city: 'Dakar',
    },
  });

  const orgParoisse = await prisma.organization.create({
    data: {
      name: 'Paroisse Saint-Joseph de Médina',
      type: 'PAROISSE',
      diocese: 'Archidiocèse de Dakar',
      city: 'Dakar',
    },
  });

  // 2. Création de l'Administrateur
  const adminUser = await prisma.user.create({
    data: {
      firstName: 'Admin',
      lastName: 'PAPYRUS',
      email: 'admin@papyrus.sn',
      phone: '+221 77 000 00 00',
      password: adminPassword,
      role: 'ADMIN',
      organizationId: orgDakar.id,
    },
  });

  await prisma.wallet.create({
    data: {
      userId: adminUser.id,
      balance: 1000000,
    },
  });

  // 3. Création du compte Démo Organisateur
  const demoUser = await prisma.user.create({
    data: {
      firstName: 'Abbé Paul',
      lastName: 'NDIAYE',
      email: 'demo@papyrus.sn',
      phone: '+221 77 123 45 67',
      password: demoPassword,
      role: 'ORGANIZER',
      organizationId: orgParoisse.id,
    },
  });

  // Portefeuille démo : 50 000 FCFA (500 inscriptions)
  const demoWallet = await prisma.wallet.create({
    data: {
      userId: demoUser.id,
      balance: 50000,
    },
  });

  // Transaction initiale de recharge
  await prisma.transaction.create({
    data: {
      userId: demoUser.id,
      amount: 50000,
      type: 'CREDIT_PURCHASE',
      status: 'COMPLETED',
      reference: 'TX-PACK-INIT-50000',
      paymentMethod: 'WAVE',
      packName: 'Pack Diocèse (500 inscriptions)',
    },
  });

  // 4. Événements
  const jmjQr = await generateQr('http://localhost:5000/e/jmj-dakar-2027');
  const popenguineQr = await generateQr('http://localhost:5000/e/pelerinage-popenguine');
  const marcheQr = await generateQr('http://localhost:5000/e/marche-diocesaine');

  const jmjEvent = await prisma.event.create({
    data: {
      userId: demoUser.id,
      name: 'JMJ Dakar 2027',
      slug: 'jmj-dakar-2027',
      type: 'JMJ',
      description: 'Journées Mondiales de la Jeunesse diocésaines à Dakar. Rassemblement fraternel de tous les jeunes chrétiens.',
      startDate: new Date('2027-04-10T08:00:00Z'),
      endDate: new Date('2027-04-12T18:00:00Z'),
      location: 'Grand Théâtre National / Stade Iba Mar Diop, Dakar',
      parish: 'Cathédrale de Dakar',
      diocese: 'Archidiocèse de Dakar',
      contributionAmount: 5000,
      contributionType: 'FIXED',
      isActive: true,
      qrCode: jmjQr,
    },
  });

  const popenguineEvent = await prisma.event.create({
    data: {
      userId: demoUser.id,
      name: 'Pèlerinage Marial de Popenguine',
      slug: 'pelerinage-popenguine',
      type: 'PELERINAGE',
      description: 'Grand pèlerinage annuel au sanctuaire marial de Popenguine. Marche, prière et célébrations mariales.',
      startDate: new Date('2027-05-24T06:00:00Z'),
      endDate: new Date('2027-05-25T17:00:00Z'),
      location: 'Sanctuaire Marial de Popenguine',
      diocese: 'Archidiocèse de Dakar',
      contributionAmount: 2500,
      contributionType: 'FIXED',
      isActive: true,
      qrCode: popenguineQr,
    },
  });

  const marcheEvent = await prisma.event.create({
    data: {
      userId: demoUser.id,
      name: 'Grande Marche Diocésaine de Carême',
      slug: 'marche-diocesaine',
      type: 'MARCHE',
      description: 'Marche pénitentielle diocésaine rassemblant les chorales, mouvements et fidèles.',
      startDate: new Date('2027-03-21T06:30:00Z'),
      endDate: new Date('2027-03-21T14:00:00Z'),
      location: 'Départ Paroisse Martyrs de l\'Ouganda',
      diocese: 'Archidiocèse de Dakar',
      contributionAmount: 1000,
      contributionType: 'FIXED',
      isActive: true,
      qrCode: marcheQr,
    },
  });

  // 5. Participants pour JMJ Dakar 2027 (24 participants réalistes)
  const parishes = [
    'Saint-Joseph de Médina',
    'Cathédrale du Souvenir Africain',
    'Sainte-Thérèse de Grand-Dakar',
    'Saint-Pierre des Baobabs',
    'Martyrs de l\'Ouganda',
    'Sacré-Cœur',
    'Saint-Paul de Grand Yoff',
  ];

  const dioceses = [
    'Archidiocèse de Dakar',
    'Diocèse de Thiès',
    'Diocèse de Kaolack',
    'Diocèse de Ziguinchor',
  ];

  const movements = [
    'Scouts du Sénégal',
    'Guides du Sénégal',
    'Jeunesse Étudiante Chrétienne (JEC)',
    'Chorale Sainte Cécile',
    'CVAV',
    'Légion de Marie',
    'Renouveau Charismatique',
  ];

  const sampleParticipants = [
    { first: 'Jean-Baptiste', last: 'SARR', phone: '+221 77 201 10 20', gender: 'M', city: 'Dakar', status: 'PAID', amount: 5000, present: true },
    { first: 'Marie-Madeleine', last: 'DIOP', phone: '+221 78 312 45 60', gender: 'F', city: 'Thiès', status: 'PAID', amount: 5000, present: true },
    { first: 'Augustin', last: 'MENDY', phone: '+221 76 450 78 90', gender: 'M', city: 'Dakar', status: 'PAID', amount: 5000, present: false },
    { first: 'Bernadette', last: 'GOMIS', phone: '+221 77 560 12 34', gender: 'F', city: 'Rufisque', status: 'PARTIAL', amount: 3000, present: false },
    { first: 'François-Xavier', last: 'FAYE', phone: '+221 70 890 23 45', gender: 'M', city: 'Dakar', status: 'PAID', amount: 5000, present: true },
    { first: 'Thérèse', last: 'SENE', phone: '+221 77 654 98 12', gender: 'F', city: 'Kaolack', status: 'UNPAID', amount: 0, present: false },
    { first: 'Michel', last: 'COLY', phone: '+221 78 111 22 33', gender: 'M', city: 'Ziguinchor', status: 'PAID', amount: 5000, present: true },
    { first: 'Véronique', last: 'BASSENE', phone: '+221 76 222 33 44', gender: 'F', city: 'Dakar', status: 'PAID', amount: 5000, present: false },
    { first: 'Joseph', last: 'DIOUF', phone: '+221 77 333 44 55', gender: 'M', city: 'Mbour', status: 'PARTIAL', amount: 2500, present: false },
    { first: 'Clara', last: 'MANGA', phone: '+221 78 444 55 66', gender: 'F', city: 'Dakar', status: 'PAID', amount: 5000, present: true },
    { first: 'Daniel', last: 'SAMBOU', phone: '+221 70 555 66 77', gender: 'M', city: 'Thiès', status: 'UNPAID', amount: 0, present: false },
    { first: 'Antoinette', last: 'BADJI', phone: '+221 77 666 77 88', gender: 'F', city: 'Dakar', status: 'PAID', amount: 5000, present: false },
    { first: 'Gabriel', last: 'TAVAREZ', phone: '+221 78 777 88 99', gender: 'M', city: 'Dakar', status: 'PAID', amount: 5000, present: true },
    { first: 'Élisabeth', last: 'DA SILVA', phone: '+221 76 888 99 00', gender: 'F', city: 'Rufisque', status: 'PAID', amount: 5000, present: true },
    { first: 'Dominique', last: 'NDECKY', phone: '+221 77 999 00 11', gender: 'M', city: 'Dakar', status: 'UNPAID', amount: 0, present: false },
    { first: 'Rose', last: 'SANYA', phone: '+221 78 000 11 22', gender: 'F', city: 'Kaolack', status: 'PARTIAL', amount: 2000, present: false },
    { first: 'Blaise', last: 'CORREA', phone: '+221 70 123 32 10', gender: 'M', city: 'Ziguinchor', status: 'PAID', amount: 5000, present: true },
    { first: 'Monique', last: 'DIATTA', phone: '+221 77 234 43 21', gender: 'F', city: 'Dakar', status: 'PAID', amount: 5000, present: false },
    { first: 'Pascal', last: 'SAGNA', phone: '+221 78 345 54 32', gender: 'M', city: 'Thiès', status: 'UNPAID', amount: 0, present: false },
    { first: 'Jeanne', last: 'MANE', phone: '+221 76 456 65 43', gender: 'F', city: 'Dakar', status: 'PAID', amount: 5000, present: true },
    { first: 'Simon', last: 'BOISSY', phone: '+221 77 567 76 54', gender: 'M', city: 'Dakar', status: 'PAID', amount: 5000, present: true },
    { first: 'Hélène', last: 'PREIRA', phone: '+221 78 678 87 65', gender: 'F', city: 'Mbour', status: 'UNPAID', amount: 0, present: false },
    { first: 'Charles', last: 'GOUDIABY', phone: '+221 70 789 98 76', gender: 'M', city: 'Ziguinchor', status: 'PARTIAL', amount: 4000, present: false },
    { first: 'Anne-Marie', last: 'CARVALHO', phone: '+221 77 890 09 87', gender: 'F', city: 'Dakar', status: 'PAID', amount: 5000, present: true },
  ];

  let seq = 1;
  for (const sp of sampleParticipants) {
    const regNo = `PAP-2027-${String(seq).padStart(6, '0')}`;
    const qrToken = crypto.randomUUID();
    const qrPayload = JSON.stringify({
      regNo,
      token: qrToken,
      eventId: jmjEvent.id,
    });
    const qrCode = await generateQr(qrPayload);

    const parish = parishes[(seq - 1) % parishes.length];
    const diocese = dioceses[(seq - 1) % dioceses.length];
    const movement = movements[(seq - 1) % movements.length];

    const participant = await prisma.participant.create({
      data: {
        eventId: jmjEvent.id,
        registrationNumber: regNo,
        firstName: sp.first,
        lastName: sp.last,
        phone: sp.phone,
        email: `${sp.first.toLowerCase().replace(/[^a-z]/g, '')}.${sp.last.toLowerCase()}@example.sn`,
        gender: sp.gender,
        parish,
        diocese,
        movement,
        city: sp.city,
        emergencyContact: 'Responsable de délégation',
        emergencyPhone: '+221 77 600 00 00',
        contributionStatus: sp.status,
        amountPaid: sp.amount,
        isPresent: sp.present,
        checkedInAt: sp.present ? new Date('2027-04-10T08:30:00Z') : null,
        qrCode,
        qrToken,
      },
    });

    // Enregistrement des cotisations correspondantes
    if (sp.amount > 0) {
      const paymentMethods = ['WAVE', 'ORANGE_MONEY', 'ESPECES', 'FREE_MONEY'];
      const method = paymentMethods[seq % paymentMethods.length];
      await prisma.contribution.create({
        data: {
          participantId: participant.id,
          amount: sp.amount,
          paymentMethod: method,
          reference: `REC-${method}-${Date.now()}-${seq}`,
          recordedBy: 'Secrétariat JMJ Dakar',
          date: new Date(),
        },
      });
    }

    // Enregistrement de check-in si présent
    if (sp.present) {
      await prisma.checkIn.create({
        data: {
          participantId: participant.id,
          checkedInBy: 'Abbé Paul NDIAYE',
          deviceInfo: 'Scanner Porte Principale',
          checkedInAt: new Date('2027-04-10T08:30:00Z'),
        },
      });
    }

    // Déduire les 100 FCFA de frais de service Papyrus
    await prisma.wallet.update({
      where: { id: demoWallet.id },
      data: { balance: { decrement: 100 } },
    });

    await prisma.transaction.create({
      data: {
        userId: demoUser.id,
        amount: -100,
        type: 'REGISTRATION_FEE',
        status: 'COMPLETED',
        reference: `TX-REG-SEED-${seq}`,
        paymentMethod: 'SYSTEM',
        createdAt: new Date(),
      },
    });

    seq++;
  }

  // Création de quelques notifications
  await prisma.notification.createMany({
    data: [
      {
        userId: demoUser.id,
        title: 'Nouvelle inscription confirmée',
        message: 'Jean-Baptiste SARR s\'est inscrit à JMJ Dakar 2027. Frais de 100 FCFA déduits.',
        type: 'REGISTRATION',
      },
      {
        userId: demoUser.id,
        title: 'Cotisation reçue',
        message: 'Paiement Wave de 5 000 FCFA reçu pour Marie-Madeleine DIOP.',
        type: 'PAYMENT',
      },
      {
        userId: demoUser.id,
        title: 'Préparatifs Popenguine',
        message: 'Le pèlerinage de Popenguine est en ligne et prêt à accueillir des inscriptions.',
        type: 'INFO',
      },
    ],
  });

  console.log(`
✅ Amorçage terminé avec succès !
============================================================
  Compte Organisateur Démo :
    Email        : demo@papyrus.sn
    Mot de passe : Papyrus2027!
    Solde        : 47 600 FCFA (476 inscriptions restantes)

  Compte Administrateur :
    Email        : admin@papyrus.sn
    Mot de passe : Admin2027!

  Événements créés :
    1. JMJ Dakar 2027 (/e/jmj-dakar-2027) - 24 participants
    2. Pèlerinage de Popenguine (/e/pelerinage-popenguine)
    3. Grande Marche Diocésaine (/e/marche-diocesaine)
============================================================
  `);
}

main()
  .catch((e) => {
    console.error('Erreur amorçage:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
