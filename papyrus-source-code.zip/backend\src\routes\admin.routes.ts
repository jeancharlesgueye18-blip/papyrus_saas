import { Router } from 'express';
import {
  getAdminDashboard,
  getAdminUsers,
  toggleUserSuspension,
  getAdminEvents,
  getAdminTransactions,
} from '../controllers/admin.controller.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = Router();

router.use(authenticateToken);
router.use(requireAdmin);

router.get('/dashboard', getAdminDashboard);
router.get('/users', getAdminUsers);
router.put('/users/:userId/suspension', toggleUserSuspension);
router.get('/events', getAdminEvents);
router.get('/transactions', getAdminTransactions);

export default router;
