import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { Contribution, EventItem } from '../types/index.js';
import { Modal } from '../components/Modal.js';
import {
  Coins,
  ArrowLeft,
  PlusCircle,
  TrendingUp,
  CreditCard,
  Search,
  CheckCircle2,
  Clock,
  ArrowUpRight,
} from 'lucide-react';

export const ContributionsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [event, setEvent] = useState<EventItem | null>(null);
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Modal nouveau paiement
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedParticipantId, setSelectedParticipantId] = useState('');
  const [amount, setAmount] = useState('5000');
  const [paymentMethod, setPaymentMethod] = useState('WAVE');
  const [reference, setReference] = useState('');

  useEffect(() => {
    if (id) {
      loadData();
    }
  }, [id]);

  const loadData = async () => {
    if (!id) return;
    try {
      const [eventRes, contribRes] = await Promise.all([
        api.getEventById(id),
        api.getContributions(id),
      ]);
      setEvent(eventRes.event);
      setData(contribRes);
      if (contribRes.participants && contribRes.participants.length > 0) {
        setSelectedParticipantId(contribRes.participants[0].id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !selectedParticipantId) return;
    try {
      await api.recordContribution(id, {
        participantId: selectedParticipantId,
        amount: Number(amount),
        paymentMethod,
        reference: reference || `REF-${paymentMethod}-${Date.now()}`,
      });
      setModalOpen(false);
      setReference('');
      loadData();
    } catch (err: any) {
      alert(err.message || 'Erreur lors de l\'enregistrement');
    }
  };

  if (loading) {
    return (
      <div className="text-center py-20 text-slate-400 text-sm">
        Chargement du module de cotisations...
      </div>
    );
  }

  const summary = data?.summary || {};
  const contributions: Contribution[] = data?.contributions || [];
  const participants = data?.participants || [];

  return (
    <div className="space-y-6 pb-20 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link
            to={id ? `/events/${id}` : '/events'}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <ArrowLeft size={20} />
          </Link>
          <div>
            <h1 className="text-2xl font-extrabold text-[#0F2B59]">
              Cotisations & Caisse
            </h1>
            <p className="text-xs text-slate-500">
              {event?.name} • Suivi en temps réel des encaissements
            </p>
          </div>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all hover:scale-105"
        >
          <PlusCircle size={18} />
          <span>Enregistrer un encaissement</span>
        </button>
      </div>

      {/* KPI FINANCIERS DE LA CAISSE (Section 18) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl bg-white border border-slate-100 shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Total Attendu
          </span>
          <div className="text-2xl font-extrabold text-[#0F2B59] font-serif-papyrus">
            {(summary.totalExpected || 0).toLocaleString('fr-FR')} <span className="text-xs font-sans text-slate-400">FCFA</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {summary.totalParticipants} participants × {summary.feePerPerson} F
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-emerald-50/70 border border-emerald-200/80 shadow-sm">
          <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block mb-1">
            Total Collecté
          </span>
          <div className="text-2xl font-extrabold text-emerald-700 font-serif-papyrus">
            {(summary.totalCollected || 0).toLocaleString('fr-FR')} <span className="text-xs font-sans text-emerald-600">FCFA</span>
          </div>
          <div className="text-[11px] text-emerald-700 mt-1 font-semibold">
            {summary.paidCount} payés complets • {summary.partialCount} partiels
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-amber-50/70 border border-amber-200/80 shadow-sm">
          <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block mb-1">
            Reste à Recouvrer
          </span>
          <div className="text-2xl font-extrabold text-amber-700 font-serif-papyrus">
            {(summary.totalRemaining || 0).toLocaleString('fr-FR')} <span className="text-xs font-sans text-amber-600">FCFA</span>
          </div>
          <div className="text-[11px] text-amber-700 mt-1">
            {summary.unpaidCount} participants non payés
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-blue-50/70 border border-blue-200/80 shadow-sm">
          <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wider block mb-1">
            Taux de Recouvrement
          </span>
          <div className="text-2xl font-extrabold text-[#0F2B59]">
            {summary.totalExpected > 0
              ? Math.round((summary.totalCollected / summary.totalExpected) * 100)
              : 100}%
          </div>
          <div className="w-full bg-blue-200 h-1.5 rounded-full mt-2 overflow-hidden">
            <div
              className="bg-[#0F2B59] h-full"
              style={{
                width: `${
                  summary.totalExpected > 0
                    ? Math.min(100, (summary.totalCollected / summary.totalExpected) * 100)
                    : 100
                }%`,
              }}
            ></div>
          </div>
        </div>
      </div>

      {/* HISTORIQUE DÉTAILLÉ DES PAIEMENTS */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-[#0F2B59] uppercase tracking-wider">
            Journal des Transactions de Cotisation ({contributions.length})
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Participant</th>
                <th className="py-3 px-4">Montant</th>
                <th className="py-3 px-4">Méthode</th>
                <th className="py-3 px-4">Référence</th>
                <th className="py-3 px-4">Responsable</th>
                <th className="py-3 px-4 text-right">Date & Heure</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {contributions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Aucun versement de cotisation enregistré pour le moment.
                  </td>
                </tr>
              ) : (
                contributions.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/70">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">
                        {c.participant?.firstName} {c.participant?.lastName}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {c.participant?.registrationNumber}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-emerald-700 text-sm">
                      +{c.amount.toLocaleString('fr-FR')} FCFA
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-slate-100 text-slate-700">
                        {c.paymentMethod}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-500 text-[11px]">
                      {c.reference || '-'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 font-medium">
                      {c.recordedBy || 'Responsable'}
                    </td>
                    <td className="py-3.5 px-4 text-right text-slate-400 whitespace-nowrap">
                      {new Date(c.date).toLocaleString('fr-FR')}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL ENREGISTRER PAIEMENT */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Encaisser une Cotisation"
      >
        <form onSubmit={handleRecordPayment} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Sélectionner le participant *
            </label>
            <select
              value={selectedParticipantId}
              onChange={(e) => setSelectedParticipantId(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-medium"
            >
              {participants.map((p: any) => (
                <option key={p.id} value={p.id}>
                  {p.firstName} {p.lastName} ({p.registrationNumber}) — Payé: {p.amountPaid} F ({p.contributionStatus})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Montant versé (FCFA) *
            </label>
            <input
              type="number"
              required
              min="100"
              step="500"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-base font-bold text-[#0F2B59]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Mode de paiement *
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs"
              >
                <option value="WAVE">Wave</option>
                <option value="ORANGE_MONEY">Orange Money</option>
                <option value="FREE_MONEY">Free Money</option>
                <option value="ESPECES">Espèces</option>
                <option value="VIREMENT">Virement</option>
                <option value="AUTRE">Autre</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                N° de transaction / Reçu
              </label>
              <input
                type="text"
                placeholder="Ex : WAVE-987452"
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs"
              />
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm"
            >
              Encaisser et Mettre à jour
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
