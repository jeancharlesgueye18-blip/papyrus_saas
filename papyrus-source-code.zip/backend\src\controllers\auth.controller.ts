import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest } from '../types/index.js';

const JWT_SECRET = process.env.JWT_SECRET || 'papyrus_secret_key_default';

export async function register(req: Request, res: Response): Promise<void> {
  try {
    const { firstName, lastName, email, phone, password, organizationName, organizationType } = req.body;

    if (!firstName || !lastName || !email || !phone || !password) {
      res.status(400).json({ error: 'Tous les champs obligatoires doivent être renseignés' });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ error: 'Le mot de passe doit comporter au moins 6 caractères' });
      return;
    }

    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
    });

    if (existingUser) {
      res.status(400).json({ error: 'Un compte existe déjà avec cette adresse email' });
      return;
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // Création atomique de l'organisation éventuelle, de l'utilisateur et de son portefeuille
    const result = await prisma.$transaction(async (tx) => {
      let orgId: string | undefined = undefined;
      if (organizationName) {
        const org = await tx.organization.create({
          data: {
            name: organizationName,
            type: organizationType || 'PAROISSE',
          },
        });
        orgId = org.id;
      }

      const user = await tx.user.create({
        data: {
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          email: email.toLowerCase().trim(),
          phone: phone.trim(),
          password: hashedPassword,
          role: 'ORGANIZER',
          organizationId: orgId,
        },
      });

      // Création du portefeuille avec solde 0
      const wallet = await tx.wallet.create({
        data: {
          userId: user.id,
          balance: 0,
        },
      });

      // Notification de bienvenue
      await tx.notification.create({
        data: {
          userId: user.id,
          title: 'Bienvenue sur Papyrus !',
          message: 'Votre compte a été créé avec succès. Rechargez des crédits pour commencer à inscrire vos participants.',
          type: 'INFO',
        },
      });

      return { user, wallet };
    });

    const token = jwt.sign(
      { id: result.user.id, email: result.user.email, role: result.user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'Compte créé avec succès',
      token,
      user: {
        id: result.user.id,
        firstName: result.user.firstName,
        lastName: result.user.lastName,
        email: result.user.email,
        phone: result.user.phone,
        role: result.user.role,
        wallet: {
          balance: result.wallet.balance,
          credits: Math.floor(result.wallet.balance / 100),
        },
      },
    });
  } catch (error) {
    console.error('Erreur inscription:', error);
    res.status(500).json({ error: 'Erreur lors de la création du compte' });
  }
}

export async function login(req: Request, res: Response): Promise<void> {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: 'Email et mot de passe requis' });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
      include: {
        wallet: true,
        organization: true,
      },
    });

    if (!user) {
      res.status(401).json({ error: 'Identifiants invalides' });
      return;
    }

    if (user.isSuspended) {
      res.status(403).json({ error: 'Votre compte a été suspendu. Veuillez contacter le support.' });
      return;
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      res.status(401).json({ error: 'Identifiants invalides' });
      return;
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Connexion réussie',
      token,
      user: {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        role: user.role,
        organization: user.organization,
        wallet: {
          balance: user.wallet?.balance ?? 0,
          credits: Math.floor((user.wallet?.balance ?? 0) / 100),
        },
      },
    });
  } catch (error) {
    console.error('Erreur connexion:', error);
    res.status(500).json({ error: 'Erreur serveur lors de la connexion' });
  }
}

export async function getMe(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Non authentifié' });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      include: {
        wallet: true,
        organization: true,
        _count: {
          select: {
            events: true,
            notifications: { where: { isRead: false } },
          },
        },
      },
    });

    if (!user) {
      res.status(404).json({ error: 'Utilisateur introuvable' });
      return;
    }

    res.json({
      user: {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isSuspended: user.isSuspended,
        organization: user.organization,
        unreadNotificationsCount: user._count.notifications,
        wallet: {
          balance: user.wallet?.balance ?? 0,
          credits: Math.floor((user.wallet?.balance ?? 0) / 100),
        },
      },
    });
  } catch (error) {
    console.error('Erreur getMe:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération du profil' });
  }
}

export async function forgotPassword(req: Request, res: Response): Promise<void> {
  const { email } = req.body;
  // Simulé pour le MVP
  res.json({
    message: 'Si cette adresse existe, un lien de réinitialisation a été envoyé par email/SMS.',
  });
}
