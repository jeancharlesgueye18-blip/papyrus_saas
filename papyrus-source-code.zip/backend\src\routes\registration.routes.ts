import { Router } from 'express';
import {
  registerParticipant,
  getPublicTicket,
} from '../controllers/registration.controller.js';

const router = Router();

// Inscription publique à un événement par son slug (sans authentification)
router.post('/public/:slug', registerParticipant);

// Consultation publique d'un billet/confirmation
router.get('/public/ticket/:regNumber', getPublicTicket);

export default router;
