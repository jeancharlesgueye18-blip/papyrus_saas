import { Router } from 'express';
import {
  getParticipants,
  getParticipantById,
  updateParticipant,
  deleteParticipant,
  getCategoryLists,
} from '../controllers/participant.controller.js';
import { authenticateToken } from '../middleware/auth.js';
import { authorizeEvent } from '../middleware/eventAuth.js';

const router = Router();

router.use(authenticateToken);

// Gestion des participants par événement
router.get('/events/:id/participants', authorizeEvent('MANAGER'), getParticipants);
router.get('/events/:id/categories', authorizeEvent('MANAGER'), getCategoryLists);

// Actions directes sur un participant
router.get('/:participantId', getParticipantById);
router.put('/:participantId', updateParticipant);
router.delete('/:participantId', deleteParticipant);

export default router;
