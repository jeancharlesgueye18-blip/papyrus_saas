const API_BASE = '/api';

export function getStoredToken(): string | null {
  return localStorage.getItem('papyrus_token');
}

export function setStoredToken(token: string): void {
  localStorage.setItem('papyrus_token', token);
}

export function removeStoredToken(): void {
  localStorage.removeItem('papyrus_token');
}

async function request<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = data.error || `Erreur serveur (${response.status})`;
    const error: any = new Error(errorMsg);
    error.status = response.status;
    error.code = data.code;
    throw error;
  }

  return data as T;
}

export const api = {
  // Auth
  login: (credentials: any) =>
    request<any>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),
  register: (payload: any) =>
    request<any>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getMe: () => request<any>('/auth/me'),

  // Événements
  getEvents: () => request<any>('/events'),
  getEventById: (id: string) => request<any>(`/events/${id}`),
  getEventBySlug: (slug: string) => request<any>(`/events/public/slug/${slug}`),
  createEvent: (data: any) =>
    request<any>('/events', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  updateEvent: (id: string, data: any) =>
    request<any>(`/events/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  deleteEvent: (id: string) =>
    request<any>(`/events/${id}`, { method: 'DELETE' }),

  // Inscriptions publiques
  registerParticipant: (slug: string, participantData: any) =>
    request<any>(`/registrations/public/${slug}`, {
      method: 'POST',
      body: JSON.stringify(participantData),
    }),
  getPublicTicket: (regNumber: string) =>
    request<any>(`/registrations/public/ticket/${regNumber}`),

  // Participants & Listes
  getParticipants: (eventId: string, params: Record<string, any> = {}) => {
    const query = new URLSearchParams(params).toString();
    return request<any>(`/participants/events/${eventId}/participants?${query}`);
  },
  getCategories: (eventId: string) =>
    request<any>(`/participants/events/${eventId}/categories`),
  updateParticipant: (id: string, data: any) =>
    request<any>(`/participants/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  deleteParticipant: (id: string) =>
    request<any>(`/participants/${id}`, { method: 'DELETE' }),

  // Cotisations
  getContributions: (eventId: string) =>
    request<any>(`/contributions/events/${eventId}/contributions`),
  recordContribution: (eventId: string, data: any) =>
    request<any>(`/contributions/events/${eventId}/contributions`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Check-In
  lookupTicket: (eventId: string, query: string) =>
    request<any>(`/checkin/events/${eventId}/lookup?query=${encodeURIComponent(query)}`),
  confirmCheckIn: (eventId: string, data: { participantId: string; deviceInfo?: string }) =>
    request<any>(`/checkin/events/${eventId}/confirm`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Portefeuille & Crédits
  getWallet: () => request<any>('/wallet'),
  purchaseCredits: (data: { packId: string; paymentMethod?: string; phoneNumber?: string }) =>
    request<any>('/wallet/purchase', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Administration
  getAdminDashboard: () => request<any>('/admin/dashboard'),
  getAdminUsers: () => request<any>('/admin/users'),
  toggleUserSuspension: (userId: string) =>
    request<any>(`/admin/users/${userId}/suspension`, { method: 'PUT' }),
  getAdminEvents: () => request<any>('/admin/events'),
  getAdminTransactions: () => request<any>('/admin/transactions'),

  // Notifications
  getNotifications: () => request<any>('/notifications'),
  markNotificationAsRead: (id: string) =>
    request<any>(`/notifications/${id}/read`, { method: 'PUT' }),
  markAllNotificationsAsRead: () =>
    request<any>('/notifications/read-all', { method: 'PUT' }),

  // URL d'export
  getExportUrl: (eventId: string, format = 'xlsx', type = 'general', extra = '') => {
    const token = getStoredToken();
    return `/api/exports/events/${eventId}?format=${format}&type=${type}&token=${token}${extra}`;
  },
};
