import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../services/api.js';
import {
  Calendar,
  MapPin,
  Coins,
  FileText,
  Church,
  ArrowLeft,
  Sparkles,
  AlertCircle,
} from 'lucide-react';

export const EventCreatePage: React.FC = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    type: 'JMJ',
    description: '',
    startDate: '',
    endDate: '',
    location: '',
    parish: '',
    diocese: '',
    contributionAmount: '5000',
    contributionType: 'FIXED',
  });

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await api.createEvent({
        ...formData,
        contributionAmount: Number(formData.contributionAmount) || 0,
      });
      navigate(`/events/${res.event.id}`);
    } catch (err: any) {
      setError(err.message || 'Erreur lors de la création de l\'événement');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-20 animate-fade-in">
      <div className="flex items-center gap-3">
        <Link
          to="/dashboard"
          className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <ArrowLeft size={20} />
        </Link>
        <div>
          <h1 className="text-2xl font-extrabold text-[#0F2B59]">
            Créer un Nouvel Événement
          </h1>
          <p className="text-xs text-slate-500">
            Configurez votre rassemblement et générez votre lien d'inscription en direct.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-xl shadow-slate-200/50">
        {error && (
          <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle size={18} className="shrink-0 text-rose-500" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Nom et Type */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Nom de l'événement *
              </label>
              <input
                type="text"
                required
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Ex : JMJ Dakar 2027"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Type *
              </label>
              <select
                name="type"
                value={formData.type}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
              >
                <option value="JMJ">JMJ</option>
                <option value="PELERINAGE">Pèlerinage</option>
                <option value="MARCHE">Marche</option>
                <option value="RETRAITE">Retraite</option>
                <option value="RASSEMBLEMENT">Rassemblement</option>
                <option value="CONFERENCE">Conférence</option>
                <option value="FORMATION">Formation</option>
                <option value="CHORALE">Chorale</option>
                <option value="AUTRE">Autre</option>
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Description ou Thème
            </label>
            <textarea
              name="description"
              rows={3}
              value={formData.description}
              onChange={handleChange}
              placeholder="Thème spirituel, programme succinct, consignes pour les participants..."
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
            ></textarea>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Date de début *
              </label>
              <div className="relative">
                <input
                  type="date"
                  required
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Date de fin (Optionnelle)
              </label>
              <input
                type="date"
                name="endDate"
                value={formData.endDate}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
              />
            </div>
          </div>

          {/* Lieu */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Lieu du rassemblement *
            </label>
            <div className="relative">
              <MapPin size={18} className="absolute inset-y-0 left-3.5 my-auto text-slate-400" />
              <input
                type="text"
                required
                name="location"
                value={formData.location}
                onChange={handleChange}
                placeholder="Ex : Stade Iba Mar Diop, Dakar"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
              />
            </div>
          </div>

          {/* Paroisse et Diocèse */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Paroisse organisatrice
              </label>
              <input
                type="text"
                name="parish"
                value={formData.parish}
                onChange={handleChange}
                placeholder="Ex : Cathédrale du Souvenir Africain"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Diocèse
              </label>
              <input
                type="text"
                name="diocese"
                value={formData.diocese}
                onChange={handleChange}
                placeholder="Ex : Archidiocèse de Dakar"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
              />
            </div>
          </div>

          {/* SECTION COTISATION */}
          <div className="p-5 rounded-2xl bg-amber-50/60 border border-amber-200/80 space-y-4">
            <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
              <Coins size={18} className="text-amber-600" />
              <span>Cotisation demandée aux participants</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Montant (en FCFA)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    step="500"
                    required
                    name="contributionAmount"
                    value={formData.contributionAmount}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 text-base font-bold text-[#0F2B59] focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                  />
                  <span className="absolute inset-y-0 right-4 flex items-center text-xs font-bold text-slate-400">
                    FCFA
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Mettre 0 si la participation est gratuite.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Régime de cotisation
                </label>
                <select
                  name="contributionType"
                  value={formData.contributionType}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-white"
                >
                  <option value="FIXED">Montant fixe obligatoire</option>
                  <option value="FREE">Gratuit</option>
                  <option value="OPTIONAL">Don / Participation libre</option>
                </select>
              </div>
            </div>

            <div className="text-[11px] text-amber-900 bg-amber-100/70 p-3 rounded-xl flex items-center gap-2">
              <Sparkles size={16} className="text-amber-600 shrink-0" />
              <span>
                <strong>Rappel du modèle Papyrus :</strong> 100 FCFA de frais de service seront prélevés sur votre solde Papyrus pour chaque participant inscrit, indépendamment du montant de votre cotisation.
              </span>
            </div>
          </div>

          <div className="pt-4 flex items-center justify-end gap-3">
            <Link
              to="/dashboard"
              className="px-5 py-3 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              Annuler
            </Link>
            <button
              type="submit"
              disabled={loading}
              className="px-7 py-3 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white font-bold text-sm shadow-md shadow-blue-950/20 transition-all hover:scale-105 disabled:opacity-50"
            >
              {loading ? 'Création en cours...' : 'Générer l\'événement et la page d\'inscription'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
