import QRCode from 'qrcode';

/**
 * Génère un QR Code sous forme de Data URL base64 image PNG
 */
export async function generateQrCodeDataUrl(data: string): Promise<string> {
  try {
    return await QRCode.toDataURL(data, {
      errorCorrectionLevel: 'M',
      margin: 2,
      width: 300,
      color: {
        dark: '#0F2B59', // Bleu profond Papyrus
        light: '#FFFFFF',
      },
    });
  } catch (error) {
    console.error('Erreur génération QR code:', error);
    throw new Error('Impossible de générer le QR code');
  }
}
