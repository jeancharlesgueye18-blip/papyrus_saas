import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { Participant, EventItem } from '../types/index.js';
import { Badge } from '../components/Badge.js';
import {
  ListFilter,
  Church,
  MapPin,
  Users,
  Coins,
  CheckCircle,
  XCircle,
  FileSpreadsheet,
  ArrowLeft,
} from 'lucide-react';

export const DynamicListsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [event, setEvent] = useState<EventItem | null>(null);
  const [categories, setCategories] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>('parish');

  useEffect(() => {
    if (id) {
      Promise.all([api.getEventById(id), api.getCategories(id)])
        .then(([eventRes, catRes]) => {
          setEvent(eventRes.event);
          setCategories(catRes);
        })
        .catch((err) => console.error(err))
        .finally(() => setLoading(false));
    }
  }, [id]);

  if (loading) {
    return (
      <div className="text-center py-20 text-slate-400 text-sm">
        Génération des listes dynamiques...
      </div>
    );
  }

  const summary = categories?.summary || {};
  const lists = categories?.lists || {};

  return (
    <div className="space-y-6 pb-20 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link
            to={id ? `/events/${id}` : '/events'}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <ArrowLeft size={20} />
          </Link>
          <div>
            <h1 className="text-2xl font-extrabold text-[#0F2B59]">
              Listes Automatiques par Catégorie
            </h1>
            <p className="text-xs text-slate-500">
              {event?.name} • Regroupements dynamiques en temps réel
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href={id ? `/api/exports/events/${id}?format=xlsx&type=${activeTab}` : '#'}
            target="_blank"
            download
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold shadow-sm"
          >
            <FileSpreadsheet size={16} className="text-emerald-600" />
            <span>Exporter cette liste</span>
          </a>
        </div>
      </div>

      {/* COMPTEURS RÉCAPITULATIFS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
          <span className="text-slate-400 block font-semibold uppercase text-[10px]">Paroisses représentées</span>
          <span className="text-xl font-extrabold text-[#0F2B59]">{summary.parishesCount || 0}</span>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
          <span className="text-slate-400 block font-semibold uppercase text-[10px]">Diocèses</span>
          <span className="text-xl font-extrabold text-[#0F2B59]">{summary.diocesesCount || 0}</span>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
          <span className="text-slate-400 block font-semibold uppercase text-[10px]">Cotisants à jour</span>
          <span className="text-xl font-extrabold text-emerald-700">{summary.cotisantsCount || 0}</span>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
          <span className="text-slate-400 block font-semibold uppercase text-[10px]">Pointés Présents</span>
          <span className="text-xl font-extrabold text-blue-700">{summary.presentsCount || 0}</span>
        </div>
      </div>

      {/* ONGLETS DES CATÉGORIES (Section 17) */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('parish')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'parish'
              ? 'bg-[#0F2B59] text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Par Paroisse
        </button>

        <button
          onClick={() => setActiveTab('diocese')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'diocese'
              ? 'bg-[#0F2B59] text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Par Diocèse
        </button>

        <button
          onClick={() => setActiveTab('movement')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'movement'
              ? 'bg-[#0F2B59] text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Par Mouvement / Groupe
        </button>

        <button
          onClick={() => setActiveTab('cotisants')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'cotisants'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Cotisants ({summary.cotisantsCount || 0})
        </button>

        <button
          onClick={() => setActiveTab('nonCotisants')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'nonCotisants'
              ? 'bg-rose-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Non-Cotisants ({summary.nonCotisantsCount || 0})
        </button>

        <button
          onClick={() => setActiveTab('presents')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'presents'
              ? 'bg-blue-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Présents ({summary.presentsCount || 0})
        </button>

        <button
          onClick={() => setActiveTab('absents')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'absents'
              ? 'bg-slate-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100'
          }`}
        >
          Absents ({summary.absentsCount || 0})
        </button>
      </div>

      {/* CONTENU DE L'ONGLET SÉLECTIONNÉ */}
      <div className="space-y-6">
        {activeTab === 'parish' && (
          <div className="space-y-4">
            {Object.entries(lists.byParish || {}).map(([parishName, members]: [string, any]) => (
              <div key={parishName} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                  <h3 className="font-bold text-[#0F2B59] flex items-center gap-2 text-sm">
                    <Church size={16} className="text-amber-500" />
                    {parishName}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
                    {members.length} participant{members.length > 1 ? 's' : ''}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                  {members.map((m: any) => (
                    <div key={m.id} className="p-2.5 rounded-xl bg-slate-50 flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-slate-800">{m.firstName} {m.lastName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{m.registrationNumber}</div>
                      </div>
                      <Badge status={m.contributionStatus} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'diocese' && (
          <div className="space-y-4">
            {Object.entries(lists.byDiocese || {}).map(([dioceseName, members]: [string, any]) => (
              <div key={dioceseName} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                  <h3 className="font-bold text-[#0F2B59] flex items-center gap-2 text-sm">
                    <MapPin size={16} className="text-blue-500" />
                    {dioceseName}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
                    {members.length} participant{members.length > 1 ? 's' : ''}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                  {members.map((m: any) => (
                    <div key={m.id} className="p-2.5 rounded-xl bg-slate-50 flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-slate-800">{m.firstName} {m.lastName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{m.parish || '-'}</div>
                      </div>
                      <Badge status={m.contributionStatus} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'movement' && (
          <div className="space-y-4">
            {Object.entries(lists.byMovement || {}).map(([movName, members]: [string, any]) => (
              <div key={movName} className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                  <h3 className="font-bold text-[#0F2B59] flex items-center gap-2 text-sm">
                    <Users size={16} className="text-emerald-500" />
                    {movName}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
                    {members.length} participant{members.length > 1 ? 's' : ''}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                  {members.map((m: any) => (
                    <div key={m.id} className="p-2.5 rounded-xl bg-slate-50 flex items-center justify-between">
                      <div className="font-semibold text-slate-800">{m.firstName} {m.lastName}</div>
                      <Badge status={m.contributionStatus} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {['cotisants', 'nonCotisants', 'presents', 'absents'].includes(activeTab) && (
          <div className="bg-white rounded-3xl border border-slate-100 p-5 shadow-sm">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {(lists[activeTab] || []).map((m: any) => (
                <div key={m.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-slate-900">{m.firstName} {m.lastName}</div>
                    <div className="text-[10px] text-slate-500">{m.phone} • {m.parish || '-'}</div>
                  </div>
                  <Badge status={activeTab === 'presents' || activeTab === 'absents' ? (m.isPresent ? 'PRESENT' : 'ABSENT') : m.contributionStatus} />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
