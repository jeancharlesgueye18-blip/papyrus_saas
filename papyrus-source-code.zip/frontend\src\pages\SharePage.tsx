import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { EventItem } from '../types/index.js';
import {
  Share2,
  Copy,
  Check,
  Download,
  ArrowLeft,
  QrCode,
  MessageCircle,
  ExternalLink,
} from 'lucide-react';

export const SharePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [event, setEvent] = useState<EventItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (id) {
      api.getEventById(id)
        .then((res) => setEvent(res.event))
        .catch((err) => console.error(err))
        .finally(() => setLoading(false));
    }
  }, [id]);

  if (loading) {
    return (
      <div className="text-center py-20 text-slate-400 text-sm">
        Chargement des liens de partage...
      </div>
    );
  }

  if (!event) {
    return (
      <div className="text-center py-20 text-slate-500">
        Événement non trouvé.
      </div>
    );
  }

  const appUrl = window.location.origin;
  const publicUrl = `${appUrl}/e/${event.slug}`;
  const whatsappMessage = `Inscrivez-vous à ${event.name} :\n${publicUrl}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(publicUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsApp = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(url, '_blank');
  };

  const handleDownloadQr = () => {
    if (!event.qrCode) return;
    const a = document.createElement('a');
    a.href = event.qrCode;
    a.download = `qrcode-${event.slug}.png`;
    a.click();
  };

  return (
    <div className="max-w-xl mx-auto space-y-6 pb-20 animate-fade-in">
      <div className="flex items-center gap-3">
        <Link
          to={`/events/${event.id}`}
          className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <ArrowLeft size={20} />
        </Link>
        <div>
          <h1 className="text-2xl font-extrabold text-[#0F2B59]">
            Partager l'Événement
          </h1>
          <p className="text-xs text-slate-500">
            {event.name} • Diffusez votre lien auprès des fidèles et participants
          </p>
        </div>
      </div>

      {/* CARTE PARTAGE LIEN */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-sm space-y-6">
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            Lien d'inscription direct
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={publicUrl}
              className="flex-1 px-4 py-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-700 bg-slate-50"
            />
            <button
              onClick={handleCopy}
              className="px-4 py-3 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white font-bold text-xs flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
              <span>{copied ? 'Copié !' : 'Copier'}</span>
            </button>
          </div>
        </div>

        {/* BOUTONS ACTIONS WHATSAPP ET NAVIGATEUR */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleWhatsApp}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all hover:scale-105"
          >
            <MessageCircle size={18} />
            <span>Partager WhatsApp</span>
          </button>

          <a
            href={publicUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors"
          >
            <ExternalLink size={16} />
            <span>Tester la page</span>
          </a>
        </div>
      </div>

      {/* QR CODE OFFICIEL DE L'ÉVÉNEMENT */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-100 shadow-sm text-center space-y-4">
        <div className="flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0F2B59]">
          <QrCode size={16} className="text-amber-500" />
          <span>Affiche & QR Code de l'Événement</span>
        </div>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          Imprimez ce QR Code sur vos affiches paroissiales, tracts ou livrets de messe pour permettre aux fidèles de scanner et s'inscrire en direct.
        </p>

        {event.qrCode && (
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 inline-block shadow-sm">
            <img
              src={event.qrCode}
              alt={`QR Code ${event.name}`}
              className="w-48 h-48 object-contain mx-auto"
            />
          </div>
        )}

        <div>
          <button
            onClick={handleDownloadQr}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-colors"
          >
            <Download size={16} />
            <span>Télécharger l'image PNG</span>
          </button>
        </div>
      </div>
    </div>
  );
};
