import { Response } from 'express';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest } from '../types/index.js';

export async function lookupTicket(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params; // eventId
    const { query } = req.query; // QR token, registration number, or search string

    if (!query || typeof query !== 'string') {
      res.status(400).json({ error: 'Code QR ou numéro d\'inscription requis' });
      return;
    }

    let parsedToken = query.trim();
    // Tester si le scan est du JSON (notre format de payload QR)
    try {
      if (parsedToken.startsWith('{') && parsedToken.endsWith('}')) {
        const parsed = JSON.parse(parsedToken);
        if (parsed.token) parsedToken = parsed.token;
        else if (parsed.regNo) parsedToken = parsed.regNo;
      }
    } catch (e) {
      // Pas du JSON, continuer avec la chaîne brute
    }

    const participant = await prisma.participant.findFirst({
      where: {
        eventId: id,
        OR: [
          { qrToken: parsedToken },
          { registrationNumber: parsedToken },
          { id: parsedToken },
          { phone: parsedToken },
        ],
      },
      include: {
        event: {
          select: {
            name: true,
            contributionAmount: true,
          },
        },
        checkIns: {
          orderBy: { checkedInAt: 'desc' },
        },
      },
    });

    if (!participant) {
      res.status(404).json({ error: 'Aucun participant trouvé correspondant à ce code' });
      return;
    }

    res.json({ participant });
  } catch (error) {
    console.error('Erreur lookupTicket:', error);
    res.status(500).json({ error: 'Erreur lors de la recherche du participant' });
  }
}

export async function confirmCheckIn(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params; // eventId
    const { participantId, deviceInfo } = req.body;

    if (!participantId) {
      res.status(400).json({ error: 'Identifiant du participant requis' });
      return;
    }

    const participant = await prisma.participant.findUnique({
      where: { id: participantId },
      include: {
        checkIns: { orderBy: { checkedInAt: 'desc' } },
      },
    });

    if (!participant || participant.eventId !== id) {
      res.status(404).json({ error: 'Participant non trouvé pour cet événement' });
      return;
    }

    // Empêcher les doubles check-in
    if (participant.isPresent) {
      const lastCheckIn = participant.checkIns[0];
      const checkInTime = lastCheckIn
        ? new Date(lastCheckIn.checkedInAt).toLocaleTimeString('fr-FR')
        : 'antérieurement';

      res.status(409).json({
        error: `Ce participant a déjà été pointé présent à ${checkInTime} !`,
        participant,
      });
      return;
    }

    const staffName = req.user
      ? `${req.user.firstName} ${req.user.lastName}`
      : 'Contrôleur';

    const result = await prisma.$transaction(async (tx) => {
      // Créer l'entrée de check-in
      const checkInRecord = await tx.checkIn.create({
        data: {
          participantId: participant.id,
          checkedInBy: staffName,
          deviceInfo: deviceInfo || 'Scanner Mobile Papyrus',
        },
      });

      // Mettre à jour le participant
      const updatedParticipant = await tx.participant.update({
        where: { id: participant.id },
        data: {
          isPresent: true,
          checkedInAt: new Date(),
        },
      });

      return { checkInRecord, updatedParticipant };
    });

    res.json({
      message: 'Participant marqué présent avec succès !',
      participant: result.updatedParticipant,
      checkIn: result.checkInRecord,
    });
  } catch (error) {
    console.error('Erreur confirmCheckIn:', error);
    res.status(500).json({ error: 'Erreur lors du pointage du participant' });
  }
}
