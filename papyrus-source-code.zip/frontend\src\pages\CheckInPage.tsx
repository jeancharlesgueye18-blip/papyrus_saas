import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { Participant, EventItem } from '../types/index.js';
import { Badge } from '../components/Badge.js';
import {
  QrCode,
  Search,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  UserCheck,
  ShieldAlert,
  Clock,
  Sparkles,
} from 'lucide-react';

export const CheckInPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [event, setEvent] = useState<EventItem | null>(null);
  const [query, setQuery] = useState('');
  const [scannedParticipant, setScannedParticipant] = useState<Participant | null>(null);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'warning'; text: string } | null>(null);

  // Liste des derniers participants pointés
  const [recentCheckIns, setRecentCheckIns] = useState<any[]>([]);

  useEffect(() => {
    if (id) {
      api.getEventById(id)
        .then((res) => setEvent(res.event))
        .catch((err) => console.error(err));
    }
  }, [id]);

  const handleLookup = async (lookupValue: string) => {
    if (!id || !lookupValue.trim()) return;
    setLoading(true);
    setMessage(null);
    setScannedParticipant(null);

    try {
      const res = await api.lookupTicket(id, lookupValue.trim());
      setScannedParticipant(res.participant);

      if (res.participant.isPresent) {
        setMessage({
          type: 'warning',
          text: `Attention : Ce participant a déjà été pointé présent !`,
        });
      }
    } catch (err: any) {
      setMessage({
        type: 'error',
        text: err.message || 'Aucun participant correspondant à ce code.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmPresence = async () => {
    if (!id || !scannedParticipant) return;
    setActionLoading(true);

    try {
      const res = await api.confirmCheckIn(id, {
        participantId: scannedParticipant.id,
        deviceInfo: 'Scanner Papyrus Accueil',
      });

      setScannedParticipant(res.participant);
      setMessage({
        type: 'success',
        text: `Présence validée avec succès pour ${res.participant.firstName} ${res.participant.lastName} !`,
      });

      setRecentCheckIns((prev) => [
        {
          id: res.participant.id,
          name: `${res.participant.firstName} ${res.participant.lastName}`,
          regNo: res.participant.registrationNumber,
          time: new Date().toLocaleTimeString('fr-FR'),
        },
        ...prev.slice(0, 9),
      ]);
    } catch (err: any) {
      setMessage({
        type: 'error',
        text: err.message || 'Erreur lors de la validation du pointage.',
      });
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-20 animate-fade-in">
      {/* HEADER */}
      <div className="flex items-center gap-3">
        <Link
          to={id ? `/events/${id}` : '/events'}
          className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <ArrowLeft size={20} />
        </Link>
        <div>
          <h1 className="text-2xl font-extrabold text-[#0F2B59]">
            Contrôle d'Accès & Scanner
          </h1>
          <p className="text-xs text-slate-500">
            {event?.name} • Pointage en direct des participants
          </p>
        </div>
      </div>

      {/* ZONE DE SCAN & RECHERCHE */}
      <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-md">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleLookup(query);
          }}
          className="space-y-4"
        >
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Scanner le QR Code ou saisir le N° PAP
            </label>
            <div className="relative">
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ex : PAP-2027-000001 ou scannez la douchette..."
                className="w-full pl-11 pr-24 py-3.5 rounded-2xl border border-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#0F2B59] bg-slate-50/50"
              />
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <QrCode size={20} />
              </div>
              <button
                type="submit"
                disabled={loading || !query.trim()}
                className="absolute inset-y-1.5 right-1.5 px-4 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white font-bold text-xs transition-colors disabled:opacity-40"
              >
                {loading ? 'Recherche...' : 'Vérifier'}
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* NOTIFICATIONS & MESSAGES */}
      {message && (
        <div
          className={`p-4 rounded-2xl text-xs flex items-center gap-2.5 shadow-sm animate-fade-in ${
            message.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              : message.type === 'warning'
              ? 'bg-amber-50 border border-amber-200 text-amber-800 font-semibold'
              : 'bg-rose-50 border border-rose-200 text-rose-800'
          }`}
        >
          {message.type === 'success' ? (
            <CheckCircle2 size={18} className="shrink-0 text-emerald-600" />
          ) : message.type === 'warning' ? (
            <ShieldAlert size={18} className="shrink-0 text-amber-600" />
          ) : (
            <AlertCircle size={18} className="shrink-0 text-rose-600" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      {/* FICHE D'IDENTIFICATION DU PARTICIPANT SCANNÉ */}
      {scannedParticipant && (
        <div className="bg-white rounded-3xl p-6 border-2 border-slate-200 shadow-xl space-y-6 animate-scale-up">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                N° d'inscription
              </span>
              <div className="text-base font-black text-amber-600 font-mono">
                {scannedParticipant.registrationNumber}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Badge status={scannedParticipant.isPresent ? 'PRESENT' : 'ABSENT'} />
              <Badge status={scannedParticipant.contributionStatus} />
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <h2 className="text-2xl font-black text-[#0F2B59]">
                {scannedParticipant.firstName} {scannedParticipant.lastName.toUpperCase()}
              </h2>
              <div className="text-xs text-slate-500 font-medium mt-0.5">
                {scannedParticipant.phone} • {scannedParticipant.parish || 'Paroisse non précisée'}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3.5 rounded-2xl bg-slate-50 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Diocèse</span>
                <span className="font-semibold text-slate-800">{scannedParticipant.diocese || '-'}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Mouvement</span>
                <span className="font-semibold text-slate-800">{scannedParticipant.movement || '-'}</span>
              </div>
            </div>

            {/* Avertissement si cotisation non payée */}
            {scannedParticipant.contributionStatus !== 'PAID' && (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-center gap-2">
                <AlertCircle size={16} className="text-amber-600 shrink-0" />
                <span>
                  <strong>Cotisation incomplète :</strong> {scannedParticipant.amountPaid} FCFA payés sur {event?.contributionAmount} FCFA.
                </span>
              </div>
            )}
          </div>

          {/* ACTION : MARQUER PRÉSENT */}
          <div>
            {scannedParticipant.isPresent ? (
              <div className="w-full py-3.5 px-4 rounded-2xl bg-blue-50 border border-blue-200 text-blue-900 font-bold text-sm text-center flex items-center justify-center gap-2">
                <CheckCircle2 size={18} className="text-blue-600" />
                <span>Participant déjà pointé présent</span>
              </div>
            ) : (
              <button
                onClick={handleConfirmPresence}
                disabled={actionLoading}
                className="w-full py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm shadow-lg shadow-emerald-700/20 transition-all hover:scale-[1.01] flex items-center justify-center gap-2"
              >
                <UserCheck size={20} />
                <span>{actionLoading ? 'Validation en cours...' : 'Marquer Présent'}</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* DERNIERS ENREGISTREMENTS */}
      {recentCheckIns.length > 0 && (
        <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-[#0F2B59] uppercase tracking-wider">
            Derniers pointages effectués
          </h3>
          <div className="divide-y divide-slate-50 text-xs">
            {recentCheckIns.map((item, idx) => (
              <div key={idx} className="py-2.5 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-800">{item.name}</span>
                  <span className="text-[10px] text-slate-400 font-mono ml-2">{item.regNo}</span>
                </div>
                <div className="flex items-center gap-1 text-[11px] text-slate-400">
                  <Clock size={12} />
                  <span>{item.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
