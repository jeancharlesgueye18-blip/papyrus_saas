import { Response, NextFunction } from 'express';
import prisma from '../config/prisma.js';
import { AuthenticatedRequest, StaffRole } from '../types/index.js';

export function authorizeEvent(minimumRole: StaffRole = 'CHECKER') {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
    const eventId = req.params.id || req.params.eventId;

    if (!eventId) {
      res.status(400).json({ error: 'Identifiant d\'événement manquant' });
      return;
    }

    if (!req.user) {
      res.status(401).json({ error: 'Utilisateur non authentifié' });
      return;
    }

    // L'administrateur a tous les droits
    if (req.user.role === 'ADMIN') {
      return next();
    }

    try {
      const event = await prisma.event.findUnique({
        where: { id: eventId },
        include: {
          staff: {
            where: { userId: req.user.id },
          },
        },
      });

      if (!event) {
        res.status(404).json({ error: 'Événement non trouvé' });
        return;
      }

      // Est-il le créateur / propriétaire de l'événement ?
      if (event.userId === req.user.id) {
        return next();
      }

      // Est-il membre du staff ?
      const staffMember = event.staff[0];
      if (!staffMember) {
        res.status(403).json({ error: 'Vous n\'avez pas accès à cet événement' });
        return;
      }

      // Vérification hiérarchique : OWNER > MANAGER > CHECKER
      const roleHierarchy: Record<StaffRole, number> = {
        OWNER: 3,
        MANAGER: 2,
        CHECKER: 1,
      };

      const userRoleLevel = roleHierarchy[staffMember.role as StaffRole] || 0;
      const requiredLevel = roleHierarchy[minimumRole];

      if (userRoleLevel >= requiredLevel) {
        return next();
      }

      res.status(403).json({
        error: `Permission insuffisante. Rôle requis: ${minimumRole}`,
      });
    } catch (error) {
      console.error('Erreur vérification droits événement:', error);
      res.status(500).json({ error: 'Erreur lors de la vérification des permissions' });
    }
  };
}
