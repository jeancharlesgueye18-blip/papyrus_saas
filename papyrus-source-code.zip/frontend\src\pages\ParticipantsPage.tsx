import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { Participant, EventItem } from '../types/index.js';
import { Badge } from '../components/Badge.js';
import { Modal } from '../components/Modal.js';
import {
  Search,
  PlusCircle,
  FileSpreadsheet,
  Coins,
  Edit2,
  Trash2,
  ChevronLeft,
  ChevronRight,
  ArrowLeft,
  CheckCircle,
  XCircle,
  UserPlus,
  AlertCircle,
  Ticket,
  Download,
} from 'lucide-react';

export const ParticipantsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [event, setEvent] = useState<EventItem | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [loading, setLoading] = useState(true);

  // Filtres et pagination
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [presenceFilter, setPresenceFilter] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // Modals
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedParticipant, setSelectedParticipant] = useState<Participant | null>(null);
  const [paymentAmount, setPaymentAmount] = useState('5000');
  const [paymentMethod, setPaymentMethod] = useState('WAVE');

  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editForm, setEditForm] = useState<any>({});

  // Modal saisie manuelle
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [addSubmitting, setAddSubmitting] = useState(false);
  const [addError, setAddError] = useState<string | null>(null);
  const [addSuccess, setAddSuccess] = useState<{ regNumber: string; name: string } | null>(null);
  const [addForm, setAddForm] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    birthDate: '',
    gender: 'M',
    parish: '',
    diocese: '',
    movement: '',
    city: 'Dakar',
    emergencyContact: '',
    emergencyPhone: '',
  });

  useEffect(() => {
    if (id) {
      api.getEventById(id)
        .then((res) => {
          setEvent(res.event);
          setPaymentAmount(String(res.event.contributionAmount || 5000));
        })
        .catch((err) => console.error(err));
    }
  }, [id]);

  useEffect(() => {
    loadParticipants();
  }, [id, search, statusFilter, presenceFilter, page]);

  const loadParticipants = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const params: any = { page, limit: 15 };
      if (search) params.search = search;
      if (statusFilter) params.contributionStatus = statusFilter;
      if (presenceFilter !== '') params.isPresent = presenceFilter;

      const res = await api.getParticipants(id, params);
      setParticipants(res.participants || []);
      setTotalPages(res.pagination?.totalPages || 1);
      setTotalCount(res.pagination?.total || 0);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenPayment = (p: Participant) => {
    setSelectedParticipant(p);
    setPaymentModalOpen(true);
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !selectedParticipant) return;
    try {
      await api.recordContribution(id, {
        participantId: selectedParticipant.id,
        amount: Number(paymentAmount),
        paymentMethod,
      });
      setPaymentModalOpen(false);
      loadParticipants();
    } catch (err: any) {
      alert(err.message || 'Erreur enregistrement cotisation');
    }
  };

  const handleOpenEdit = (p: Participant) => {
    setSelectedParticipant(p);
    setEditForm({
      firstName: p.firstName,
      lastName: p.lastName,
      phone: p.phone,
      email: p.email || '',
      parish: p.parish || '',
      diocese: p.diocese || '',
      movement: p.movement || '',
    });
    setEditModalOpen(true);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedParticipant) return;
    try {
      await api.updateParticipant(selectedParticipant.id, editForm);
      setEditModalOpen(false);
      loadParticipants();
    } catch (err: any) {
      alert(err.message || 'Erreur modification participant');
    }
  };

  const handleDelete = async (participantId: string) => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer ce participant ?')) return;
    try {
      await api.deleteParticipant(participantId);
      loadParticipants();
    } catch (err: any) {
      alert(err.message || 'Erreur suppression participant');
    }
  };

  const resetAddForm = () => {
    setAddForm({
      firstName: '',
      lastName: '',
      phone: '',
      email: '',
      birthDate: '',
      gender: 'M',
      parish: '',
      diocese: '',
      movement: '',
      city: 'Dakar',
      emergencyContact: '',
      emergencyPhone: '',
    });
    setAddError(null);
    setAddSuccess(null);
  };

  const handleOpenAddModal = () => {
    resetAddForm();
    setAddModalOpen(true);
  };

  const handleAddParticipant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!event?.slug) return;
    setAddError(null);
    setAddSubmitting(true);
    try {
      const res = await api.registerParticipant(event.slug, addForm);
      setAddSuccess({
        regNumber: res.participant.registrationNumber,
        name: `${res.participant.firstName} ${res.participant.lastName}`,
      });
      loadParticipants();
    } catch (err: any) {
      if (err.status === 402 || err.code === 'INSUFFICIENT_WALLET_BALANCE') {
        setAddError('Solde Papyrus insuffisant. Veuillez recharger votre portefeuille (100 FCFA requis par inscription).');
      } else {
        setAddError(err.message || 'Erreur lors de l\'inscription manuelle.');
      }
    } finally {
      setAddSubmitting(false);
    }
  };


  return (
    <div className="space-y-6 pb-20 animate-fade-in">
      {/* HEADER DE NAVIGATION */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link
            to={id ? `/events/${id}` : '/events'}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <ArrowLeft size={20} />
          </Link>
          <div>
            <h1 className="text-2xl font-extrabold text-[#0F2B59]">
              Participants ({totalCount})
            </h1>
            <p className="text-xs text-slate-500">
              {event?.name} • Gestion intégrale des inscrits
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleOpenAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white text-xs font-bold shadow-sm transition-colors"
          >
            <UserPlus size={16} />
            <span>Inscrire un participant</span>
          </button>
          <a
            href={id ? `/api/exports/events/${id}?format=xlsx` : '#'}
            target="_blank"
            download
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold shadow-sm transition-colors"
          >
            <FileSpreadsheet size={16} className="text-emerald-600" />
            <span>Exporter Excel</span>
          </a>
        </div>
      </div>

      {/* FILTRES & RECHERCHE */}
      <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={18} className="absolute inset-y-0 left-3.5 my-auto text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Rechercher par nom, téléphone, N° PAP..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium bg-slate-50 focus:outline-none"
        >
          <option value="">Toutes les cotisations</option>
          <option value="PAID">Payé</option>
          <option value="PARTIAL">Partiellement payé</option>
          <option value="UNPAID">Non payé</option>
        </select>

        <select
          value={presenceFilter}
          onChange={(e) => {
            setPresenceFilter(e.target.value);
            setPage(1);
          }}
          className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium bg-slate-50 focus:outline-none"
        >
          <option value="">Tous les statuts de présence</option>
          <option value="true">Présents uniquement</option>
          <option value="false">Absents uniquement</option>
        </select>
      </div>

      {/* TABLE DES PARTICIPANTS */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3.5 px-4">N°</th>
                <th className="py-3.5 px-4">Participant</th>
                <th className="py-3.5 px-4">Téléphone</th>
                <th className="py-3.5 px-4">Paroisse / Diocèse</th>
                <th className="py-3.5 px-4">Groupe</th>
                <th className="py-3.5 px-4">Cotisation</th>
                <th className="py-3.5 px-4 text-center">Présence</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    Chargement des participants...
                  </td>
                </tr>
              ) : participants.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    Aucun participant trouvé avec ces critères.
                  </td>
                </tr>
              ) : (
                participants.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-amber-700">
                      {p.registrationNumber}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">
                        {p.firstName} {p.lastName.toUpperCase()}
                      </div>
                      {p.email && (
                        <div className="text-[11px] text-slate-400">{p.email}</div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 font-medium whitespace-nowrap">
                      {p.phone}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-800">{p.parish || '-'}</div>
                      <div className="text-[10px] text-slate-400">{p.diocese || '-'}</div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {p.movement || '-'}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex flex-col gap-1 items-start">
                        <Badge status={p.contributionStatus} />
                        <span className="text-[10px] text-slate-500 font-semibold">
                          {(p.amountPaid || 0).toLocaleString('fr-FR')} FCFA
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <Badge status={p.isPresent ? 'PRESENT' : 'ABSENT'} />
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenPayment(p)}
                          className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors"
                          title="Enregistrer une cotisation"
                        >
                          <Coins size={15} />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(p)}
                          className="p-1.5 rounded-lg bg-blue-50 text-[#0F2B59] hover:bg-blue-100 transition-colors"
                          title="Modifier"
                        >
                          <Edit2 size={15} />
                        </button>
                        <button
                          onClick={() => handleDelete(p.id)}
                          className="p-1.5 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors"
                          title="Supprimer"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION */}
        <div className="px-6 py-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>
            Page <strong>{page}</strong> sur <strong>{totalPages}</strong> ({totalCount} au total)
          </span>
          <div className="flex items-center gap-2">
            <button
              disabled={page <= 1}
              onClick={() => setPage(page - 1)}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 transition-colors"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              disabled={page >= totalPages}
              onClick={() => setPage(page + 1)}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40 transition-colors"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* MODAL ENREGISTRER UNE COTISATION */}
      <Modal
        isOpen={paymentModalOpen}
        onClose={() => setPaymentModalOpen(false)}
        title="Enregistrer un Règlement de Cotisation"
      >
        {selectedParticipant && (
          <form onSubmit={handleRecordPayment} className="space-y-4">
            <div className="p-3.5 rounded-xl bg-blue-50/60 text-xs text-[#0F2B59]">
              Participant : <strong>{selectedParticipant.firstName} {selectedParticipant.lastName}</strong> ({selectedParticipant.registrationNumber})
              <br />
              Déjà payé : <strong>{(selectedParticipant.amountPaid || 0).toLocaleString('fr-FR')} FCFA</strong> sur {event?.contributionAmount} FCFA
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Montant Reçu (FCFA) *
              </label>
              <input
                type="number"
                required
                min="100"
                step="500"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-base font-bold text-[#0F2B59]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Mode de Paiement
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm"
              >
                <option value="WAVE">Wave</option>
                <option value="ORANGE_MONEY">Orange Money</option>
                <option value="FREE_MONEY">Free Money</option>
                <option value="ESPECES">Espèces</option>
                <option value="VIREMENT">Virement bancaire</option>
                <option value="AUTRE">Autre</option>
              </select>
            </div>

            <div className="pt-3 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setPaymentModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm"
              >
                Valider l'encaissement
              </button>
            </div>
          </form>
        )}
      </Modal>

      {/* MODAL MODIFIER PARTICIPANT */}
      <Modal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        title="Modifier les Informations du Participant"
      >
        <form onSubmit={handleSaveEdit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Prénom</label>
              <input
                type="text"
                required
                value={editForm.firstName || ''}
                onChange={(e) => setEditForm({ ...editForm, firstName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Nom</label>
              <input
                type="text"
                required
                value={editForm.lastName || ''}
                onChange={(e) => setEditForm({ ...editForm, lastName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Téléphone</label>
              <input
                type="tel"
                required
                value={editForm.phone || ''}
                onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Email</label>
              <input
                type="email"
                value={editForm.email || ''}
                onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Paroisse</label>
              <input
                type="text"
                value={editForm.parish || ''}
                onChange={(e) => setEditForm({ ...editForm, parish: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Diocèse</label>
              <input
                type="text"
                value={editForm.diocese || ''}
                onChange={(e) => setEditForm({ ...editForm, diocese: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
              />
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setEditModalOpen(false)}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white text-xs font-bold"
            >
              Enregistrer
            </button>
          </div>
        </form>
      </Modal>

      {/* ====================================================== */}
      {/* MODAL : SAISIE MANUELLE D'UN PARTICIPANT                */}
      {/* ====================================================== */}
      <Modal
        isOpen={addModalOpen}
        onClose={() => { setAddModalOpen(false); resetAddForm(); }}
        title="Saisie Manuelle — Inscrire un Participant"
      >
        {addSuccess ? (
          /* ---- ÉCRAN DE SUCCÈS ---- */
          <div className="space-y-6 text-center py-4">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto">
              <Ticket size={30} className="text-emerald-600" />
            </div>
            <div>
              <h3 className="text-lg font-extrabold text-[#0F2B59]">Inscription enregistrée !</h3>
              <p className="text-sm text-slate-500 mt-1">{addSuccess.name}</p>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
              <p className="text-xs text-amber-700 font-semibold uppercase tracking-wider mb-1">Numéro d'inscription</p>
              <p className="text-2xl font-mono font-extrabold text-amber-700">{addSuccess.regNumber}</p>
            </div>
            <div className="flex gap-2 justify-center">
              <a
                href={`/confirmation/${addSuccess.regNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0F2B59] text-white text-xs font-bold"
              >
                <Download size={14} />
                Voir le billet
              </a>
              <button
                onClick={resetAddForm}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold"
              >
                <UserPlus size={14} />
                Nouvel inscrit
              </button>
              <button
                onClick={() => { setAddModalOpen(false); resetAddForm(); }}
                className="px-4 py-2 rounded-xl bg-slate-100 text-slate-600 text-xs font-semibold"
              >
                Fermer
              </button>
            </div>
          </div>
        ) : (
          /* ---- FORMULAIRE DE SAISIE ---- */
          <form onSubmit={handleAddParticipant} className="space-y-5">
            {/* Bandeau coût */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-800">
              <Coins size={18} className="text-amber-600 shrink-0" />
              <span>
                Cette inscription déduira <strong>100 FCFA</strong> de votre portefeuille Papyrus.
              </span>
            </div>

            {addError && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700">
                <AlertCircle size={16} className="shrink-0 mt-0.5 text-rose-500" />
                <span>{addError}</span>
              </div>
            )}

            {/* 1. Infos personnelles */}
            <div className="space-y-3">
              <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                1. Informations personnelles
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Prénom *</label>
                  <input
                    type="text" required
                    value={addForm.firstName}
                    onChange={(e) => setAddForm({ ...addForm, firstName: e.target.value })}
                    placeholder="Jean-Baptiste"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nom *</label>
                  <input
                    type="text" required
                    value={addForm.lastName}
                    onChange={(e) => setAddForm({ ...addForm, lastName: e.target.value })}
                    placeholder="SARR"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Téléphone *</label>
                  <input
                    type="tel" required
                    value={addForm.phone}
                    onChange={(e) => setAddForm({ ...addForm, phone: e.target.value })}
                    placeholder="+221 77 000 00 00"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={addForm.email}
                    onChange={(e) => setAddForm({ ...addForm, email: e.target.value })}
                    placeholder="prenom@example.sn"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Sexe</label>
                  <select
                    value={addForm.gender}
                    onChange={(e) => setAddForm({ ...addForm, gender: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  >
                    <option value="M">Masculin</option>
                    <option value="F">Féminin</option>
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Date de naissance</label>
                  <input
                    type="date"
                    value={addForm.birthDate}
                    onChange={(e) => setAddForm({ ...addForm, birthDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
              </div>
            </div>

            {/* 2. Communauté */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                2. Communauté &amp; Origine
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Paroisse</label>
                  <input
                    type="text"
                    value={addForm.parish}
                    onChange={(e) => setAddForm({ ...addForm, parish: e.target.value })}
                    placeholder="Ex : Saint-Joseph"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Diocèse</label>
                  <input
                    type="text"
                    value={addForm.diocese}
                    onChange={(e) => setAddForm({ ...addForm, diocese: e.target.value })}
                    placeholder="Ex : Archidiocèse de Dakar"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Groupe / Mouvement</label>
                  <input
                    type="text"
                    value={addForm.movement}
                    onChange={(e) => setAddForm({ ...addForm, movement: e.target.value })}
                    placeholder="Scouts, Chorale..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Ville</label>
                  <input
                    type="text"
                    value={addForm.city}
                    onChange={(e) => setAddForm({ ...addForm, city: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
              </div>
            </div>

            {/* 3. Contact d'urgence */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                3. Contact d'urgence
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nom du contact</label>
                  <input
                    type="text"
                    value={addForm.emergencyContact}
                    onChange={(e) => setAddForm({ ...addForm, emergencyContact: e.target.value })}
                    placeholder="Parent / Responsable"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Téléphone d'urgence</label>
                  <input
                    type="tel"
                    value={addForm.emergencyPhone}
                    onChange={(e) => setAddForm({ ...addForm, emergencyPhone: e.target.value })}
                    placeholder="+221 77 000 00 00"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#0F2B59]"
                  />
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-4 flex justify-end gap-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => { setAddModalOpen(false); resetAddForm(); }}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600"
              >
                Annuler
              </button>
              <button
                type="submit"
                disabled={addSubmitting}
                className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white text-xs font-bold shadow-sm disabled:opacity-50 transition-all"
              >
                <UserPlus size={15} />
                {addSubmitting ? 'Inscription en cours...' : 'Confirmer l\'inscription'}
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};
