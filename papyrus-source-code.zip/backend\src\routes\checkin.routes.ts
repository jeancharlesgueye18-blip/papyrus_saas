import { Router } from 'express';
import { lookupTicket, confirmCheckIn } from '../controllers/checkin.controller.js';
import { authenticateToken } from '../middleware/auth.js';
import { authorizeEvent } from '../middleware/eventAuth.js';

const router = Router();

router.use(authenticateToken);

// Les contrôleurs (CHECKER, MANAGER, OWNER) peuvent scanner et valider
router.get('/events/:id/lookup', authorizeEvent('CHECKER'), lookupTicket);
router.post('/events/:id/confirm', authorizeEvent('CHECKER'), confirmCheckIn);

export default router;
