import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.js';
import { Logo } from './Logo.js';
import {
  Wallet,
  Bell,
  LogOut,
  User as UserIcon,
  PlusCircle,
  Menu,
  X,
  ShieldCheck,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { api } from '../services/api.js';
import { NotificationItem } from '../types/index.js';

export const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  useEffect(() => {
    if (user) {
      api.getNotifications()
        .then((res) => setNotifications(res.notifications || []))
        .catch(() => {});
    }
  }, [user]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkAllRead = async () => {
    try {
      await api.markAllNotificationsAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    } catch (e) {}
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link to={user ? '/dashboard' : '/'} className="flex items-center">
          <Logo />
        </Link>

        {user ? (
          <div className="flex items-center gap-3 sm:gap-5">
            {/* Portefeuille Rapide */}
            <Link
              to="/billing"
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200/80 text-amber-900 transition-colors group"
              title="Gérer mes crédits et mon portefeuille Papyrus"
            >
              <div className="p-1 rounded-lg bg-amber-500/20 text-amber-700 group-hover:scale-105 transition-transform">
                <Wallet size={16} />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-[10px] font-semibold text-amber-700 leading-none uppercase">
                  Solde Papyrus
                </span>
                <span className="text-xs font-bold text-[#0F2B59] leading-tight">
                  {(user.wallet?.balance || 0).toLocaleString('fr-FR')} FCFA
                  <span className="hidden md:inline font-normal text-amber-700 text-[11px] ml-1">
                    ({Math.floor((user.wallet?.balance || 0) / 100)} crédits)
                  </span>
                </span>
              </div>
            </Link>

            {/* Nouveau Événement */}
            <Link
              to="/events/new"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white text-xs font-semibold shadow-sm transition-all hover:shadow"
            >
              <PlusCircle size={15} className="text-amber-400" />
              <span>Créer un événement</span>
            </Link>

            {/* Notification Popover */}
            <div className="relative">
              <button
                onClick={() => setNotifOpen(!notifOpen)}
                className="relative p-2 rounded-xl text-slate-500 hover:text-[#0F2B59] hover:bg-slate-100 transition-colors"
                title="Notifications"
              >
                <Bell size={18} />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>

              {notifOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-100 py-3 z-50 animate-fade-in">
                  <div className="flex items-center justify-between px-4 pb-2 border-b border-slate-100">
                    <span className="text-xs font-bold text-[#0F2B59] uppercase tracking-wider">
                      Notifications ({unreadCount})
                    </span>
                    {unreadCount > 0 && (
                      <button
                        onClick={handleMarkAllRead}
                        className="text-[11px] text-amber-600 hover:underline font-medium"
                      >
                        Tout marquer comme lu
                      </button>
                    )}
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-50">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-center text-xs text-slate-400">
                        Aucune notification
                      </div>
                    ) : (
                      notifications.slice(0, 10).map((n) => (
                        <div
                          key={n.id}
                          className={`p-3 text-xs hover:bg-slate-50 transition-colors ${
                            !n.isRead ? 'bg-blue-50/40 font-medium' : 'text-slate-600'
                          }`}
                        >
                          <div className="flex items-start gap-2">
                            {n.type === 'SUCCESS' || n.type === 'PAYMENT' ? (
                              <CheckCircle size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                            ) : n.type === 'WARNING' ? (
                              <AlertTriangle size={15} className="text-amber-500 shrink-0 mt-0.5" />
                            ) : (
                              <Bell size={15} className="text-blue-500 shrink-0 mt-0.5" />
                            )}
                            <div>
                              <div className="text-slate-900 font-semibold">{n.title}</div>
                              <div className="text-slate-500 text-[11px] mt-0.5">{n.message}</div>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Menu Admin si ADMIN */}
            {user.role === 'ADMIN' && (
              <Link
                to="/admin"
                className="hidden lg:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 text-xs font-semibold hover:bg-indigo-100 transition-colors"
              >
                <ShieldCheck size={14} />
                Admin
              </Link>
            )}

            {/* Déconnexion */}
            <button
              onClick={() => {
                logout();
                navigate('/login');
              }}
              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
              title="Se déconnecter"
            >
              <LogOut size={18} />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <Link
              to="/login"
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-[#0F2B59] hover:text-amber-600 transition-colors"
            >
              Se connecter
            </Link>
            <Link
              to="/register"
              className="px-4 py-2 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white text-xs sm:text-sm font-semibold shadow-md shadow-blue-950/20 transition-all hover:scale-105"
            >
              Créer mon événement
            </Link>
          </div>
        )}
      </div>
    </header>
  );
};
