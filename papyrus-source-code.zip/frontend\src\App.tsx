import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './context/AuthContext.js';
import { Navbar } from './components/Navbar.js';
import { Sidebar } from './components/Sidebar.js';

import { LandingPage } from './pages/LandingPage.js';
import { LoginPage } from './pages/LoginPage.js';
import { RegisterPage } from './pages/RegisterPage.js';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage.js';
import { DashboardPage } from './pages/DashboardPage.js';
import { EventsListPage } from './pages/EventsListPage.js';
import { EventCreatePage } from './pages/EventCreatePage.js';
import { EventDetailPage } from './pages/EventDetailPage.js';
import { PublicEventPage } from './pages/PublicEventPage.js';
import { ConfirmationPage } from './pages/ConfirmationPage.js';
import { ParticipantsPage } from './pages/ParticipantsPage.js';
import { DynamicListsPage } from './pages/DynamicListsPage.js';
import { ContributionsPage } from './pages/ContributionsPage.js';
import { CheckInPage } from './pages/CheckInPage.js';
import { BillingPage } from './pages/BillingPage.js';
import { SharePage } from './pages/SharePage.js';
import { AdminPage } from './pages/AdminPage.js';

const ProtectedLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-sm font-semibold text-slate-500 animate-pulse">
          Chargement de Papyrus...
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        <Sidebar />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0">
          {children}
        </main>
      </div>
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <Routes>
      {/* Routes Publiques Sans Layout Dashboard */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/e/:slug" element={<PublicEventPage />} />
      <Route path="/confirmation/:regNumber" element={<ConfirmationPage />} />

      {/* Routes Protégées avec Navigation & Sidebar */}
      <Route
        path="/dashboard"
        element={
          <ProtectedLayout>
            <DashboardPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/events"
        element={
          <ProtectedLayout>
            <EventsListPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/events/new"
        element={
          <ProtectedLayout>
            <EventCreatePage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/events/:id"
        element={
          <ProtectedLayout>
            <EventDetailPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/events/:id/participants"
        element={
          <ProtectedLayout>
            <ParticipantsPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/events/:id/categories"
        element={
          <ProtectedLayout>
            <DynamicListsPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/events/:id/contributions"
        element={
          <ProtectedLayout>
            <ContributionsPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/events/:id/check-in"
        element={
          <ProtectedLayout>
            <CheckInPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/events/:id/share"
        element={
          <ProtectedLayout>
            <SharePage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/billing"
        element={
          <ProtectedLayout>
            <BillingPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/admin"
        element={
          <ProtectedLayout>
            <AdminPage />
          </ProtectedLayout>
        }
      />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default App;
