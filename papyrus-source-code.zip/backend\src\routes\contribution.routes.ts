import { Router } from 'express';
import {
  getEventContributions,
  recordContribution,
} from '../controllers/contribution.controller.js';
import { authenticateToken } from '../middleware/auth.js';
import { authorizeEvent } from '../middleware/eventAuth.js';

const router = Router();

router.use(authenticateToken);

router.get('/events/:id/contributions', authorizeEvent('MANAGER'), getEventContributions);
router.post('/events/:id/contributions', authorizeEvent('MANAGER'), recordContribution);

export default router;
