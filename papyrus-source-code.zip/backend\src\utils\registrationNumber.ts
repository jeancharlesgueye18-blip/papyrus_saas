import prisma from '../config/prisma.js';

/**
 * Génère un numéro d'inscription unique au format PAP-YYYY-XXXXXX
 * Exemple: PAP-2027-000001
 */
export async function generateRegistrationNumber(eventDate?: Date): Promise<string> {
  const year = eventDate ? eventDate.getFullYear() : new Date().getFullYear();
  const prefix = `PAP-${year}-`;

  // Compter le nombre de participants existants avec ce préfixe pour dériver le séquenceur
  const count = await prisma.participant.count({
    where: {
      registrationNumber: {
        startsWith: prefix,
      },
    },
  });

  const nextNumber = count + 1;
  const paddedNumber = String(nextNumber).padStart(6, '0');
  let regNumber = `${prefix}${paddedNumber}`;

  // Vérifier l'unicité stricte
  let exists = await prisma.participant.findUnique({
    where: { registrationNumber: regNumber },
  });

  let attempts = 0;
  while (exists && attempts < 100) {
    attempts++;
    const randomSuffix = Math.floor(100000 + Math.random() * 900000);
    regNumber = `${prefix}${randomSuffix}`;
    exists = await prisma.participant.findUnique({
      where: { registrationNumber: regNumber },
    });
  }

  return regNumber;
}
