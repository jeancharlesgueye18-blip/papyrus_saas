import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { CreditPack, Transaction } from '../types/index.js';
import { Modal } from '../components/Modal.js';
import {
  Wallet,
  Sparkles,
  CreditCard,
  History,
  CheckCircle2,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';

export const BillingPage: React.FC = () => {
  const { refreshUser } = useAuth();
  const [walletData, setWalletData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Modal recharge
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedPack, setSelectedPack] = useState<CreditPack | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('WAVE');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    loadBillingData();
  }, []);

  const loadBillingData = async () => {
    try {
      const data = await api.getWallet();
      setWalletData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenPack = (pack: CreditPack) => {
    setSelectedPack(pack);
    setSuccessMessage(null);
    setModalOpen(true);
  };

  const handlePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPack) return;
    setSubmitting(true);

    try {
      await api.purchaseCredits({
        packId: selectedPack.id,
        paymentMethod,
        phoneNumber,
      });

      await refreshUser();
      await loadBillingData();
      setSuccessMessage(`Félicitations ! Votre compte a été crédité de +${selectedPack.credits} inscriptions.`);
      setTimeout(() => {
        setModalOpen(false);
        setSuccessMessage(null);
      }, 2000);
    } catch (err: any) {
      alert(err.message || 'Erreur lors du paiement');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-20 text-slate-400 text-sm">
        Chargement de votre portefeuille Papyrus...
      </div>
    );
  }

  const wallet = walletData?.wallet || { balance: 0, availableCredits: 0 };
  const packs: CreditPack[] = walletData?.packs || [];
  const transactions: Transaction[] = walletData?.transactions || [];

  return (
    <div className="space-y-8 pb-20 animate-fade-in max-w-5xl mx-auto">
      {/* HEADER */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F2B59]">
          Portefeuille Papyrus & Crédits
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Gérez votre solde d'inscriptions et approvisionnez votre compte simplement.
        </p>
      </div>

      {/* CARTE PRINCIPALE SOLDE */}
      <div className="rounded-3xl bg-gradient-to-br from-[#0F2B59] via-blue-900 to-[#0A1C3A] text-white p-6 sm:p-10 shadow-xl shadow-blue-950/20 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-400/20 text-amber-300 border border-amber-400/30">
              <Zap size={14} /> Solde Actuel du Portefeuille
            </span>
            <div className="text-3xl sm:text-5xl font-black font-serif-papyrus text-amber-400">
              {wallet.balance.toLocaleString('fr-FR')} <span className="text-sm font-sans text-slate-300">FCFA</span>
            </div>
            <p className="text-xs text-slate-300">
              Équivalent à <strong className="text-white text-sm">{wallet.availableCredits} inscriptions</strong> disponibles.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur border border-white/10 text-xs text-slate-200 space-y-1">
            <div className="font-bold text-amber-300 uppercase tracking-wider text-[10px]">
              Formule de service Papyrus
            </div>
            <div className="font-bold text-white text-sm">
              1 inscription = 100 FCFA
            </div>
            <p className="text-[11px] text-slate-300">
              Prélèvement automatique & transparent à chaque nouvel inscrit.
            </p>
          </div>
        </div>
      </div>

      {/* GRILLE DES 5 PACKS (Section 20) */}
      <div className="space-y-4">
        <div>
          <h2 className="text-lg font-bold text-[#0F2B59]">
            Recharger mes Crédits d'Inscription
          </h2>
          <p className="text-xs text-slate-500">
            Choisissez le pack adapté à la taille de votre événement ou rassemblement.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {packs.map((pack) => (
            <div
              key={pack.id}
              className={`rounded-3xl p-5 border transition-all flex flex-col justify-between relative bg-white ${
                pack.popular
                  ? 'border-amber-400 shadow-lg shadow-amber-500/10 ring-2 ring-amber-400/30'
                  : 'border-slate-100 shadow-sm hover:border-slate-200 hover:shadow-md'
              }`}
            >
              {pack.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-amber-500 text-[#0F2B59] text-[10px] font-black uppercase tracking-wider shadow-sm">
                  Populaire
                </div>
              )}

              <div>
                <div className="text-xs font-bold text-[#0F2B59] mb-1">
                  {pack.name}
                </div>
                <div className="text-2xl font-black text-[#0F2B59] font-serif-papyrus">
                  {pack.price.toLocaleString('fr-FR')} <span className="text-xs font-sans font-normal text-slate-500">FCFA</span>
                </div>
                <div className="mt-3 p-2.5 rounded-xl bg-blue-50/60 text-center">
                  <div className="text-base font-extrabold text-[#0F2B59]">
                    {pack.credits}
                  </div>
                  <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                    inscriptions
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleOpenPack(pack)}
                className="mt-4 w-full py-2.5 px-3 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white font-bold text-xs shadow-sm transition-all hover:scale-105"
              >
                Acheter ce pack
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* HISTORIQUE DES TRANSACTIONS DU PORTEFEUILLE */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-bold text-[#0F2B59] uppercase tracking-wider flex items-center gap-2">
            <History size={16} className="text-amber-500" />
            Historique des Débits & Recharges ({transactions.length})
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Montant</th>
                <th className="py-3 px-4">Mode / Référence</th>
                <th className="py-3 px-4">Détail</th>
                <th className="py-3 px-4 text-right">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    Aucune transaction sur ce portefeuille.
                  </td>
                </tr>
              ) : (
                transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50/70">
                    <td className="py-3.5 px-4 font-semibold">
                      {tx.type === 'CREDIT_PURCHASE' ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-bold text-[10px]">
                          <ArrowDownLeft size={12} /> Recharge
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-slate-700 bg-slate-100 px-2 py-0.5 rounded-full font-bold text-[10px]">
                          <ArrowUpRight size={12} /> Frais Inscription
                        </span>
                      )}
                    </td>
                    <td
                      className={`py-3.5 px-4 font-bold text-sm ${
                        tx.amount > 0 ? 'text-emerald-700' : 'text-slate-800'
                      }`}
                    >
                      {tx.amount > 0 ? `+${tx.amount.toLocaleString('fr-FR')}` : tx.amount.toLocaleString('fr-FR')} FCFA
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-500 text-[11px]">
                      {tx.paymentMethod || 'SYSTEM'} • {tx.reference}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {tx.packName || 'Frais de service Papyrus'}
                    </td>
                    <td className="py-3.5 px-4 text-right text-slate-400 whitespace-nowrap">
                      {new Date(tx.createdAt).toLocaleString('fr-FR')}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL SIMULATION RECHARGE */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Recharger mon Portefeuille Papyrus"
      >
        {selectedPack && (
          <form onSubmit={handlePurchase} className="space-y-4">
            {successMessage ? (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs text-center font-bold">
                {successMessage}
              </div>
            ) : (
              <>
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-1">
                  <div className="font-bold text-sm">
                    {selectedPack.name} : +{selectedPack.credits} inscriptions
                  </div>
                  <div>
                    Montant à débiter : <strong className="text-base text-[#0F2B59]">{selectedPack.price.toLocaleString('fr-FR')} FCFA</strong>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                    Moyen de Paiement Mobile Money
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {['WAVE', 'ORANGE_MONEY', 'FREE_MONEY'].map((m) => (
                      <button
                        type="button"
                        key={m}
                        onClick={() => setPaymentMethod(m)}
                        className={`p-3 rounded-xl border text-xs font-bold text-center transition-all ${
                          paymentMethod === m
                            ? 'border-[#0F2B59] bg-blue-50 text-[#0F2B59] shadow-sm ring-2 ring-blue-500/20'
                            : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        {m === 'WAVE' ? 'Wave' : m === 'ORANGE_MONEY' ? 'Orange Money' : 'Free Money'}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Numéro de téléphone payeur
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+221 77 123 45 67"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Simulation sécurisée de paiement pour la version MVP.
                  </p>
                </div>

                <div className="pt-3 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0F2B59] text-xs font-bold shadow-md transition-all disabled:opacity-50"
                  >
                    {submitting ? 'Validation...' : `Payer ${selectedPack.price.toLocaleString('fr-FR')} FCFA`}
                  </button>
                </div>
              </>
            )}
          </form>
        )}
      </Modal>
    </div>
  );
};
