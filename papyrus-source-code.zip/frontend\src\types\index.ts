export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: 'ADMIN' | 'ORGANIZER';
  isSuspended?: boolean;
  organization?: {
    name: string;
    type: string;
    diocese?: string;
    city?: string;
  };
  wallet?: {
    balance: number;
    credits: number;
  };
  unreadNotificationsCount?: number;
}

export interface EventItem {
  id: string;
  name: string;
  slug: string;
  type: string;
  description?: string;
  startDate: string;
  endDate?: string;
  location: string;
  parish?: string;
  diocese?: string;
  contributionAmount: number;
  contributionType: string;
  isActive: boolean;
  qrCode?: string;
  stats?: {
    totalParticipants: number;
    totalCollected: number;
    totalCheckedIn: number;
    fullyPaidCount: number;
  };
  _count?: {
    participants: number;
  };
}

export interface Participant {
  id: string;
  eventId: string;
  registrationNumber: string;
  firstName: string;
  lastName: string;
  phone: string;
  email?: string;
  birthDate?: string;
  gender?: 'M' | 'F';
  parish?: string;
  diocese?: string;
  movement?: string;
  city?: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  customData?: string;
  qrCode?: string;
  qrToken?: string;
  contributionStatus: 'PAID' | 'PARTIAL' | 'UNPAID';
  amountPaid: number;
  isPresent: boolean;
  checkedInAt?: string;
  createdAt: string;
  event?: EventItem;
  contributions?: Contribution[];
}

export interface Contribution {
  id: string;
  participantId: string;
  amount: number;
  date: string;
  paymentMethod: string;
  reference?: string;
  recordedBy?: string;
  participant?: {
    id: string;
    registrationNumber: string;
    firstName: string;
    lastName: string;
    phone: string;
    parish?: string;
  };
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  type: 'CREDIT_PURCHASE' | 'REGISTRATION_FEE' | 'REFUND';
  status: string;
  reference: string;
  paymentMethod?: string;
  packName?: string;
  createdAt: string;
}

export interface CreditPack {
  id: string;
  name: string;
  price: number;
  credits: number;
  popular?: boolean;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: string;
}
