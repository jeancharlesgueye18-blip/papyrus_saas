import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.js';
import { api } from '../services/api.js';
import { EventItem } from '../types/index.js';
import {
  Calendar,
  Users,
  Coins,
  Wallet,
  ArrowUpRight,
  PlusCircle,
  QrCode,
  Share2,
  TrendingUp,
  Clock,
  Sparkles,
  Search,
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [chartTimeframe, setChartTimeframe] = useState<'7' | '30' | '90'>('30');

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const data = await api.getEvents();
      setEvents(data.events || []);
    } catch (err) {
      console.error('Erreur chargement dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  // Calcul des métriques globales
  const activeEventsCount = events.filter((e) => e.isActive).length;
  const totalParticipantsCount = events.reduce(
    (sum, e) => sum + (e.stats?.totalParticipants || 0),
    0
  );
  const totalCollectedAmount = events.reduce(
    (sum, e) => sum + (e.stats?.totalCollected || 0),
    0
  );
  const walletBalance = user?.wallet?.balance || 0;
  const availableCredits = Math.floor(walletBalance / 100);

  // Données simulées d'évolution des inscriptions pour le graphique interactif SVG
  const chartData = {
    '7': [
      { label: 'J-6', val: 12 },
      { label: 'J-5', val: 18 },
      { label: 'J-4', val: 24 },
      { label: 'J-3', val: 19 },
      { label: 'J-2', val: 35 },
      { label: 'Hier', val: 42 },
      { label: 'Auj', val: 56 },
    ],
    '30': [
      { label: 'Sem 1', val: 45 },
      { label: 'Sem 2', val: 92 },
      { label: 'Sem 3', val: 140 },
      { label: 'Sem 4', val: 210 },
    ],
    '90': [
      { label: 'Mois 1', val: 110 },
      { label: 'Mois 2', val: 240 },
      { label: 'Mois 3', val: 428 },
    ],
  }[chartTimeframe];

  const maxVal = Math.max(...chartData.map((d) => d.val), 1);

  return (
    <div className="space-y-8 animate-fade-in pb-16">
      {/* HEADER DE BIENVENUE */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#0F2B59]">
            Tableau de Bord
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Bienvenue, <strong className="text-slate-800">{user?.firstName} {user?.lastName}</strong> • {user?.organization?.name || 'Communauté chrétienne'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/events/new"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0F2B59] hover:bg-blue-900 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-950/20 transition-all hover:scale-[1.02]"
          >
            <PlusCircle size={18} className="text-amber-400" />
            <span>Nouvel Événement</span>
          </Link>
        </div>
      </div>

      {/* CARTES STATISTIQUES */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-5">
        {/* Événements actifs */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Événements Actifs
            </span>
            <div className="p-2 rounded-xl bg-blue-50 text-[#0F2B59]">
              <Calendar size={18} />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#0F2B59]">
            {activeEventsCount}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span className="text-emerald-600 font-semibold">{events.length}</span> au total
          </div>
        </div>

        {/* Participants */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Participants
            </span>
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-700">
              <Users size={18} />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#0F2B59]">
            {totalParticipantsCount.toLocaleString('fr-FR')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Inscriptions cumulées
          </div>
        </div>

        {/* Cotisations */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-shadow col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Cotisations
            </span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
              <Coins size={18} />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-700 font-serif-papyrus">
            {totalCollectedAmount.toLocaleString('fr-FR')} <span className="text-xs font-sans text-slate-500">FCFA</span>
          </div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">
            Fonds collectés
          </div>
        </div>

        {/* Solde Papyrus */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#0F2B59] to-blue-900 text-white shadow-md shadow-blue-950/20">
          <div className="flex items-center justify-between text-amber-300 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              Solde Papyrus
            </span>
            <div className="p-2 rounded-xl bg-white/10 text-amber-400">
              <Wallet size={18} />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold font-serif-papyrus text-amber-400">
            {walletBalance.toLocaleString('fr-FR')} <span className="text-xs font-sans text-slate-200">FCFA</span>
          </div>
          <Link
            to="/billing"
            className="text-[11px] text-amber-300 hover:text-amber-200 underline font-semibold mt-1 inline-block"
          >
            Recharger mon portefeuille →
          </Link>
        </div>

        {/* Inscriptions restantes */}
        <div className="p-4 sm:p-5 rounded-2xl bg-amber-50 border border-amber-200 shadow-sm">
          <div className="flex items-center justify-between text-amber-700 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              Inscriptions Restantes
            </span>
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-700">
              <Sparkles size={18} />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#0F2B59]">
            {availableCredits}
          </div>
          <div className="text-[11px] text-amber-800 font-medium mt-1">
            (100 FCFA / inscription)
          </div>
        </div>
      </div>

      {/* GRAPHIQUE ÉVOLUTION DES INSCRIPTIONS */}
      <div className="p-6 rounded-3xl bg-white border border-slate-100 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h2 className="text-base font-bold text-[#0F2B59] flex items-center gap-2">
              <TrendingUp size={18} className="text-amber-500" />
              Évolution des Inscriptions
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Rythme des enregistrements sur la plateforme
            </p>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold">
            {(['7', '30', '90'] as const).map((period) => (
              <button
                key={period}
                onClick={() => setChartTimeframe(period)}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  chartTimeframe === period
                    ? 'bg-white text-[#0F2B59] shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {period === '7' ? '7 jours' : period === '30' ? '30 jours' : '90 jours'}
              </button>
            ))}
          </div>
        </div>

        {/* BARS CHART SVG MODERNE */}
        <div className="h-48 flex items-end gap-3 sm:gap-6 pt-6 px-2 border-b border-slate-100">
          {chartData.map((bar, i) => {
            const heightPercent = Math.max(12, Math.round((bar.val / maxVal) * 100));
            return (
              <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                <span className="text-[11px] font-bold text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity">
                  {bar.val}
                </span>
                <div
                  style={{ height: `${heightPercent}%` }}
                  className="w-full max-w-[48px] rounded-t-xl bg-gradient-to-t from-[#0F2B59] to-amber-500 group-hover:to-amber-400 transition-all shadow-sm"
                ></div>
                <span className="text-[10px] font-semibold text-slate-500 mt-1 whitespace-nowrap">
                  {bar.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION MES ÉVÉNEMENTS */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#0F2B59]">
            Mes Événements ({events.length})
          </h2>
          <Link
            to="/events/new"
            className="text-xs font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1"
          >
            <span>+ Créer un nouvel événement</span>
          </Link>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-400 text-sm">
            Chargement des événements...
          </div>
        ) : events.length === 0 ? (
          <div className="text-center py-16 px-4 bg-white rounded-3xl border border-dashed border-slate-200">
            <div className="w-16 h-16 rounded-full bg-blue-50 text-[#0F2B59] flex items-center justify-center mx-auto mb-4">
              <Calendar size={28} />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Aucun événement pour le moment
            </h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-6">
              Créez votre première messe, pèlerinage, JMJ ou marche pour commencer à recevoir des inscriptions.
            </p>
            <Link
              to="/events/new"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#0F2B59] text-white font-bold text-xs"
            >
              <PlusCircle size={16} className="text-amber-400" />
              Créer un événement
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {events.map((evt) => (
              <div
                key={evt.id}
                className="bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md hover:border-slate-200 transition-all p-5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-[#0F2B59]">
                      {evt.type}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        evt.isActive
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      {evt.isActive ? 'Actif' : 'Clôturé'}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-[#0F2B59] line-clamp-1">
                    {evt.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                    {evt.description || `Lieu : ${evt.location}`}
                  </p>

                  <div className="mt-4 pt-4 border-t border-slate-50 grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px] font-semibold uppercase">
                        Participants
                      </span>
                      <span className="font-bold text-slate-800 text-sm">
                        {evt.stats?.totalParticipants || 0}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] font-semibold uppercase">
                        Cotisation
                      </span>
                      <span className="font-bold text-emerald-700 text-sm">
                        {evt.contributionAmount.toLocaleString('fr-FR')} F
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                  <Link
                    to={`/events/${evt.id}`}
                    className="flex-1 text-center py-2 px-3 rounded-xl bg-slate-100 hover:bg-[#0F2B59] hover:text-white text-[#0F2B59] font-bold text-xs transition-colors"
                  >
                    Gérer
                  </Link>

                  <Link
                    to={`/events/${evt.id}/check-in`}
                    className="p-2 rounded-xl bg-amber-50 text-amber-700 hover:bg-amber-100 transition-colors"
                    title="Scanner à l'entrée"
                  >
                    <QrCode size={18} />
                  </Link>

                  <Link
                    to={`/events/${evt.id}/share`}
                    className="p-2 rounded-xl bg-blue-50 text-[#0F2B59] hover:bg-blue-100 transition-colors"
                    title="Partager le lien"
                  >
                    <Share2 size={18} />
                  </Link>

                  <Link
                    to={`/e/${evt.slug}`}
                    target="_blank"
                    className="p-2 rounded-xl bg-slate-50 text-slate-600 hover:text-slate-900 transition-colors"
                    title="Voir la page publique"
                  >
                    <ArrowUpRight size={18} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
